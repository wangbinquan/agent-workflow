--
-- PostgreSQL database dump
--

\restrict Q802Qe3I5i6fCXkRhgnt1T151kOEpA9VOJ2g9lfUr8zcn8Is8aECyN5rcJiVO7Z

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: agent_workflow; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA agent_workflow;


--
-- Name: agent_workflow_meta; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA agent_workflow_meta;


--
-- Name: hex(bytea); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.hex(value bytea) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$ SELECT encode(value, 'hex') $$;


--
-- Name: hex(text); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.hex(value text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$ SELECT encode(convert_to(value, 'UTF8'), 'hex') $$;


--
-- Name: instr(text, text); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.instr(value text, needle text) RETURNS bigint
    LANGUAGE sql IMMUTABLE STRICT
    AS $$ SELECT strpos(value, needle)::bigint $$;


--
-- Name: json_extract(text, text); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.json_extract(value text, path text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $_$ DECLARE item jsonb; BEGIN IF path !~ '^\$\.[A-Za-z_][A-Za-z0-9_]*$' THEN RETURN NULL; END IF; item := value::jsonb -> substring(path from 3); IF item IS NULL THEN RETURN NULL; END IF; IF jsonb_typeof(item) = 'string' THEN RETURN item #>> '{}'; END IF; RETURN item::text; EXCEPTION WHEN others THEN RETURN NULL; END $_$;


--
-- Name: json_type(text, text); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.json_type(value text, path text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $_$ DECLARE item jsonb; BEGIN IF path !~ '^\$\.[A-Za-z_][A-Za-z0-9_]*$' THEN RETURN NULL; END IF; item := value::jsonb -> substring(path from 3); IF item IS NULL THEN RETURN NULL; END IF; RETURN jsonb_typeof(item); EXCEPTION WHEN others THEN RETURN NULL; END $_$;


--
-- Name: json_valid(text); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.json_valid(value text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$ BEGIN PERFORM value::jsonb; RETURN TRUE; EXCEPTION WHEN others THEN RETURN FALSE; END $$;


--
-- Name: max(bigint, bigint); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.max(left_value bigint, right_value bigint) RETURNS bigint
    LANGUAGE sql IMMUTABLE STRICT
    AS $$ SELECT greatest(left_value, right_value) $$;


--
-- Name: unixepoch(); Type: FUNCTION; Schema: agent_workflow; Owner: -
--

CREATE FUNCTION agent_workflow.unixepoch() RETURNS bigint
    LANGUAGE sql
    AS $$ SELECT extract(epoch from clock_timestamp())::bigint $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_template_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.action_template_revisions (
    template_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: action_templates; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.action_templates (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint,
    capability_id text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: agents; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.agents (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    outputs text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    inputs text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    sync_outputs_on_iterate boolean DEFAULT true NOT NULL,
    runtime text COLLATE pg_catalog."C",
    permission text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    skills text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    depends_on text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    mcp text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    plugins text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    frontmatter_extra text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    body_md text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    builtin boolean DEFAULT false NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: auth_login_policy; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.auth_login_policy (
    id text NOT NULL COLLATE pg_catalog."C",
    password_login_enabled boolean DEFAULT true NOT NULL,
    oidc_default_role text DEFAULT 'guest'::text NOT NULL COLLATE pg_catalog."C",
    bootstrap_completed_at bigint,
    updated_at bigint NOT NULL
);


--
-- Name: automation_policies; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.automation_policies (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint
);


--
-- Name: automation_policy_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.automation_policy_revisions (
    policy_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: cached_repos; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.cached_repos (
    id text NOT NULL COLLATE pg_catalog."C",
    url_hash text NOT NULL COLLATE pg_catalog."C",
    url_enc text COLLATE pg_catalog."C",
    url_redacted text COLLATE pg_catalog."C",
    local_path text NOT NULL COLLATE pg_catalog."C",
    default_branch text COLLATE pg_catalog."C",
    last_fetched_at bigint NOT NULL,
    created_at bigint NOT NULL,
    has_submodules boolean,
    last_submodule_sync_ok boolean,
    last_submodule_sync_error text COLLATE pg_catalog."C",
    last_auto_refresh_at bigint
);


--
-- Name: capability_templates; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.capability_templates (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text COLLATE pg_catalog."C",
    capability text NOT NULL COLLATE pg_catalog."C",
    scripts_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    hooks_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    param_schema_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    param_defaults_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    agent_by_slot_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    prompt_by_slot_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    params_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    stage_contract_ver bigint DEFAULT 1 NOT NULL,
    upstream_id text COLLATE pg_catalog."C",
    upstream_version bigint,
    base_digest text COLLATE pg_catalog."C",
    base_snapshot_json text COLLATE pg_catalog."C",
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    builtin boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: clarify_rounds; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.clarify_rounds (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    asking_node_id text NOT NULL COLLATE pg_catalog."C",
    asking_node_run_id text NOT NULL COLLATE pg_catalog."C",
    asking_shard_key text COLLATE pg_catalog."C",
    intermediary_node_id text NOT NULL COLLATE pg_catalog."C",
    intermediary_node_run_id text NOT NULL COLLATE pg_catalog."C",
    target_consumer_node_id text COLLATE pg_catalog."C",
    loop_iter bigint DEFAULT 0 NOT NULL,
    container_run_id text COLLATE pg_catalog."C",
    iteration bigint DEFAULT 0 NOT NULL,
    questions_json text NOT NULL COLLATE pg_catalog."C",
    answers_json text COLLATE pg_catalog."C",
    directive text COLLATE pg_catalog."C",
    status text DEFAULT 'awaiting_human'::text NOT NULL COLLATE pg_catalog."C",
    truncation_warnings_json text COLLATE pg_catalog."C",
    designer_run_triggered_at bigint,
    abandoned_at bigint,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    answered_at bigint,
    answered_by text COLLATE pg_catalog."C",
    submitted_by_role text COLLATE pg_catalog."C",
    answer_attributions_json text COLLATE pg_catalog."C",
    draft_answers_json text COLLATE pg_catalog."C"
);


--
-- Name: code_ai_attempts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_ai_attempts (
    id text NOT NULL COLLATE pg_catalog."C",
    round_id text NOT NULL COLLATE pg_catalog."C",
    stage_name text NOT NULL COLLATE pg_catalog."C",
    shard_key text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    rerun_seq bigint DEFAULT 0 NOT NULL,
    attempt_seq bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'claimed'::text NOT NULL COLLATE pg_catalog."C",
    validation_outcome text COLLATE pg_catalog."C",
    session_ref text COLLATE pg_catalog."C",
    node_run_id text COLLATE pg_catalog."C",
    started_at bigint NOT NULL,
    ended_at bigint
);


--
-- Name: code_findings; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_findings (
    id text NOT NULL COLLATE pg_catalog."C",
    code_host_endpoint_id text NOT NULL COLLATE pg_catalog."C",
    stable_project_id text NOT NULL COLLATE pg_catalog."C",
    anchor_kind text NOT NULL COLLATE pg_catalog."C",
    anchor_id text NOT NULL COLLATE pg_catalog."C",
    capability text NOT NULL COLLATE pg_catalog."C",
    fingerprint text NOT NULL COLLATE pg_catalog."C",
    generation bigint DEFAULT 1 NOT NULL,
    lifecycle text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    severity text COLLATE pg_catalog."C",
    title text COLLATE pg_catalog."C",
    file_path text COLLATE pg_catalog."C",
    anchor_line bigint,
    external_id text COLLATE pg_catalog."C",
    published_round_id text COLLATE pg_catalog."C",
    disappeared_round_id text COLLATE pg_catalog."C",
    resolved_at bigint,
    resolved_round_id text COLLATE pg_catalog."C",
    code_changed_at bigint,
    code_changed_round_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    last_seen_at bigint NOT NULL,
    closed_at bigint
);


--
-- Name: code_host_connections; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_host_connections (
    provider text NOT NULL COLLATE pg_catalog."C",
    base_url text NOT NULL COLLATE pg_catalog."C",
    repository_url_prefixes_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    transport_mappings_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    connection_generation text DEFAULT md5(((random())::text || (clock_timestamp())::text)) NOT NULL COLLATE pg_catalog."C",
    reject_unauthorized boolean DEFAULT true NOT NULL,
    token_enc text NOT NULL COLLATE pg_catalog."C",
    token_hint text NOT NULL COLLATE pg_catalog."C",
    last_test_json text COLLATE pg_catalog."C",
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_by text COLLATE pg_catalog."C"
);


--
-- Name: code_round_stages; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_round_stages (
    id text NOT NULL COLLATE pg_catalog."C",
    round_id text NOT NULL COLLATE pg_catalog."C",
    stage_seq bigint NOT NULL,
    stage_name text NOT NULL COLLATE pg_catalog."C",
    stage_kind text NOT NULL COLLATE pg_catalog."C",
    status text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    counts_json text COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    started_at bigint,
    ended_at bigint
);


--
-- Name: code_trigger_deliveries; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_trigger_deliveries (
    id text NOT NULL COLLATE pg_catalog."C",
    correlation_id text NOT NULL COLLATE pg_catalog."C",
    code_host_endpoint_id text COLLATE pg_catalog."C",
    stable_project_id text COLLATE pg_catalog."C",
    anchor_kind text COLLATE pg_catalog."C",
    anchor_id text COLLATE pg_catalog."C",
    capability text COLLATE pg_catalog."C",
    step text NOT NULL COLLATE pg_catalog."C",
    outcome text NOT NULL COLLATE pg_catalog."C",
    reason text COLLATE pg_catalog."C",
    queued_at bigint,
    queue_position bigint,
    waiting_on text COLLATE pg_catalog."C",
    round_id text COLLATE pg_catalog."C",
    is_probe boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: code_work_items; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_work_items (
    id text NOT NULL COLLATE pg_catalog."C",
    code_host_endpoint_id text NOT NULL COLLATE pg_catalog."C",
    stable_project_id text NOT NULL COLLATE pg_catalog."C",
    capability text NOT NULL COLLATE pg_catalog."C",
    anchor_kind text NOT NULL COLLATE pg_catalog."C",
    anchor_id text NOT NULL COLLATE pg_catalog."C",
    status text DEFAULT 'idle'::text NOT NULL COLLATE pg_catalog."C",
    epoch bigint DEFAULT 1 NOT NULL,
    current_round_id text COLLATE pg_catalog."C",
    pending_generation bigint,
    handed_off_fingerprint text COLLATE pg_catalog."C",
    publishing_epoch bigint,
    pending_revision text COLLATE pg_catalog."C",
    anchor_meta text COLLATE pg_catalog."C",
    initiator_user_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    closed_at bigint
);


--
-- Name: code_work_rounds; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.code_work_rounds (
    id text NOT NULL COLLATE pg_catalog."C",
    work_item_id text NOT NULL COLLATE pg_catalog."C",
    round_seq bigint NOT NULL,
    epoch bigint NOT NULL,
    task_id text COLLATE pg_catalog."C",
    baseline_sha text COLLATE pg_catalog."C",
    work_package text COLLATE pg_catalog."C",
    template_snapshot text COLLATE pg_catalog."C",
    stage_contract_ver bigint DEFAULT 1 NOT NULL,
    outcome text COLLATE pg_catalog."C",
    started_at bigint NOT NULL,
    ended_at bigint
);


--
-- Name: collaboration_gate_artifacts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.collaboration_gate_artifacts (
    operation_id text NOT NULL COLLATE pg_catalog."C",
    artifact_key text NOT NULL COLLATE pg_catalog."C",
    artifact_kind text NOT NULL COLLATE pg_catalog."C",
    staged_path text NOT NULL COLLATE pg_catalog."C",
    final_path text NOT NULL COLLATE pg_catalog."C",
    sha256 text NOT NULL COLLATE pg_catalog."C",
    byte_size bigint NOT NULL,
    state text NOT NULL COLLATE pg_catalog."C",
    receipt_json text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL,
    CONSTRAINT collaboration_gate_artifacts_byte_size_nonnegative CHECK ((byte_size >= 0)),
    CONSTRAINT collaboration_gate_artifacts_receipt_json_valid CHECK (((receipt_json IS NULL) OR agent_workflow.json_valid(receipt_json)))
);


--
-- Name: collaboration_gate_operations; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.collaboration_gate_operations (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    gate_kind text NOT NULL COLLATE pg_catalog."C",
    operation_kind text NOT NULL COLLATE pg_catalog."C",
    gate_ref text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    expected_task_revision bigint NOT NULL,
    expected_gate_revision bigint NOT NULL,
    result_gate_revision bigint,
    state text NOT NULL COLLATE pg_catalog."C",
    claim_epoch bigint DEFAULT 0 NOT NULL,
    claim_expires_at bigint,
    schema_version bigint DEFAULT 1 NOT NULL,
    manifest_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    receipt_json text COLLATE pg_catalog."C",
    failure_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    committed_at bigint,
    completed_at bigint,
    CONSTRAINT collaboration_gate_operations_claim_epoch_nonnegative CHECK ((claim_epoch >= 0)),
    CONSTRAINT collaboration_gate_operations_committed_shape CHECK (((state <> 'committed'::text) OR ((result_gate_revision IS NOT NULL) AND (receipt_json IS NOT NULL) AND (committed_at IS NOT NULL)))),
    CONSTRAINT collaboration_gate_operations_completed_shape CHECK (((state <> 'completed'::text) OR ((failure_json IS NOT NULL) OR ((result_gate_revision IS NOT NULL) AND (receipt_json IS NOT NULL) AND (committed_at IS NOT NULL))))),
    CONSTRAINT collaboration_gate_operations_failed_shape CHECK (((state <> 'failed'::text) OR (failure_json IS NOT NULL))),
    CONSTRAINT collaboration_gate_operations_failure_json_valid CHECK (((failure_json IS NULL) OR agent_workflow.json_valid(failure_json))),
    CONSTRAINT collaboration_gate_operations_gate_revision_nonnegative CHECK ((expected_gate_revision >= 0)),
    CONSTRAINT collaboration_gate_operations_manifest_json_valid CHECK (agent_workflow.json_valid(manifest_json)),
    CONSTRAINT collaboration_gate_operations_receipt_json_valid CHECK (((receipt_json IS NULL) OR agent_workflow.json_valid(receipt_json))),
    CONSTRAINT collaboration_gate_operations_result_revision_next CHECK (((result_gate_revision IS NULL) OR (result_gate_revision = (expected_gate_revision + 1)))),
    CONSTRAINT collaboration_gate_operations_schema_version_positive CHECK ((schema_version > 0)),
    CONSTRAINT collaboration_gate_operations_task_revision_nonnegative CHECK ((expected_task_revision >= 0))
);


--
-- Name: committed_event_aggregate_heads; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.committed_event_aggregate_heads (
    producer text NOT NULL COLLATE pg_catalog."C",
    family text NOT NULL COLLATE pg_catalog."C",
    aggregate_kind text NOT NULL COLLATE pg_catalog."C",
    aggregate_id text NOT NULL COLLATE pg_catalog."C",
    last_seq bigint NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT committed_event_aggregate_heads_last_seq_positive CHECK ((last_seq > 0))
);


--
-- Name: committed_event_deliveries; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.committed_event_deliveries (
    event_id text NOT NULL COLLATE pg_catalog."C",
    consumer_id text NOT NULL COLLATE pg_catalog."C",
    delivery_class text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    attempt_count bigint DEFAULT 0 NOT NULL,
    next_attempt_at bigint NOT NULL,
    claimed_by text COLLATE pg_catalog."C",
    lease_epoch bigint DEFAULT 0 NOT NULL,
    claim_expires_at bigint,
    last_error_code text COLLATE pg_catalog."C",
    last_error_summary text COLLATE pg_catalog."C",
    replay_generation bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    accepted_at bigint,
    dead_letter_at bigint,
    CONSTRAINT committed_event_deliveries_attempt_nonnegative CHECK ((attempt_count >= 0)),
    CONSTRAINT committed_event_deliveries_lease_epoch_nonnegative CHECK ((lease_epoch >= 0)),
    CONSTRAINT committed_event_deliveries_replay_generation_nonnegative CHECK ((replay_generation >= 0))
);


--
-- Name: committed_event_family_cutovers; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.committed_event_family_cutovers (
    producer text NOT NULL COLLATE pg_catalog."C",
    family text NOT NULL COLLATE pg_catalog."C",
    mode text NOT NULL COLLATE pg_catalog."C",
    epoch bigint NOT NULL,
    changed_at bigint NOT NULL,
    change_ref text NOT NULL COLLATE pg_catalog."C",
    CONSTRAINT committed_event_family_cutovers_epoch_positive CHECK ((epoch > 0))
);


--
-- Name: committed_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.committed_events (
    id text NOT NULL COLLATE pg_catalog."C",
    event_group_id text NOT NULL COLLATE pg_catalog."C",
    event_group_ordinal bigint NOT NULL,
    producer text NOT NULL COLLATE pg_catalog."C",
    family text NOT NULL COLLATE pg_catalog."C",
    event_type text NOT NULL COLLATE pg_catalog."C",
    schema_version bigint NOT NULL,
    aggregate_kind text NOT NULL COLLATE pg_catalog."C",
    aggregate_id text NOT NULL COLLATE pg_catalog."C",
    aggregate_seq bigint NOT NULL,
    operation_ref text NOT NULL COLLATE pg_catalog."C",
    correlation_ref text COLLATE pg_catalog."C",
    causation_ref text COLLATE pg_catalog."C",
    occurred_at bigint NOT NULL,
    payload_json text NOT NULL COLLATE pg_catalog."C",
    payload_digest text NOT NULL COLLATE pg_catalog."C",
    delivery_mode text NOT NULL COLLATE pg_catalog."C",
    producer_epoch bigint NOT NULL,
    created_at bigint NOT NULL,
    CONSTRAINT committed_events_aggregate_seq_positive CHECK ((aggregate_seq > 0)),
    CONSTRAINT committed_events_group_ordinal_nonnegative CHECK ((event_group_ordinal >= 0)),
    CONSTRAINT committed_events_payload_digest_shape CHECK (((length(payload_digest) = 64) OR (payload_digest = ('canonical-hex-v1:'::text || lower(agent_workflow.hex(payload_json)))))),
    CONSTRAINT committed_events_payload_json_valid CHECK (agent_workflow.json_valid(payload_json)),
    CONSTRAINT committed_events_producer_epoch_positive CHECK ((producer_epoch > 0)),
    CONSTRAINT committed_events_schema_v1 CHECK ((schema_version = 1))
);


--
-- Name: custom_event_source_definitions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.custom_event_source_definitions (
    id text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    retired_at bigint
);


--
-- Name: custom_event_source_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.custom_event_source_revisions (
    source_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    validation_receipt_json text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: development_action_runs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_action_runs (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    mission_revision bigint NOT NULL,
    decision_id text NOT NULL COLLATE pg_catalog."C",
    capability_id text NOT NULL COLLATE pg_catalog."C",
    capability_contract_version bigint NOT NULL,
    template_id text COLLATE pg_catalog."C",
    template_revision bigint,
    work_set_digest text COLLATE pg_catalog."C",
    input_fact_digest text NOT NULL COLLATE pg_catalog."C",
    baseline_ref text COLLATE pg_catalog."C",
    writable bigint DEFAULT 0 NOT NULL,
    status text NOT NULL COLLATE pg_catalog."C",
    result_ref text COLLATE pg_catalog."C",
    failure_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_adapter_definition_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_adapter_definition_revisions (
    adapter_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: development_adapter_definitions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_adapter_definitions (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint,
    purpose text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: development_agent_attempts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_agent_attempts (
    id text NOT NULL COLLATE pg_catalog."C",
    action_run_id text NOT NULL COLLATE pg_catalog."C",
    rerun_seq bigint NOT NULL,
    attempt_seq bigint NOT NULL,
    execution_ref text COLLATE pg_catalog."C",
    baseline_ref text NOT NULL COLLATE pg_catalog."C",
    nonce_digest text NOT NULL COLLATE pg_catalog."C",
    input_digest text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    rejection_json text COLLATE pg_catalog."C",
    outcome_ref text COLLATE pg_catalog."C",
    pre_snapshot_ref text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_approval_sagas; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_approval_sagas (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    step_run_id text NOT NULL COLLATE pg_catalog."C",
    adapter_id text NOT NULL COLLATE pg_catalog."C",
    adapter_revision bigint NOT NULL,
    draft_ref text NOT NULL COLLATE pg_catalog."C",
    submit_intent_digest text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    correlation_ref text COLLATE pg_catalog."C",
    external_request_ref text COLLATE pg_catalog."C",
    submitted_revision text COLLATE pg_catalog."C",
    latest_status text DEFAULT 'submitting'::text NOT NULL COLLATE pg_catalog."C",
    observed_revision text COLLATE pg_catalog."C",
    evidence_ref text COLLATE pg_catalog."C",
    deadline_at bigint NOT NULL,
    attempt_ordinal bigint DEFAULT 0 NOT NULL,
    next_observe_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_bundle_refs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_bundle_refs (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    purpose text NOT NULL COLLATE pg_catalog."C",
    evidence_ref text NOT NULL COLLATE pg_catalog."C",
    manifest_digest text NOT NULL COLLATE pg_catalog."C",
    file_count bigint NOT NULL,
    total_bytes bigint NOT NULL,
    retention_state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: development_decisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_decisions (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    mission_revision bigint NOT NULL,
    policy_id text COLLATE pg_catalog."C",
    policy_revision bigint,
    employee_id text COLLATE pg_catalog."C",
    employee_revision bigint,
    fact_snapshot_id text COLLATE pg_catalog."C",
    fact_digest text NOT NULL COLLATE pg_catalog."C",
    work_set_json text COLLATE pg_catalog."C",
    guard_trace_json text NOT NULL COLLATE pg_catalog."C",
    rule_trace_json text NOT NULL COLLATE pg_catalog."C",
    selected_json text NOT NULL COLLATE pg_catalog."C",
    canonical_digest text NOT NULL COLLATE pg_catalog."C",
    decision_input_digest text NOT NULL COLLATE pg_catalog."C",
    decided_at bigint NOT NULL
);


--
-- Name: development_deferred_wakes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_deferred_wakes (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    decision_id text NOT NULL COLLATE pg_catalog."C",
    reason text NOT NULL COLLATE pg_catalog."C",
    resume_at bigint,
    wake_sources_json text NOT NULL COLLATE pg_catalog."C",
    attempt_ordinal bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'armed'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_effects; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_effects (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    action_run_id text COLLATE pg_catalog."C",
    effect_kind text NOT NULL COLLATE pg_catalog."C",
    intent_digest text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    epoch bigint NOT NULL,
    state text DEFAULT 'prepared'::text NOT NULL COLLATE pg_catalog."C",
    receipt_ref text COLLATE pg_catalog."C",
    failure_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_fact_snapshots; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_fact_snapshots (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    mission_revision bigint NOT NULL,
    captured_at text NOT NULL COLLATE pg_catalog."C",
    cells_json text NOT NULL COLLATE pg_catalog."C",
    refs_json text NOT NULL COLLATE pg_catalog."C",
    digest text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: development_feedback_ledger; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_feedback_ledger (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    thread_ref text NOT NULL COLLATE pg_catalog."C",
    revision text NOT NULL COLLATE pg_catalog."C",
    head_sha text NOT NULL COLLATE pg_catalog."C",
    fingerprint text NOT NULL COLLATE pg_catalog."C",
    author_class text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'observed'::text NOT NULL COLLATE pg_catalog."C",
    action_run_id text COLLATE pg_catalog."C",
    reply_effect_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: development_mission_links; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_mission_links (
    id text NOT NULL COLLATE pg_catalog."C",
    parent_mission_id text NOT NULL COLLATE pg_catalog."C",
    parent_step_run_id text NOT NULL COLLATE pg_catalog."C",
    target_repository_id text NOT NULL COLLATE pg_catalog."C",
    target_employee_id text NOT NULL COLLATE pg_catalog."C",
    target_employee_revision bigint NOT NULL,
    input_digest text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    child_mission_id text COLLATE pg_catalog."C",
    completion text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'creating'::text NOT NULL COLLATE pg_catalog."C",
    latest_child_revision bigint,
    latest_status text COLLATE pg_catalog."C",
    completion_satisfied bigint DEFAULT 0 NOT NULL,
    output_ref text COLLATE pg_catalog."C",
    observed_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: development_mission_sources; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_mission_sources (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    generation bigint DEFAULT 1 NOT NULL,
    source_kind text NOT NULL COLLATE pg_catalog."C",
    external_id text COLLATE pg_catalog."C",
    adapter_id text COLLATE pg_catalog."C",
    adapter_revision bigint,
    source_revision text COLLATE pg_catalog."C",
    bundle_ref text COLLATE pg_catalog."C",
    manifest_digest text COLLATE pg_catalog."C",
    file_count bigint,
    total_bytes bigint,
    state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: development_missions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_missions (
    id text NOT NULL COLLATE pg_catalog."C",
    revision bigint DEFAULT 0 NOT NULL,
    epoch bigint DEFAULT 0 NOT NULL,
    status text NOT NULL COLLATE pg_catalog."C",
    automation_mode text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    transition_fence text DEFAULT 'none'::text NOT NULL COLLATE pg_catalog."C",
    repository_id text NOT NULL COLLATE pg_catalog."C",
    source_kind text NOT NULL COLLATE pg_catalog."C",
    source_content_digest text COLLATE pg_catalog."C",
    requested_source_key text COLLATE pg_catalog."C",
    external_id text COLLATE pg_catalog."C",
    resolved_source_key text COLLATE pg_catalog."C",
    resolved_adapter_id text COLLATE pg_catalog."C",
    resolved_adapter_revision bigint,
    delivery_kind text NOT NULL COLLATE pg_catalog."C",
    delivery_target_ref text COLLATE pg_catalog."C",
    delivery_source_branch text COLLATE pg_catalog."C",
    adopted_mr_ref text COLLATE pg_catalog."C",
    assignment_id text COLLATE pg_catalog."C",
    employee_id text COLLATE pg_catalog."C",
    employee_revision bigint,
    policy_id text COLLATE pg_catalog."C",
    policy_revision bigint,
    requirement_bundle_ref text COLLATE pg_catalog."C",
    repository_facts_ref text COLLATE pg_catalog."C",
    upload_plan_ref text COLLATE pg_catalog."C",
    upload_placement_ref text COLLATE pg_catalog."C",
    upload_publication_ref text COLLATE pg_catalog."C",
    mr_claim_id text COLLATE pg_catalog."C",
    current_action_run_id text COLLATE pg_catalog."C",
    readiness_json text COLLATE pg_catalog."C",
    block_code text COLLATE pg_catalog."C",
    block_detail text COLLATE pg_catalog."C",
    terminal_kind text COLLATE pg_catalog."C",
    terminal_upload_fulfillment text COLLATE pg_catalog."C",
    terminal_at bigint,
    reopened_from_mission_id text COLLATE pg_catalog."C",
    launch_idempotency_key text COLLATE pg_catalog."C",
    created_by text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: development_mr_claims; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_mr_claims (
    id text NOT NULL COLLATE pg_catalog."C",
    code_host_endpoint_ref text NOT NULL COLLATE pg_catalog."C",
    stable_project_ref text NOT NULL COLLATE pg_catalog."C",
    mr_iid text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    epoch bigint NOT NULL,
    head_sha text COLLATE pg_catalog."C",
    state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    released_at bigint
);


--
-- Name: development_repository_upload_plan_entries; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_repository_upload_plan_entries (
    plan_id text NOT NULL COLLATE pg_catalog."C",
    ordinal bigint NOT NULL,
    file_id text NOT NULL COLLATE pg_catalog."C",
    upload_blob_ref text NOT NULL COLLATE pg_catalog."C",
    upload_sha256 text NOT NULL COLLATE pg_catalog."C",
    repository_target_path text NOT NULL COLLATE pg_catalog."C",
    content_policy text NOT NULL COLLATE pg_catalog."C",
    target_file_mode text NOT NULL COLLATE pg_catalog."C",
    expected_target_kind text NOT NULL COLLATE pg_catalog."C",
    expected_target_sha256 text COLLATE pg_catalog."C",
    expected_target_file_mode text COLLATE pg_catalog."C"
);


--
-- Name: development_repository_upload_plans; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_repository_upload_plans (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    mission_revision bigint NOT NULL,
    repository_id text NOT NULL COLLATE pg_catalog."C",
    baseline_snapshot_ref text NOT NULL COLLATE pg_catalog."C",
    baseline_sha text NOT NULL COLLATE pg_catalog."C",
    plan_digest text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: development_repository_upload_receipts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_repository_upload_receipts (
    id text NOT NULL COLLATE pg_catalog."C",
    plan_id text NOT NULL COLLATE pg_catalog."C",
    baseline_snapshot_ref text NOT NULL COLLATE pg_catalog."C",
    receipt_kind text NOT NULL COLLATE pg_catalog."C",
    seed_change_ref text COLLATE pg_catalog."C",
    seed_tree_digest text COLLATE pg_catalog."C",
    fulfillment_kind text COLLATE pg_catalog."C",
    commit_sha text COLLATE pg_catalog."C",
    entries_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: development_step_joins; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_step_joins (
    mission_id text NOT NULL COLLATE pg_catalog."C",
    group_id text NOT NULL COLLATE pg_catalog."C",
    member_step_id text NOT NULL COLLATE pg_catalog."C",
    mode text NOT NULL COLLATE pg_catalog."C",
    quorum bigint,
    deadline_at bigint NOT NULL,
    member_state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    receipt_revision text COLLATE pg_catalog."C",
    settled_result text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: development_step_runs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_step_runs (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    employee_id text NOT NULL COLLATE pg_catalog."C",
    employee_revision bigint NOT NULL,
    step_id text NOT NULL COLLATE pg_catalog."C",
    attempt bigint DEFAULT 0 NOT NULL,
    input_digest text NOT NULL COLLATE pg_catalog."C",
    producer_kind text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'claimed'::text NOT NULL COLLATE pg_catalog."C",
    decision_id text COLLATE pg_catalog."C",
    action_run_id text COLLATE pg_catalog."C",
    deadline_at bigint,
    output_ref text COLLATE pg_catalog."C",
    output_revision text COLLATE pg_catalog."C",
    failure_category text COLLATE pg_catalog."C",
    failure_code text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: development_wake_hints; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.development_wake_hints (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    delivery_key text NOT NULL COLLATE pg_catalog."C",
    observed_at bigint NOT NULL,
    consumed_at bigint
);


--
-- Name: digital_employee_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.digital_employee_revisions (
    employee_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: digital_employees; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.digital_employees (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint
);


--
-- Name: doc_versions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.doc_versions (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    review_node_id text NOT NULL COLLATE pg_catalog."C",
    review_node_run_id text NOT NULL COLLATE pg_catalog."C",
    source_node_id text NOT NULL COLLATE pg_catalog."C",
    source_port_name text NOT NULL COLLATE pg_catalog."C",
    version_index bigint NOT NULL,
    review_iteration bigint NOT NULL,
    body_path text NOT NULL COLLATE pg_catalog."C",
    comments_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    decision text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    decision_reason text COLLATE pg_catalog."C",
    prompt_snapshot text COLLATE pg_catalog."C",
    source_file_path text COLLATE pg_catalog."C",
    item_index bigint,
    selection text COLLATE pg_catalog."C",
    item_path text COLLATE pg_catalog."C",
    selection_stale boolean,
    round_generation bigint,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    decided_at bigint,
    decided_by text COLLATE pg_catalog."C",
    decided_by_role text COLLATE pg_catalog."C"
);


--
-- Name: employee_approval_sagas; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_approval_sagas (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    submit_round_id text NOT NULL COLLATE pg_catalog."C",
    adapter_id text NOT NULL COLLATE pg_catalog."C",
    adapter_revision bigint NOT NULL,
    validated_draft_ref text NOT NULL COLLATE pg_catalog."C",
    deadline_at text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    intent_digest text NOT NULL COLLATE pg_catalog."C",
    correlation_ref text COLLATE pg_catalog."C",
    external_request_ref text COLLATE pg_catalog."C",
    submitted_revision text COLLATE pg_catalog."C",
    submitted_at text COLLATE pg_catalog."C",
    latest_status text DEFAULT 'prepared'::text NOT NULL COLLATE pg_catalog."C",
    observed_revision text COLLATE pg_catalog."C",
    evidence_ref text COLLATE pg_catalog."C",
    observed_at text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_attention_bindings; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_attention_bindings (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    context_id text NOT NULL COLLATE pg_catalog."C",
    context_revision bigint NOT NULL,
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    event_type_revision bigint NOT NULL,
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_ref text NOT NULL COLLATE pg_catalog."C",
    desired_identity_key text NOT NULL COLLATE pg_catalog."C",
    event_subscription_id text COLLATE pg_catalog."C",
    state text DEFAULT 'desired'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_case_event_origins; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_case_event_origins (
    case_id text NOT NULL COLLATE pg_catalog."C",
    event_subscription_id text NOT NULL COLLATE pg_catalog."C",
    event_delivery_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: employee_case_inbox; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_case_inbox (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    delivery_id text NOT NULL COLLATE pg_catalog."C",
    event_id text NOT NULL COLLATE pg_catalog."C",
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    event_type_revision bigint NOT NULL,
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_ref text NOT NULL COLLATE pg_catalog."C",
    delivery_class text NOT NULL COLLATE pg_catalog."C",
    priority bigint NOT NULL,
    occurred_at bigint NOT NULL,
    summary text NOT NULL COLLATE pg_catalog."C",
    payload_artifact_ref text COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    round_id text COLLATE pg_catalog."C",
    accepted_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: employee_case_members; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_case_members (
    case_id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL COLLATE pg_catalog."C",
    added_by text NOT NULL COLLATE pg_catalog."C",
    added_at bigint NOT NULL
);


--
-- Name: employee_case_metering_receipts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_case_metering_receipts (
    source_ref text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    round_id text NOT NULL COLLATE pg_catalog."C",
    duration_ms bigint NOT NULL,
    total_tokens bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: employee_case_workspaces; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_case_workspaces (
    case_id text NOT NULL COLLATE pg_catalog."C",
    repository_id text NOT NULL COLLATE pg_catalog."C",
    cached_repo_id text NOT NULL COLLATE pg_catalog."C",
    baseline_sha text NOT NULL COLLATE pg_catalog."C",
    target_branch text NOT NULL COLLATE pg_catalog."C",
    source_branch text NOT NULL COLLATE pg_catalog."C",
    remote_head_sha text COLLATE pg_catalog."C",
    state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_cases; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_cases (
    id text NOT NULL COLLATE pg_catalog."C",
    name text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    employee_id text NOT NULL COLLATE pg_catalog."C",
    employee_revision bigint NOT NULL,
    type_id text NOT NULL COLLATE pg_catalog."C",
    type_revision bigint NOT NULL,
    primary_context_id text NOT NULL COLLATE pg_catalog."C",
    execution_policy_revision bigint NOT NULL,
    max_duration_ms bigint,
    consumed_duration_ms bigint DEFAULT 0 NOT NULL,
    max_total_tokens bigint,
    consumed_total_tokens bigint DEFAULT 0 NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    launch_origin text DEFAULT 'api'::text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    terminal_kind text COLLATE pg_catalog."C",
    block_reason text COLLATE pg_catalog."C",
    current_work_item_ref text COLLATE pg_catalog."C",
    active_round_id text COLLATE pg_catalog."C",
    revision bigint DEFAULT 1 NOT NULL,
    writer_generation bigint DEFAULT 1 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    terminal_at bigint
);


--
-- Name: employee_change_candidates; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_change_candidates (
    candidate_ref text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    round_id text NOT NULL COLLATE pg_catalog."C",
    baseline_sha text NOT NULL COLLATE pg_catalog."C",
    tree_oid text NOT NULL COLLATE pg_catalog."C",
    receipt_json text NOT NULL COLLATE pg_catalog."C",
    summary_source text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'prepared'::text NOT NULL COLLATE pg_catalog."C",
    commit_sha text COLLATE pg_catalog."C",
    push_receipt_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_channel_results; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_channel_results (
    id text NOT NULL COLLATE pg_catalog."C",
    channel_id text NOT NULL COLLATE pg_catalog."C",
    milestone_type text NOT NULL COLLATE pg_catalog."C",
    envelope_json text NOT NULL COLLATE pg_catalog."C",
    envelope_digest text NOT NULL COLLATE pg_catalog."C",
    monotonic boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: employee_channels; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_channels (
    id text NOT NULL COLLATE pg_catalog."C",
    invocation_id text NOT NULL COLLATE pg_catalog."C",
    parent_case_id text NOT NULL COLLATE pg_catalog."C",
    child_case_id text NOT NULL COLLATE pg_catalog."C",
    correlation_ref text NOT NULL COLLATE pg_catalog."C",
    result_contract_ref_json text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'open'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_context_links; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_context_links (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    from_context_id text NOT NULL COLLATE pg_catalog."C",
    relation text NOT NULL COLLATE pg_catalog."C",
    to_context_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: employee_context_records; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_context_records (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    type_id text NOT NULL COLLATE pg_catalog."C",
    schema_version bigint NOT NULL,
    current_revision bigint NOT NULL,
    lifecycle_state text NOT NULL COLLATE pg_catalog."C",
    state_json text NOT NULL COLLATE pg_catalog."C",
    artifact_refs_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_context_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_context_revisions (
    context_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    state_json text NOT NULL COLLATE pg_catalog."C",
    artifact_refs_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: employee_definition_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_definition_revisions (
    employee_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: employee_definitions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_definitions (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    type_id text NOT NULL COLLATE pg_catalog."C",
    type_revision bigint NOT NULL,
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint
);


--
-- Name: employee_execution_policy_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_execution_policy_revisions (
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: employee_external_context_bindings; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_external_context_bindings (
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_ref text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    context_id text NOT NULL COLLATE pg_catalog."C",
    binding_revision bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_input_uploads; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_input_uploads (
    id text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    original_name text NOT NULL COLLATE pg_catalog."C",
    bytes bigint NOT NULL,
    sha256 text NOT NULL COLLATE pg_catalog."C",
    blob_ref text NOT NULL COLLATE pg_catalog."C",
    upload_idempotency_key text COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    claimed_by_case_id text COLLATE pg_catalog."C",
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    claimed_at bigint
);


--
-- Name: employee_invocations; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_invocations (
    id text NOT NULL COLLATE pg_catalog."C",
    idempotency_key text NOT NULL COLLATE pg_catalog."C",
    parent_case_id text NOT NULL COLLATE pg_catalog."C",
    parent_round_id text NOT NULL COLLATE pg_catalog."C",
    target_employee_id text NOT NULL COLLATE pg_catalog."C",
    target_employee_revision bigint NOT NULL,
    target_work_scope_ref_json text NOT NULL COLLATE pg_catalog."C",
    input_envelope_ref text NOT NULL COLLATE pg_catalog."C",
    input_digest text NOT NULL COLLATE pg_catalog."C",
    completion_contract_ref_json text NOT NULL COLLATE pg_catalog."C",
    deadline_at bigint NOT NULL,
    child_case_id text COLLATE pg_catalog."C",
    state text DEFAULT 'requested'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_job_template_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_job_template_revisions (
    template_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: employee_job_templates; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_job_templates (
    id text NOT NULL COLLATE pg_catalog."C",
    type_id text NOT NULL COLLATE pg_catalog."C",
    type_revision bigint NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint
);


--
-- Name: employee_os_outbox; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_os_outbox (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    payload_json text NOT NULL COLLATE pg_catalog."C",
    dedupe_key text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    attempt_count bigint DEFAULT 0 NOT NULL,
    next_attempt_at bigint NOT NULL,
    claimed_by text COLLATE pg_catalog."C",
    claim_expires_at bigint,
    last_error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_os_settings; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_os_settings (
    singleton_key text NOT NULL COLLATE pg_catalog."C",
    execution_policy_revision bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_os_writer_state; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_os_writer_state (
    id text NOT NULL COLLATE pg_catalog."C",
    active_generation bigint NOT NULL,
    mode text NOT NULL COLLATE pg_catalog."C",
    legacy_admissions_enabled boolean NOT NULL,
    legacy_open_mission_count bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_reaction_rounds; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_reaction_rounds (
    id text NOT NULL COLLATE pg_catalog."C",
    case_id text NOT NULL COLLATE pg_catalog."C",
    case_revision bigint NOT NULL,
    inbox_id text COLLATE pg_catalog."C",
    employee_id text NOT NULL COLLATE pg_catalog."C",
    employee_revision bigint NOT NULL,
    rule_id text NOT NULL COLLATE pg_catalog."C",
    work_item_ref text NOT NULL COLLATE pg_catalog."C",
    work_contract_id text NOT NULL COLLATE pg_catalog."C",
    work_contract_version bigint NOT NULL,
    tool_id text COLLATE pg_catalog."C",
    tool_revision bigint,
    execution_policy_revision bigint NOT NULL,
    input_context_refs_json text NOT NULL COLLATE pg_catalog."C",
    plan_json text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'planned'::text NOT NULL COLLATE pg_catalog."C",
    execution_ref text COLLATE pg_catalog."C",
    output_json text COLLATE pg_catalog."C",
    attempt_ordinal bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    settled_at bigint
);


--
-- Name: employee_round_workspace_states; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_round_workspace_states (
    round_id text NOT NULL COLLATE pg_catalog."C",
    attempt_ordinal bigint NOT NULL,
    case_id text NOT NULL COLLATE pg_catalog."C",
    baseline_sha text NOT NULL COLLATE pg_catalog."C",
    pre_state_json text NOT NULL COLLATE pg_catalog."C",
    checkpoint_digest text NOT NULL COLLATE pg_catalog."C",
    validation_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: employee_tool_registration_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_tool_registration_revisions (
    tool_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    validation_receipt_json text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'published'::text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: employee_tool_registrations; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_tool_registrations (
    id text NOT NULL COLLATE pg_catalog."C",
    type_id text NOT NULL COLLATE pg_catalog."C",
    type_revision bigint NOT NULL,
    work_item_ref text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    name text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    retired_at bigint
);


--
-- Name: employee_type_packages; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_type_packages (
    type_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    descriptor_json text NOT NULL COLLATE pg_catalog."C",
    descriptor_digest text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'published'::text NOT NULL COLLATE pg_catalog."C",
    registered_at bigint NOT NULL
);


--
-- Name: employee_work_scope_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.employee_work_scope_revisions (
    scope_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    type_id text NOT NULL COLLATE pg_catalog."C",
    type_revision bigint NOT NULL,
    encoded_scope_json text NOT NULL COLLATE pg_catalog."C",
    display_summary text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    created_by text COLLATE pg_catalog."C"
);


--
-- Name: event_deliveries; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_deliveries (
    id text NOT NULL COLLATE pg_catalog."C",
    event_id text NOT NULL COLLATE pg_catalog."C",
    subscription_id text NOT NULL COLLATE pg_catalog."C",
    subscriber_kind text NOT NULL COLLATE pg_catalog."C",
    subscriber_ref text NOT NULL COLLATE pg_catalog."C",
    delivery_class text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    attempt_count bigint DEFAULT 0 NOT NULL,
    next_attempt_at bigint NOT NULL,
    claimed_by text COLLATE pg_catalog."C",
    claim_expires_at bigint,
    last_error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    accepted_at bigint,
    dead_letter_at bigint
);


--
-- Name: event_observer_runs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_observer_runs (
    id text NOT NULL COLLATE pg_catalog."C",
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    generation bigint NOT NULL,
    lease_epoch bigint NOT NULL,
    wake_epoch bigint NOT NULL,
    cursor_before_json text COLLATE pg_catalog."C",
    cursor_after_json text COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    observation_count bigint DEFAULT 0 NOT NULL,
    started_at bigint NOT NULL,
    finished_at bigint,
    error_code text COLLATE pg_catalog."C",
    error_detail text COLLATE pg_catalog."C"
);


--
-- Name: event_records; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_records (
    id text NOT NULL COLLATE pg_catalog."C",
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    event_type_revision bigint NOT NULL,
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_ref text NOT NULL COLLATE pg_catalog."C",
    occurred_at bigint NOT NULL,
    observed_at bigint NOT NULL,
    dedupe_key text NOT NULL COLLATE pg_catalog."C",
    summary_json text NOT NULL COLLATE pg_catalog."C",
    payload_artifact_ref text COLLATE pg_catalog."C"
);


--
-- Name: event_response_rules; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_response_rules (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    event_type_revision bigint NOT NULL,
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_match text DEFAULT 'all'::text NOT NULL COLLATE pg_catalog."C",
    subject_pattern text COLLATE pg_catalog."C",
    target_json text NOT NULL COLLATE pg_catalog."C",
    last_fired_at bigint,
    last_status text COLLATE pg_catalog."C",
    last_error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: event_sources; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_sources (
    source_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    descriptor_json text NOT NULL COLLATE pg_catalog."C",
    descriptor_digest text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'published'::text NOT NULL COLLATE pg_catalog."C",
    registered_at bigint NOT NULL
);


--
-- Name: event_subscriptions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_subscriptions (
    id text NOT NULL COLLATE pg_catalog."C",
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    event_type_revision bigint NOT NULL,
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    subject_type text NOT NULL COLLATE pg_catalog."C",
    subject_ref text NOT NULL COLLATE pg_catalog."C",
    subscriber_kind text NOT NULL COLLATE pg_catalog."C",
    subscriber_ref text NOT NULL COLLATE pg_catalog."C",
    mode text DEFAULT 'exact'::text NOT NULL COLLATE pg_catalog."C",
    origin_kind text COLLATE pg_catalog."C",
    origin_ref text COLLATE pg_catalog."C",
    definition_revision text COLLATE pg_catalog."C",
    display_name_json text COLLATE pg_catalog."C",
    selector_kind text COLLATE pg_catalog."C",
    selector_json text COLLATE pg_catalog."C",
    active_identity_key text COLLATE pg_catalog."C",
    state text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    cancelled_at bigint
);


--
-- Name: event_type_catalog; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.event_type_catalog (
    event_type_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    descriptor_json text NOT NULL COLLATE pg_catalog."C",
    descriptor_digest text NOT NULL COLLATE pg_catalog."C",
    catalog_visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'published'::text NOT NULL COLLATE pg_catalog."C",
    registered_at bigint NOT NULL
);


--
-- Name: fusions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.fusions (
    id text NOT NULL COLLATE pg_catalog."C",
    skill_id text NOT NULL COLLATE pg_catalog."C",
    skill_name text NOT NULL COLLATE pg_catalog."C",
    base_skill_version bigint NOT NULL,
    precondition_token text COLLATE pg_catalog."C",
    memory_ids_json text NOT NULL COLLATE pg_catalog."C",
    intent text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    status text DEFAULT 'running'::text NOT NULL COLLATE pg_catalog."C",
    iteration bigint DEFAULT 1 NOT NULL,
    current_task_id text COLLATE pg_catalog."C",
    proposed_worktree_path text COLLATE pg_catalog."C",
    proposed_diff text COLLATE pg_catalog."C",
    incorporated_memory_ids_json text COLLATE pg_catalog."C",
    skipped_json text COLLATE pg_catalog."C",
    changelog text COLLATE pg_catalog."C",
    applied_skill_version bigint,
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    decided_by_user_id text COLLATE pg_catalog."C",
    decided_at bigint,
    decision_reason text COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C"
);


--
-- Name: intent_apply_journal; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_apply_journal (
    id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    client_mutation_id text NOT NULL COLLATE pg_catalog."C",
    draft_id text NOT NULL COLLATE pg_catalog."C",
    draft_hash text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'prepared'::text NOT NULL COLLATE pg_catalog."C",
    prepared_artifacts_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    receipt_json text COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: intent_draft_resolutions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_draft_resolutions (
    draft_id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    reason text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: intent_drafts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_drafts (
    id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    changeset_json text NOT NULL COLLATE pg_catalog."C",
    validation_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    draft_hash text NOT NULL COLLATE pg_catalog."C",
    produced_by_turn_id text COLLATE pg_catalog."C",
    context_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: intent_provenance; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_provenance (
    resource_type text NOT NULL COLLATE pg_catalog."C",
    resource_id text NOT NULL COLLATE pg_catalog."C",
    commit_id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: intent_sessions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_sessions (
    id text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    title text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    status text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    context_revision bigint DEFAULT 0 NOT NULL,
    context_manifest_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    handle_watermark_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    current_draft_id text COLLATE pg_catalog."C",
    in_flight_turn_id text COLLATE pg_catalog."C",
    turn_seq bigint DEFAULT 0 NOT NULL,
    commit_seq bigint DEFAULT 0 NOT NULL,
    budget_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: intent_turn_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_turn_events (
    id bigint NOT NULL,
    turn_id text NOT NULL COLLATE pg_catalog."C",
    event_seq bigint NOT NULL,
    ts bigint NOT NULL,
    kind text NOT NULL COLLATE pg_catalog."C",
    payload text NOT NULL COLLATE pg_catalog."C",
    session_id text COLLATE pg_catalog."C",
    parent_session_id text COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    external_event_id text COLLATE pg_catalog."C"
);


--
-- Name: intent_turn_events_id_seq; Type: SEQUENCE; Schema: agent_workflow; Owner: -
--

ALTER TABLE agent_workflow.intent_turn_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME agent_workflow.intent_turn_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: intent_turns; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_turns (
    id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    role text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    content_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    context_revision bigint DEFAULT 0 NOT NULL,
    envelope_nonce text COLLATE pg_catalog."C",
    run_meta_json text COLLATE pg_catalog."C",
    client_mutation_id text COLLATE pg_catalog."C",
    capture_state text COLLATE pg_catalog."C",
    capture_last_event_seq bigint DEFAULT 0 NOT NULL,
    capture_event_bytes bigint DEFAULT 0 NOT NULL,
    capture_root_session_id text COLLATE pg_catalog."C",
    capture_incomplete_reason text COLLATE pg_catalog."C",
    scratch_retained boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: intent_working_set_changes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.intent_working_set_changes (
    id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    client_mutation_id text NOT NULL COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    expected_turn_seq bigint NOT NULL,
    expected_context_revision bigint NOT NULL,
    mode text NOT NULL COLLATE pg_catalog."C",
    delta_json text NOT NULL COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    resulting_context_revision bigint,
    resulting_turn_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: legacy_code_work_item_links; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.legacy_code_work_item_links (
    id text NOT NULL COLLATE pg_catalog."C",
    mission_id text NOT NULL COLLATE pg_catalog."C",
    legacy_work_item_id text COLLATE pg_catalog."C",
    legacy_round_id text COLLATE pg_catalog."C",
    cutover_receipt_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: lifecycle_alerts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.lifecycle_alerts (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    rule text NOT NULL COLLATE pg_catalog."C",
    severity text NOT NULL COLLATE pg_catalog."C",
    detail text NOT NULL COLLATE pg_catalog."C",
    detected_at bigint NOT NULL,
    resolved_at bigint
);


--
-- Name: lifecycle_repair_audit; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.lifecycle_repair_audit (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    alert_id text COLLATE pg_catalog."C",
    alert_rule text NOT NULL COLLATE pg_catalog."C",
    alert_detail_json text NOT NULL COLLATE pg_catalog."C",
    option_id text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    before_snapshot_json text NOT NULL COLLATE pg_catalog."C",
    after_snapshot_json text NOT NULL COLLATE pg_catalog."C",
    outcome text NOT NULL COLLATE pg_catalog."C",
    outcome_message text COLLATE pg_catalog."C",
    applied_at bigint NOT NULL
);


--
-- Name: maintenance_runs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.maintenance_runs (
    id text NOT NULL COLLATE pg_catalog."C",
    job_key text NOT NULL COLLATE pg_catalog."C",
    job_class text NOT NULL COLLATE pg_catalog."C",
    slot_key text NOT NULL COLLATE pg_catalog."C",
    cycle_key text COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    payload_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    cursor_version bigint DEFAULT 1 NOT NULL,
    cursor_json text COLLATE pg_catalog."C",
    lease_token text COLLATE pg_catalog."C",
    lease_expires_at bigint,
    heartbeat_at bigint,
    attempt bigint DEFAULT 0 NOT NULL,
    slice_no bigint DEFAULT 0 NOT NULL,
    counters_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    error_code text COLLATE pg_catalog."C",
    error_message text COLLATE pg_catalog."C",
    scheduled_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint
);


--
-- Name: maintenance_state; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.maintenance_state (
    key text NOT NULL COLLATE pg_catalog."C",
    value text NOT NULL COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: mcp_probes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_probes (
    id text NOT NULL COLLATE pg_catalog."C",
    mcp_id text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    latency_ms bigint NOT NULL,
    handshake_ms bigint,
    server_info_json text COLLATE pg_catalog."C",
    protocol_version text COLLATE pg_catalog."C",
    capabilities_json text COLLATE pg_catalog."C",
    tools_json text COLLATE pg_catalog."C",
    resources_json text COLLATE pg_catalog."C",
    resource_templates_json text COLLATE pg_catalog."C",
    prompts_json text COLLATE pg_catalog."C",
    error_code text COLLATE pg_catalog."C",
    error_message text COLLATE pg_catalog."C",
    error_detail_json text COLLATE pg_catalog."C",
    schema_version bigint DEFAULT 1 NOT NULL,
    started_at bigint NOT NULL,
    finished_at bigint NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: mcp_runtime_test_create_receipts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_runtime_test_create_receipts (
    mcp_id text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    client_create_id text NOT NULL COLLATE pg_catalog."C",
    request_digest text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    accepted_turn_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    CONSTRAINT mcp_runtime_test_create_receipts_shape CHECK (((length(request_digest) = 64) AND (request_digest !~ '[^0-9a-f]'::text) AND (created_at >= 0) AND (expires_at > created_at)))
);


--
-- Name: mcp_runtime_test_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_runtime_test_events (
    id bigint NOT NULL,
    test_session_id text NOT NULL COLLATE pg_catalog."C",
    first_seen_turn_id text NOT NULL COLLATE pg_catalog."C",
    event_seq bigint NOT NULL,
    ts bigint NOT NULL,
    kind text NOT NULL COLLATE pg_catalog."C",
    payload text NOT NULL COLLATE pg_catalog."C",
    session_id text COLLATE pg_catalog."C",
    parent_session_id text COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    external_event_key text COLLATE pg_catalog."C",
    CONSTRAINT mcp_runtime_test_events_shape CHECK (((event_seq > 0) AND (ts >= 0) AND (source = ANY (ARRAY['stream'::text, 'live-child'::text, 'post-run-child'::text])) AND ((external_event_key IS NULL) OR ((length(external_event_key) = 64) AND (external_event_key !~ '[^0-9a-f]'::text)))))
);


--
-- Name: mcp_runtime_test_events_id_seq; Type: SEQUENCE; Schema: agent_workflow; Owner: -
--

ALTER TABLE agent_workflow.mcp_runtime_test_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME agent_workflow.mcp_runtime_test_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mcp_runtime_test_session_leases; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_runtime_test_session_leases (
    protocol text NOT NULL COLLATE pg_catalog."C",
    runtime_session_id text NOT NULL COLLATE pg_catalog."C",
    test_session_id text NOT NULL COLLATE pg_catalog."C",
    created_turn_id text NOT NULL COLLATE pg_catalog."C",
    current_turn_id text NOT NULL COLLATE pg_catalog."C",
    lease_turn_id text COLLATE pg_catalog."C",
    lease_acquired_at bigint,
    lease_nonce_digest text COLLATE pg_catalog."C",
    CONSTRAINT mcp_runtime_test_session_leases_all_or_none CHECK ((((lease_turn_id IS NULL) AND (lease_acquired_at IS NULL) AND (lease_nonce_digest IS NULL)) OR ((lease_turn_id IS NOT NULL) AND (lease_acquired_at IS NOT NULL) AND (lease_nonce_digest IS NOT NULL)))),
    CONSTRAINT mcp_runtime_test_session_leases_shape CHECK (((protocol = ANY (ARRAY['opencode'::text, 'claude-code'::text])) AND ((lease_nonce_digest IS NULL) OR ((length(lease_nonce_digest) = 64) AND (lease_nonce_digest !~ '[^0-9a-f]'::text)))))
);


--
-- Name: mcp_runtime_test_sessions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_runtime_test_sessions (
    id text NOT NULL COLLATE pg_catalog."C",
    mcp_id text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    client_create_id text NOT NULL COLLATE pg_catalog."C",
    client_create_digest text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    end_reason text COLLATE pg_catalog."C",
    mcp_config_hash text NOT NULL COLLATE pg_catalog."C",
    runtime_row_id text NOT NULL COLLATE pg_catalog."C",
    runtime_name text NOT NULL COLLATE pg_catalog."C",
    runtime_protocol text NOT NULL COLLATE pg_catalog."C",
    runtime_snapshot_json text NOT NULL COLLATE pg_catalog."C",
    runtime_binary_path text NOT NULL COLLATE pg_catalog."C",
    runtime_session_id text COLLATE pg_catalog."C",
    native_session_state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    in_flight_turn_id text COLLATE pg_catalog."C",
    turn_seq bigint DEFAULT 0 NOT NULL,
    session_version bigint DEFAULT 0 NOT NULL,
    idle_deadline_at bigint,
    continuation_blocked_reason text COLLATE pg_catalog."C",
    scratch_root text NOT NULL COLLATE pg_catalog."C",
    cleanup_state text DEFAULT 'not-started'::text NOT NULL COLLATE pg_catalog."C",
    cleanup_error_code text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    ended_at bigint,
    CONSTRAINT mcp_runtime_test_sessions_enum_shape CHECK (((status = ANY (ARRAY['active'::text, 'ending'::text, 'ended'::text])) AND (runtime_protocol = ANY (ARRAY['opencode'::text, 'claude-code'::text])) AND (native_session_state = ANY (ARRAY['pending'::text, 'ready'::text, 'unusable'::text])) AND (cleanup_state = ANY (ARRAY['not-started'::text, 'pending'::text, 'complete'::text, 'quarantined'::text])) AND ((end_reason IS NULL) OR (end_reason = ANY (ARRAY['user'::text, 'idle-timeout'::text, 'mcp-deleted'::text, 'mcp-disabled'::text, 'mcp-config-changed'::text, 'access-revoked'::text, 'runtime-disabled'::text, 'runtime-deleted'::text, 'runtime-profile-changed'::text, 'runtime-session-reset'::text, 'capture-truncated'::text, 'capture-incomplete'::text, 'session-unusable'::text]))) AND ((continuation_blocked_reason IS NULL) OR (continuation_blocked_reason = ANY (ARRAY['mcp-config-changed'::text, 'runtime-profile-changed'::text, 'capture-truncated'::text, 'capture-incomplete'::text]))) AND (turn_seq >= 0) AND (session_version >= 0))),
    CONSTRAINT mcp_runtime_test_sessions_hash_shape CHECK (((length(client_create_digest) = 64) AND (client_create_digest !~ '[^0-9a-f]'::text) AND (length(mcp_config_hash) = 64) AND (mcp_config_hash !~ '[^0-9a-f]'::text))),
    CONSTRAINT mcp_runtime_test_sessions_status_shape CHECK ((((status = 'active'::text) AND (end_reason IS NULL) AND (ended_at IS NULL) AND (((in_flight_turn_id IS NOT NULL) AND (idle_deadline_at IS NULL)) OR ((in_flight_turn_id IS NULL) AND (idle_deadline_at IS NOT NULL) AND (native_session_state = 'ready'::text) AND (continuation_blocked_reason IS NULL)))) OR ((status = 'ending'::text) AND (end_reason IS NOT NULL) AND (ended_at IS NULL) AND (idle_deadline_at IS NULL)) OR ((status = 'ended'::text) AND (end_reason IS NOT NULL) AND (ended_at IS NOT NULL) AND (in_flight_turn_id IS NULL) AND (idle_deadline_at IS NULL))))
);


--
-- Name: mcp_runtime_test_turns; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcp_runtime_test_turns (
    id text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    client_message_id text NOT NULL COLLATE pg_catalog."C",
    prompt_text text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    hard_deadline_at bigint NOT NULL,
    capture_state text DEFAULT 'live'::text NOT NULL COLLATE pg_catalog."C",
    capture_incomplete_reason text COLLATE pg_catalog."C",
    capture_first_event_seq bigint,
    capture_last_event_seq bigint DEFAULT 0 NOT NULL,
    capture_event_bytes bigint DEFAULT 0 NOT NULL,
    cancel_requested_at bigint,
    pid bigint,
    spawned_at bigint,
    spawn_binary_path text COLLATE pg_catalog."C",
    exit_code bigint,
    failure_code text COLLATE pg_catalog."C",
    stderr_tail text COLLATE pg_catalog."C",
    duration_ms bigint,
    started_at bigint,
    finished_at bigint,
    created_at bigint NOT NULL,
    CONSTRAINT mcp_runtime_test_turns_counter_shape CHECK (((seq > 0) AND (hard_deadline_at >= created_at) AND (capture_last_event_seq >= 0) AND (capture_event_bytes >= 0) AND ((capture_first_event_seq IS NULL) OR (capture_first_event_seq > 0)) AND ((duration_ms IS NULL) OR (duration_ms >= 0)))),
    CONSTRAINT mcp_runtime_test_turns_enum_shape CHECK (((status = ANY (ARRAY['queued'::text, 'running'::text, 'succeeded'::text, 'failed'::text, 'canceled'::text, 'timed_out'::text, 'interrupted'::text])) AND (capture_state = ANY (ARRAY['live'::text, 'complete'::text, 'truncated'::text, 'incomplete'::text])) AND ((capture_incomplete_reason IS NULL) OR (capture_incomplete_reason = ANY (ARRAY['stream-persist-failed'::text, 'stream-frame-limit-exceeded'::text, 'child-capture-failed'::text, 'post-exit-flush-timeout'::text]))))),
    CONSTRAINT mcp_runtime_test_turns_lifecycle_shape CHECK ((((status = 'queued'::text) AND (started_at IS NULL) AND (finished_at IS NULL)) OR ((status = 'running'::text) AND (started_at IS NOT NULL) AND (finished_at IS NULL)) OR ((status = ANY (ARRAY['succeeded'::text, 'failed'::text, 'canceled'::text, 'timed_out'::text, 'interrupted'::text])) AND (finished_at IS NOT NULL))))
);


--
-- Name: mcps; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mcps (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    type text NOT NULL COLLATE pg_catalog."C",
    config text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: memories; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.memories (
    id text NOT NULL COLLATE pg_catalog."C",
    scope_type text NOT NULL COLLATE pg_catalog."C",
    scope_id text COLLATE pg_catalog."C",
    title text NOT NULL COLLATE pg_catalog."C",
    body_md text NOT NULL COLLATE pg_catalog."C",
    tags text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    source_kind text NOT NULL COLLATE pg_catalog."C",
    source_event_id text COLLATE pg_catalog."C",
    source_task_id text COLLATE pg_catalog."C",
    distill_job_id text COLLATE pg_catalog."C",
    distill_action text COLLATE pg_catalog."C",
    supersedes_id text COLLATE pg_catalog."C",
    superseded_by_id text COLLATE pg_catalog."C",
    approved_by_user_id text COLLATE pg_catalog."C",
    approved_at bigint,
    created_at bigint NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    fused_into_skill text COLLATE pg_catalog."C",
    fused_into_skill_id text COLLATE pg_catalog."C",
    fused_into_skill_version bigint,
    fused_at bigint,
    fused_by_user_id text COLLATE pg_catalog."C",
    fused_fusion_id text COLLATE pg_catalog."C"
);


--
-- Name: memory_distill_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.memory_distill_events (
    id bigint NOT NULL,
    distill_job_id text NOT NULL COLLATE pg_catalog."C",
    attempt_index bigint NOT NULL,
    session_id text NOT NULL COLLATE pg_catalog."C",
    parent_session_id text COLLATE pg_catalog."C",
    ts bigint NOT NULL,
    kind text NOT NULL COLLATE pg_catalog."C",
    payload text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: memory_distill_events_id_seq; Type: SEQUENCE; Schema: agent_workflow; Owner: -
--

ALTER TABLE agent_workflow.memory_distill_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME agent_workflow.memory_distill_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: memory_distill_jobs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.memory_distill_jobs (
    id text NOT NULL COLLATE pg_catalog."C",
    debounce_key text NOT NULL COLLATE pg_catalog."C",
    source_kind text NOT NULL COLLATE pg_catalog."C",
    source_event_id text NOT NULL COLLATE pg_catalog."C",
    task_id text COLLATE pg_catalog."C",
    scope_resolved_json text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    attempts bigint DEFAULT 0 NOT NULL,
    next_run_at bigint NOT NULL,
    last_error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    opencode_session_id text COLLATE pg_catalog."C",
    user_prompt_md text COLLATE pg_catalog."C",
    exit_code bigint,
    stderr_excerpt text COLLATE pg_catalog."C",
    dedup_snapshot_ids_json text COLLATE pg_catalog."C",
    output_lang text COLLATE pg_catalog."C"
);


--
-- Name: memory_scope_move_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.memory_scope_move_events (
    id text NOT NULL COLLATE pg_catalog."C",
    memory_id text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text NOT NULL COLLATE pg_catalog."C",
    actor_source text NOT NULL COLLATE pg_catalog."C",
    from_scope_type text NOT NULL COLLATE pg_catalog."C",
    from_scope_id text COLLATE pg_catalog."C",
    to_scope_type text NOT NULL COLLATE pg_catalog."C",
    to_scope_id text COLLATE pg_catalog."C",
    expected_version bigint NOT NULL,
    resulting_version bigint NOT NULL,
    correlation_id text NOT NULL COLLATE pg_catalog."C",
    causation_id text COLLATE pg_catalog."C",
    occurred_at bigint NOT NULL,
    CONSTRAINT memory_scope_move_events_actor_source CHECK ((actor_source = ANY (ARRAY['session'::text, 'pat'::text, 'daemon'::text, 'cli'::text, 'system'::text]))),
    CONSTRAINT memory_scope_move_events_from_scope CHECK ((((from_scope_type = 'global'::text) AND (from_scope_id IS NULL)) OR ((from_scope_type = ANY (ARRAY['agent'::text, 'workflow'::text, 'repo'::text, 'repo_group'::text])) AND (from_scope_id IS NOT NULL) AND (length(from_scope_id) > 0)))),
    CONSTRAINT memory_scope_move_events_not_noop CHECK (((from_scope_type <> to_scope_type) OR (from_scope_id IS DISTINCT FROM to_scope_id))),
    CONSTRAINT memory_scope_move_events_time_nonnegative CHECK ((occurred_at >= 0)),
    CONSTRAINT memory_scope_move_events_to_scope CHECK ((((to_scope_type = 'global'::text) AND (to_scope_id IS NULL)) OR ((to_scope_type = ANY (ARRAY['agent'::text, 'workflow'::text, 'repo'::text, 'repo_group'::text])) AND (to_scope_id IS NOT NULL) AND (length(to_scope_id) > 0)))),
    CONSTRAINT memory_scope_move_events_version_step CHECK (((expected_version > 0) AND (resulting_version = (expected_version + 1))))
);


--
-- Name: mission_input_uploads; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.mission_input_uploads (
    id text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    original_name text NOT NULL COLLATE pg_catalog."C",
    bytes bigint NOT NULL,
    sha256 text NOT NULL COLLATE pg_catalog."C",
    blob_ref text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'pending'::text NOT NULL COLLATE pg_catalog."C",
    claimed_by_mission_id text COLLATE pg_catalog."C",
    upload_idempotency_key text COLLATE pg_catalog."C",
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    claimed_at bigint
);


--
-- Name: node_run_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.node_run_events (
    id bigint NOT NULL,
    node_run_id text NOT NULL COLLATE pg_catalog."C",
    ts bigint NOT NULL,
    kind text NOT NULL COLLATE pg_catalog."C",
    payload text NOT NULL COLLATE pg_catalog."C",
    session_id text COLLATE pg_catalog."C",
    parent_session_id text COLLATE pg_catalog."C"
);


--
-- Name: node_run_events_id_seq; Type: SEQUENCE; Schema: agent_workflow; Owner: -
--

ALTER TABLE agent_workflow.node_run_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME agent_workflow.node_run_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: node_run_outputs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.node_run_outputs (
    node_run_id text NOT NULL COLLATE pg_catalog."C",
    port_name text NOT NULL COLLATE pg_catalog."C",
    content text NOT NULL COLLATE pg_catalog."C",
    kind text COLLATE pg_catalog."C",
    archive_json text COLLATE pg_catalog."C",
    active boolean DEFAULT true NOT NULL
);


--
-- Name: node_runs; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.node_runs (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    node_id text NOT NULL COLLATE pg_catalog."C",
    parent_node_run_id text COLLATE pg_catalog."C",
    container_run_id text COLLATE pg_catalog."C",
    scope_path text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    iteration bigint DEFAULT 0 NOT NULL,
    shard_key text COLLATE pg_catalog."C",
    retry_index bigint DEFAULT 0 NOT NULL,
    wg_round bigint,
    review_iteration bigint DEFAULT 0 NOT NULL,
    status text NOT NULL COLLATE pg_catalog."C",
    started_at bigint,
    finished_at bigint,
    pid bigint,
    spawn_binary_path text COLLATE pg_catalog."C",
    spawn_launch_nonce text COLLATE pg_catalog."C",
    exit_code bigint,
    error_message text COLLATE pg_catalog."C",
    failure_code text COLLATE pg_catalog."C",
    prompt_text text COLLATE pg_catalog."C",
    prompt_path text COLLATE pg_catalog."C",
    envelope_nonce text COLLATE pg_catalog."C",
    force_activated boolean DEFAULT false NOT NULL,
    tok_input bigint,
    tok_output bigint,
    tok_cache_create bigint,
    tok_cache_read bigint,
    tok_total bigint,
    pre_snapshot text COLLATE pg_catalog."C",
    opencode_session_id text COLLATE pg_catalog."C",
    runtime text COLLATE pg_catalog."C",
    runtime_binary text COLLATE pg_catalog."C",
    runtime_params_json text COLLATE pg_catalog."C",
    inventory_snapshot_json text COLLATE pg_catalog."C",
    runtime_inventory_json text COLLATE pg_catalog."C",
    startup_verification_json text COLLATE pg_catalog."C",
    wrapper_progress_json text COLLATE pg_catalog."C",
    injected_memories_json text COLLATE pg_catalog."C",
    port_validation_failures_json text COLLATE pg_catalog."C",
    commit_push_json text COLLATE pg_catalog."C",
    pre_snapshot_repos_json text COLLATE pg_catalog."C",
    iso_worktree_path text COLLATE pg_catalog."C",
    iso_base_snapshot text COLLATE pg_catalog."C",
    iso_base_snapshot_repos_json text COLLATE pg_catalog."C",
    iso_node_tree text COLLATE pg_catalog."C",
    iso_node_tree_repos_json text COLLATE pg_catalog."C",
    iso_submodules_json text COLLATE pg_catalog."C",
    iso_submodules_repos_json text COLLATE pg_catalog."C",
    merge_state text COLLATE pg_catalog."C",
    consumed_upstream_runs_json text COLLATE pg_catalog."C",
    shard_value_hash text COLLATE pg_catalog."C",
    rerun_cause text COLLATE pg_catalog."C",
    superseded_by_review text COLLATE pg_catalog."C",
    rolled_back boolean,
    agent_override_name text COLLATE pg_catalog."C",
    agent_override_id text COLLATE pg_catalog."C",
    child_task_id text COLLATE pg_catalog."C",
    continuation_slot_key text COLLATE pg_catalog."C",
    lineage_slot_path_json text COLLATE pg_catalog."C",
    operation_generation bigint DEFAULT 0 NOT NULL
);


--
-- Name: observer_activations; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.observer_activations (
    source_id text NOT NULL COLLATE pg_catalog."C",
    source_revision bigint NOT NULL,
    subscriber_count bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'idle'::text NOT NULL COLLATE pg_catalog."C",
    generation bigint DEFAULT 0 NOT NULL,
    wake_epoch bigint DEFAULT 0 NOT NULL,
    cursor_json text COLLATE pg_catalog."C",
    lease_owner text COLLATE pg_catalog."C",
    lease_epoch bigint DEFAULT 0 NOT NULL,
    lease_expires_at bigint,
    next_scan_at bigint,
    last_scan_at bigint,
    last_success_at bigint,
    last_error_code text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: oidc_providers; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.oidc_providers (
    id text NOT NULL COLLATE pg_catalog."C",
    slug text NOT NULL COLLATE pg_catalog."C",
    display_name text NOT NULL COLLATE pg_catalog."C",
    issuer_url text NOT NULL COLLATE pg_catalog."C",
    client_id text NOT NULL COLLATE pg_catalog."C",
    client_secret_enc text NOT NULL COLLATE pg_catalog."C",
    scopes text DEFAULT 'openid profile email'::text NOT NULL COLLATE pg_catalog."C",
    provisioning text DEFAULT 'invite'::text NOT NULL COLLATE pg_catalog."C",
    allowed_email_domains_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    icon_url text COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    authorization_endpoint text COLLATE pg_catalog."C",
    token_endpoint text COLLATE pg_catalog."C",
    userinfo_endpoint text COLLATE pg_catalog."C",
    userinfo_request_style text DEFAULT 'get_bearer'::text NOT NULL COLLATE pg_catalog."C",
    jwks_uri text COLLATE pg_catalog."C",
    trust_email_verified boolean DEFAULT false NOT NULL,
    username_claim text COLLATE pg_catalog."C",
    git_name_claim text COLLATE pg_catalog."C",
    email_claim text COLLATE pg_catalog."C",
    subject_claim text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL
);


--
-- Name: plugins; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.plugins (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    spec text NOT NULL COLLATE pg_catalog."C",
    options_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    source_kind text NOT NULL COLLATE pg_catalog."C",
    cached_path text NOT NULL COLLATE pg_catalog."C",
    resolved_version text COLLATE pg_catalog."C",
    installed_at bigint NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: recovery_events; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.recovery_events (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text COLLATE pg_catalog."C",
    node_run_id text COLLATE pg_catalog."C",
    actor text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    reason text COLLATE pg_catalog."C",
    before_json text COLLATE pg_catalog."C",
    after_json text COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: repo_capability_config; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.repo_capability_config (
    id text NOT NULL COLLATE pg_catalog."C",
    repo_id text NOT NULL COLLATE pg_catalog."C",
    capability text NOT NULL COLLATE pg_catalog."C",
    template_id text COLLATE pg_catalog."C",
    enabled boolean DEFAULT false NOT NULL,
    trigger_config_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    readiness text DEFAULT 'disabled'::text NOT NULL COLLATE pg_catalog."C",
    readiness_issues_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    dependency_revision bigint DEFAULT 0 NOT NULL,
    last_validated_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: repo_group_nodes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.repo_group_nodes (
    group_id text NOT NULL COLLATE pg_catalog."C",
    path text NOT NULL COLLATE pg_catalog."C",
    attachment_kind text COLLATE pg_catalog."C",
    cached_repo_id text COLLATE pg_catalog."C",
    ref text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    subdir text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    child_group_id text COLLATE pg_catalog."C",
    readonly boolean DEFAULT false NOT NULL
);


--
-- Name: repo_groups; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.repo_groups (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    version bigint DEFAULT 1 NOT NULL,
    created_by_user_id text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL
);


--
-- Name: repository_employee_assignments; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.repository_employee_assignments (
    id text NOT NULL COLLATE pg_catalog."C",
    scope_kind text NOT NULL COLLATE pg_catalog."C",
    scope_ref text COLLATE pg_catalog."C",
    employee_id text COLLATE pg_catalog."C",
    employee_revision bigint,
    selection_policy_id text COLLATE pg_catalog."C",
    selection_policy_revision bigint,
    execution_policy_id text COLLATE pg_catalog."C",
    execution_policy_revision bigint,
    default_requirement_source_key text COLLATE pg_catalog."C",
    updated_by text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: repository_transport_connections; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.repository_transport_connections (
    provider text NOT NULL COLLATE pg_catalog."C",
    connection_generation text NOT NULL COLLATE pg_catalog."C",
    endpoint_binding_digest text NOT NULL COLLATE pg_catalog."C",
    api_base_url text NOT NULL COLLATE pg_catalog."C",
    reject_unauthorized boolean NOT NULL,
    transport_mappings_json text NOT NULL COLLATE pg_catalog."C",
    allowed_http_base_urls_json text NOT NULL COLLATE pg_catalog."C",
    global_token_enc text NOT NULL COLLATE pg_catalog."C",
    global_token_hint text NOT NULL COLLATE pg_catalog."C",
    credential_revision bigint DEFAULT 1 NOT NULL,
    updated_at bigint NOT NULL,
    updated_by text COLLATE pg_catalog."C",
    CONSTRAINT repository_transport_connections_generation_length CHECK (((length(connection_generation) >= 1) AND (length(connection_generation) <= 128)))
);


--
-- Name: resource_bundle_applies; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.resource_bundle_applies (
    id text NOT NULL COLLATE pg_catalog."C",
    scope text NOT NULL COLLATE pg_catalog."C",
    key text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text NOT NULL COLLATE pg_catalog."C",
    state text DEFAULT 'prepared'::text NOT NULL COLLATE pg_catalog."C",
    prepared_artifacts_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    receipt_json text COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: resource_grants; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.resource_grants (
    resource_type text NOT NULL COLLATE pg_catalog."C",
    resource_id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    added_by text NOT NULL COLLATE pg_catalog."C",
    added_at bigint NOT NULL,
    level text DEFAULT 'read'::text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: review_comments; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.review_comments (
    id text NOT NULL COLLATE pg_catalog."C",
    doc_version_id text NOT NULL COLLATE pg_catalog."C",
    anchor_section_path text NOT NULL COLLATE pg_catalog."C",
    anchor_paragraph_idx bigint NOT NULL,
    anchor_offset_start bigint NOT NULL,
    anchor_offset_end bigint NOT NULL,
    selected_text text NOT NULL COLLATE pg_catalog."C",
    context_before text NOT NULL COLLATE pg_catalog."C",
    context_after text NOT NULL COLLATE pg_catalog."C",
    occurrence_index bigint NOT NULL,
    comment_text text NOT NULL COLLATE pg_catalog."C",
    author text DEFAULT 'local'::text NOT NULL COLLATE pg_catalog."C",
    author_role text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: review_node_reviewers; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.review_node_reviewers (
    task_id text NOT NULL COLLATE pg_catalog."C",
    review_node_id text NOT NULL COLLATE pg_catalog."C",
    reviewer_user_id text NOT NULL COLLATE pg_catalog."C",
    assigned_by_user_id text NOT NULL COLLATE pg_catalog."C",
    assigned_at bigint NOT NULL
);


--
-- Name: runtime_session_leases; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.runtime_session_leases (
    protocol text NOT NULL COLLATE pg_catalog."C",
    session_id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    node_id text NOT NULL COLLATE pg_catalog."C",
    created_node_run_id text NOT NULL COLLATE pg_catalog."C",
    lease_node_run_id text COLLATE pg_catalog."C",
    lease_nonce_digest text COLLATE pg_catalog."C",
    leased_at bigint,
    reset_pending boolean DEFAULT false NOT NULL,
    CONSTRAINT runtime_session_leases_all_or_none CHECK ((((lease_node_run_id IS NULL) AND (lease_nonce_digest IS NULL) AND (leased_at IS NULL)) OR ((lease_node_run_id IS NOT NULL) AND (lease_nonce_digest IS NOT NULL) AND (leased_at IS NOT NULL)))),
    CONSTRAINT runtime_session_leases_protocol_shape CHECK ((protocol = ANY (ARRAY['opencode'::text, 'claude-code'::text]))),
    CONSTRAINT runtime_session_leases_reset_pending_held CHECK (((reset_pending = false) OR (lease_node_run_id IS NOT NULL))),
    CONSTRAINT runtime_session_leases_reset_pending_shape CHECK ((reset_pending = ANY (ARRAY[false, true])))
);


--
-- Name: runtimes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.runtimes (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    protocol text NOT NULL COLLATE pg_catalog."C",
    binary_path text COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    model text COLLATE pg_catalog."C",
    variant text COLLATE pg_catalog."C",
    temperature double precision,
    steps bigint,
    max_steps bigint,
    is_sandbox boolean DEFAULT false NOT NULL,
    config_dir_env text COLLATE pg_catalog."C",
    config_dir_name text COLLATE pg_catalog."C",
    extra_args_json text COLLATE pg_catalog."C",
    last_probe_json text COLLATE pg_catalog."C",
    probe_fence bigint DEFAULT 0 NOT NULL,
    created_by text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: scheduled_tasks; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.scheduled_tasks (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    launch_kind text DEFAULT 'workflow'::text NOT NULL COLLATE pg_catalog."C",
    launch_payload text NOT NULL COLLATE pg_catalog."C",
    schedule_spec text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    next_run_at bigint,
    last_run_at bigint,
    last_status text COLLATE pg_catalog."C",
    last_error text COLLATE pg_catalog."C",
    last_task_id text COLLATE pg_catalog."C",
    consecutive_failures bigint DEFAULT 0 NOT NULL,
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: skill_operation_locks; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.skill_operation_locks (
    locked_skill_id text NOT NULL COLLATE pg_catalog."C",
    op_id text NOT NULL COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: skill_operations; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.skill_operations (
    op_id text NOT NULL COLLATE pg_catalog."C",
    skill_id text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    phase text NOT NULL COLLATE pg_catalog."C",
    active bigint DEFAULT 1 NOT NULL,
    staging_path text COLLATE pg_catalog."C",
    backup_path text COLLATE pg_catalog."C",
    candidate_path text COLLATE pg_catalog."C",
    candidate_fingerprint text COLLATE pg_catalog."C",
    backup_fingerprint text COLLATE pg_catalog."C",
    target_version bigint,
    generation bigint,
    owner_user_id text COLLATE pg_catalog."C",
    precondition_json text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: skill_versions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.skill_versions (
    id text NOT NULL COLLATE pg_catalog."C",
    skill_id text NOT NULL COLLATE pg_catalog."C",
    version_index bigint NOT NULL,
    files_path text NOT NULL COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    summary text COLLATE pg_catalog."C",
    fusion_id text COLLATE pg_catalog."C",
    restored_from_version bigint,
    author_user_id text COLLATE pg_catalog."C",
    content_hash text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: skills; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.skills (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    managed_path text COLLATE pg_catalog."C",
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    schema_version bigint DEFAULT 1 NOT NULL,
    content_version bigint DEFAULT 1 NOT NULL,
    acl_revision bigint DEFAULT 0 NOT NULL,
    meta_revision bigint DEFAULT 0 NOT NULL,
    reservation_state text DEFAULT 'ready'::text NOT NULL COLLATE pg_catalog."C",
    version_state text DEFAULT 'legacy-unbackfilled'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: task_archive_audit; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_archive_audit (
    id text NOT NULL COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    retention_days bigint NOT NULL,
    tree_count bigint NOT NULL,
    task_count bigint NOT NULL,
    skipped_count bigint NOT NULL,
    root_task_ids_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: task_collaborators; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_collaborators (
    task_id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL COLLATE pg_catalog."C",
    added_by text NOT NULL COLLATE pg_catalog."C",
    added_at bigint NOT NULL
);


--
-- Name: task_execution_effect_attempts; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_effect_attempts (
    id text NOT NULL COLLATE pg_catalog."C",
    effect_id text NOT NULL COLLATE pg_catalog."C",
    attempt_no bigint NOT NULL,
    intent_id text NOT NULL COLLATE pg_catalog."C",
    epoch bigint NOT NULL,
    state text NOT NULL COLLATE pg_catalog."C",
    candidate_id text NOT NULL COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    recovery_class text NOT NULL COLLATE pg_catalog."C",
    recovery_descriptor_json text COLLATE pg_catalog."C",
    classifier_version text NOT NULL COLLATE pg_catalog."C",
    transport_policy_version text NOT NULL COLLATE pg_catalog."C",
    application_evidence text COLLATE pg_catalog."C",
    retry_authority text DEFAULT 'none'::text NOT NULL COLLATE pg_catalog."C",
    receipt_json text COLLATE pg_catalog."C",
    failure_code text COLLATE pg_catalog."C",
    prepared_at bigint NOT NULL,
    acting_at bigint,
    settled_at bigint,
    updated_at bigint NOT NULL,
    CONSTRAINT task_execution_attempts_epoch_positive CHECK ((epoch > 0)),
    CONSTRAINT task_execution_attempts_no_positive CHECK ((attempt_no > 0))
);


--
-- Name: task_execution_effect_fences; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_effect_fences (
    effect_attempt_id text NOT NULL COLLATE pg_catalog."C",
    fence_key text NOT NULL COLLATE pg_catalog."C",
    acquired_epoch bigint NOT NULL,
    acquired_at bigint NOT NULL,
    released_at bigint,
    CONSTRAINT task_execution_effect_fences_epoch_positive CHECK ((acquired_epoch > 0))
);


--
-- Name: task_execution_effects; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_effects (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    origin_intent_id text NOT NULL COLLATE pg_catalog."C",
    current_intent_id text NOT NULL COLLATE pg_catalog."C",
    operation_key text NOT NULL COLLATE pg_catalog."C",
    execution_lineage_id text NOT NULL COLLATE pg_catalog."C",
    operation_family_key text NOT NULL COLLATE pg_catalog."C",
    operation_generation bigint NOT NULL,
    kind text NOT NULL COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    slot_path_json text NOT NULL COLLATE pg_catalog."C",
    slot_path_digest text NOT NULL COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    last_attempt_no bigint DEFAULT 0 NOT NULL,
    receipt_json text COLLATE pg_catalog."C",
    failure_code text COLLATE pg_catalog."C",
    prepared_at bigint NOT NULL,
    settled_at bigint,
    updated_at bigint NOT NULL,
    CONSTRAINT task_execution_effects_generation_nonnegative CHECK ((operation_generation >= 0))
);


--
-- Name: task_execution_intents; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_intents (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    payload_json text DEFAULT '{}'::text NOT NULL COLLATE pg_catalog."C",
    execution_lineage_id text NOT NULL COLLATE pg_catalog."C",
    continuation_slot_key text NOT NULL COLLATE pg_catalog."C",
    slot_path_json text NOT NULL COLLATE pg_catalog."C",
    operation_generation bigint DEFAULT 0 NOT NULL,
    replay_authorization_id text COLLATE pg_catalog."C",
    authorization_scope_json text COLLATE pg_catalog."C",
    expected_task_revision bigint NOT NULL,
    claimed_epoch bigint,
    failure_code text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    claimed_at bigint,
    completed_at bigint,
    updated_at bigint NOT NULL,
    CONSTRAINT task_execution_intents_generation_nonnegative CHECK ((operation_generation >= 0))
);


--
-- Name: task_execution_lineage_operation_records; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_lineage_operation_records (
    id text NOT NULL COLLATE pg_catalog."C",
    record_kind text NOT NULL COLLATE pg_catalog."C",
    execution_lineage_id text NOT NULL COLLATE pg_catalog."C",
    operation_family_key text NOT NULL COLLATE pg_catalog."C",
    operation_generation bigint,
    highest_settled_generation bigint,
    last_outcome text COLLATE pg_catalog."C",
    request_hash text NOT NULL COLLATE pg_catalog."C",
    slot_path_json text NOT NULL COLLATE pg_catalog."C",
    slot_path_digest text NOT NULL COLLATE pg_catalog."C",
    root_anchor_task_id text COLLATE pg_catalog."C",
    ancestor_anchor_task_id text COLLATE pg_catalog."C",
    current_anchor_task_id text COLLATE pg_catalog."C",
    source_task_id text COLLATE pg_catalog."C",
    source_effect_id text COLLATE pg_catalog."C",
    source_attempt_id text COLLATE pg_catalog."C",
    provider_coordinate_json text COLLATE pg_catalog."C",
    failure_code text COLLATE pg_catalog."C",
    decision_state text COLLATE pg_catalog."C",
    replay_authorization_id text COLLATE pg_catalog."C",
    authorization_scope_json text COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    authorization_source text COLLATE pg_catalog."C",
    bound_intent_id text COLLATE pg_catalog."C",
    new_effect_id text COLLATE pg_catalog."C",
    record_revision bigint NOT NULL,
    compacted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT task_execution_lineage_record_shape CHECK ((((record_kind = 'generation-watermark'::text) AND (highest_settled_generation IS NOT NULL) AND (operation_generation IS NULL) AND (decision_state IS NULL)) OR ((record_kind = 'replay-decision'::text) AND (operation_generation IS NOT NULL) AND (highest_settled_generation IS NULL) AND (decision_state IS NOT NULL)))),
    CONSTRAINT task_execution_lineage_revision_positive CHECK ((record_revision > 0))
);


--
-- Name: task_execution_maintenance_claims; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_maintenance_claims (
    id text NOT NULL COLLATE pg_catalog."C",
    root_task_id text NOT NULL COLLATE pg_catalog."C",
    operation text NOT NULL COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    member_set_digest text NOT NULL COLLATE pg_catalog."C",
    expected_tree_digest text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    cleanup_plan_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    completed_at bigint,
    CONSTRAINT task_execution_maintenance_revision_positive CHECK ((revision > 0))
);


--
-- Name: task_execution_maintenance_members; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_maintenance_members (
    claim_id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    expected_task_revision bigint NOT NULL,
    expected_owner_revision bigint,
    expected_topology_revision bigint NOT NULL,
    expected_ledger_digest text NOT NULL COLLATE pg_catalog."C",
    released_at bigint
);


--
-- Name: task_execution_owners; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_execution_owners (
    task_id text NOT NULL COLLATE pg_catalog."C",
    owner_id text NOT NULL COLLATE pg_catalog."C",
    daemon_generation text NOT NULL COLLATE pg_catalog."C",
    epoch bigint NOT NULL,
    state text NOT NULL COLLATE pg_catalog."C",
    lease_until bigint NOT NULL,
    revision bigint NOT NULL,
    last_heartbeat_at bigint NOT NULL,
    recovery_code text COLLATE pg_catalog."C",
    recovery_proof_digest text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL,
    CONSTRAINT task_execution_owners_epoch_positive CHECK ((epoch > 0)),
    CONSTRAINT task_execution_owners_revision_positive CHECK ((revision > 0))
);


--
-- Name: task_feedback; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_feedback (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    author_user_id text COLLATE pg_catalog."C",
    body_md text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    distilled bigint DEFAULT 0 NOT NULL,
    distill_job_id text COLLATE pg_catalog."C"
);


--
-- Name: task_node_clarify_directives; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_node_clarify_directives (
    task_id text NOT NULL COLLATE pg_catalog."C",
    node_id text NOT NULL COLLATE pg_catalog."C",
    shard_key text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    directive text NOT NULL COLLATE pg_catalog."C",
    set_by text COLLATE pg_catalog."C",
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: task_questions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_questions (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    origin_node_run_id text NOT NULL COLLATE pg_catalog."C",
    question_id text NOT NULL COLLATE pg_catalog."C",
    question_title text NOT NULL COLLATE pg_catalog."C",
    source_kind text NOT NULL COLLATE pg_catalog."C",
    role_kind text NOT NULL COLLATE pg_catalog."C",
    iteration bigint DEFAULT 0 NOT NULL,
    loop_iter bigint DEFAULT 0 NOT NULL,
    default_target_node_id text COLLATE pg_catalog."C",
    override_target_node_id text COLLATE pg_catalog."C",
    dispatched_at bigint,
    dispatched_by text COLLATE pg_catalog."C",
    trigger_run_id text COLLATE pg_catalog."C",
    staged_at bigint,
    staged_by text COLLATE pg_catalog."C",
    auto_dispatch_deferred_at bigint,
    sealed_at bigint,
    sealed_by text COLLATE pg_catalog."C",
    confirmation text DEFAULT 'open'::text NOT NULL COLLATE pg_catalog."C",
    confirmed_by text COLLATE pg_catalog."C",
    confirmed_by_role text COLLATE pg_catalog."C",
    confirmed_at bigint,
    last_reassigned_by text COLLATE pg_catalog."C",
    last_reassigned_at bigint,
    manual_body text COLLATE pg_catalog."C",
    manual_created_by text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: task_repos; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_repos (
    task_id text NOT NULL COLLATE pg_catalog."C",
    repo_index bigint NOT NULL,
    repo_path text NOT NULL COLLATE pg_catalog."C",
    repo_url text COLLATE pg_catalog."C",
    cached_repo_id text COLLATE pg_catalog."C",
    base_branch text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    branch text NOT NULL COLLATE pg_catalog."C",
    working_branch text COLLATE pg_catalog."C",
    base_commit text COLLATE pg_catalog."C",
    worktree_path text NOT NULL COLLATE pg_catalog."C",
    worktree_dir_name text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    mount_path text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    subdir text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    readonly boolean DEFAULT false NOT NULL,
    readonly_dirty_count bigint,
    workspace_profile_version bigint,
    workspace_profile_digest text COLLATE pg_catalog."C",
    has_submodules boolean,
    submodule_init_ok boolean,
    submodule_init_error text COLLATE pg_catalog."C",
    schema_version bigint DEFAULT 1 NOT NULL
);


--
-- Name: task_space_nodes; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.task_space_nodes (
    task_id text NOT NULL COLLATE pg_catalog."C",
    node_path text NOT NULL COLLATE pg_catalog."C",
    schema_version bigint DEFAULT 1 NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.tasks (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    workflow_id text NOT NULL COLLATE pg_catalog."C",
    workflow_snapshot text NOT NULL COLLATE pg_catalog."C",
    workflow_version bigint,
    repo_path text NOT NULL COLLATE pg_catalog."C",
    repo_url text COLLATE pg_catalog."C",
    cached_repo_id text COLLATE pg_catalog."C",
    repo_group_id text COLLATE pg_catalog."C",
    repo_group_name text COLLATE pg_catalog."C",
    worktree_path text NOT NULL COLLATE pg_catalog."C",
    base_branch text NOT NULL COLLATE pg_catalog."C",
    branch text NOT NULL COLLATE pg_catalog."C",
    base_commit text COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    inputs text NOT NULL COLLATE pg_catalog."C",
    max_duration_ms bigint,
    max_total_tokens bigint,
    started_at bigint NOT NULL,
    running_ms bigint DEFAULT 0 NOT NULL,
    running_since bigint,
    finished_at bigint,
    error_summary text COLLATE pg_catalog."C",
    error_message text COLLATE pg_catalog."C",
    failed_node_id text COLLATE pg_catalog."C",
    auto_recovery_attempts bigint DEFAULT 0 NOT NULL,
    auto_recovery_suspended boolean DEFAULT false NOT NULL,
    auto_recovery_window_started_at bigint,
    expires_at bigint,
    deleted_at bigint,
    schema_version bigint DEFAULT 1 NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    launch_origin text DEFAULT 'manual'::text NOT NULL COLLATE pg_catalog."C",
    catalog_visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    git_user_name text COLLATE pg_catalog."C",
    git_user_email text COLLATE pg_catalog."C",
    working_branch text COLLATE pg_catalog."C",
    auto_commit_push boolean DEFAULT false NOT NULL,
    repo_count bigint DEFAULT 1 NOT NULL,
    scheduled_task_id text COLLATE pg_catalog."C",
    webhook_trigger_id text COLLATE pg_catalog."C",
    webhook_fire_id text COLLATE pg_catalog."C",
    event_subscription_id text COLLATE pg_catalog."C",
    event_delivery_id text COLLATE pg_catalog."C",
    lifecycle_event_revision bigint DEFAULT 1 NOT NULL,
    source_termination_binding text COLLATE pg_catalog."C",
    source_termination_launch_rev bigint,
    source_termination_fence text COLLATE pg_catalog."C",
    source_termination_effect_rev bigint,
    workgroup_id text COLLATE pg_catalog."C",
    workgroup_config_json text COLLATE pg_catalog."C",
    space_kind text DEFAULT 'remote'::text NOT NULL COLLATE pg_catalog."C",
    source_agent_name text COLLATE pg_catalog."C",
    code_round_id text COLLATE pg_catalog."C",
    digital_employee_round_id text COLLATE pg_catalog."C",
    digital_employee_case_id text COLLATE pg_catalog."C",
    source_agent_id text COLLATE pg_catalog."C",
    workspace_pruning_at bigint,
    workspace_prune_cause text COLLATE pg_catalog."C",
    workspace_pruned_at bigint,
    parent_task_id text COLLATE pg_catalog."C",
    parent_node_run_id text COLLATE pg_catalog."C",
    invocation_depth bigint DEFAULT 0 NOT NULL,
    ref_closure_json text COLLATE pg_catalog."C",
    trigger_context_json text COLLATE pg_catalog."C",
    platform_input_paths_json text COLLATE pg_catalog."C",
    branch_started_at bigint DEFAULT 0 NOT NULL,
    root_task_id text COLLATE pg_catalog."C",
    execution_lineage_id text COLLATE pg_catalog."C",
    lineage_slot_path_json text COLLATE pg_catalog."C"
);


--
-- Name: token_audit; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.token_audit (
    id text NOT NULL COLLATE pg_catalog."C",
    pat_id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    channel text NOT NULL COLLATE pg_catalog."C",
    tool_name text COLLATE pg_catalog."C",
    method text COLLATE pg_catalog."C",
    path text COLLATE pg_catalog."C",
    resource_kind text COLLATE pg_catalog."C",
    resource_id text COLLATE pg_catalog."C",
    status_code bigint NOT NULL,
    snapshot_failed boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: token_delete_snapshot; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.token_delete_snapshot (
    id text NOT NULL COLLATE pg_catalog."C",
    audit_id text NOT NULL COLLATE pg_catalog."C",
    resource_kind text NOT NULL COLLATE pg_catalog."C",
    resource_id text NOT NULL COLLATE pg_catalog."C",
    snapshot_json text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL
);


--
-- Name: user_access_audit; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_access_audit (
    id text NOT NULL COLLATE pg_catalog."C",
    target_user_id text NOT NULL COLLATE pg_catalog."C",
    actor_user_id text COLLATE pg_catalog."C",
    actor_kind text NOT NULL COLLATE pg_catalog."C",
    operation_id text NOT NULL COLLATE pg_catalog."C",
    correlation_id text COLLATE pg_catalog."C",
    before_role text NOT NULL COLLATE pg_catalog."C",
    after_role text NOT NULL COLLATE pg_catalog."C",
    added_permissions_json text NOT NULL COLLATE pg_catalog."C",
    removed_permissions_json text NOT NULL COLLATE pg_catalog."C",
    access_revision bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: user_identities; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_identities (
    id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    provider_id text NOT NULL COLLATE pg_catalog."C",
    subject text NOT NULL COLLATE pg_catalog."C",
    email text COLLATE pg_catalog."C",
    email_verified bigint DEFAULT 0 NOT NULL,
    preferred_snapshot text COLLATE pg_catalog."C",
    linked_at bigint NOT NULL
);


--
-- Name: user_pats; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_pats (
    id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    token_hash text NOT NULL COLLATE pg_catalog."C",
    scopes_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    last_used_at bigint,
    expires_at bigint,
    revoked_at bigint,
    purpose text DEFAULT 'general'::text NOT NULL COLLATE pg_catalog."C"
);


--
-- Name: user_permission_grants; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_permission_grants (
    user_id text NOT NULL COLLATE pg_catalog."C",
    permission text NOT NULL COLLATE pg_catalog."C",
    granted_by_user_id text COLLATE pg_catalog."C",
    granted_at bigint NOT NULL
);


--
-- Name: user_repository_transport_credentials; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_repository_transport_credentials (
    user_id text NOT NULL COLLATE pg_catalog."C",
    provider text NOT NULL COLLATE pg_catalog."C",
    connection_generation text NOT NULL COLLATE pg_catalog."C",
    endpoint_binding_digest text NOT NULL COLLATE pg_catalog."C",
    token_enc text NOT NULL COLLATE pg_catalog."C",
    token_hint text NOT NULL COLLATE pg_catalog."C",
    credential_revision bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.user_sessions (
    id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    token_hash text NOT NULL COLLATE pg_catalog."C",
    user_agent text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    last_used_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    revoked_at bigint
);


--
-- Name: users; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.users (
    id text NOT NULL COLLATE pg_catalog."C",
    username text NOT NULL COLLATE pg_catalog."C",
    email text COLLATE pg_catalog."C",
    display_name text NOT NULL COLLATE pg_catalog."C",
    git_name text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    password_hash text COLLATE pg_catalog."C",
    role text DEFAULT 'user'::text NOT NULL COLLATE pg_catalog."C",
    status text DEFAULT 'active'::text NOT NULL COLLATE pg_catalog."C",
    force_password_change boolean DEFAULT false NOT NULL,
    created_by text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    last_login_at bigint,
    schema_version bigint DEFAULT 1 NOT NULL,
    access_revision bigint DEFAULT 0 NOT NULL
);


--
-- Name: verification_profile_revisions; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.verification_profile_revisions (
    profile_id text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    content_json text NOT NULL COLLATE pg_catalog."C",
    content_digest text NOT NULL COLLATE pg_catalog."C",
    published_at bigint NOT NULL,
    published_by text COLLATE pg_catalog."C"
);


--
-- Name: verification_profiles; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.verification_profiles (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    draft_json text NOT NULL COLLATE pg_catalog."C",
    published_revision bigint,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'private'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    archived_at bigint
);


--
-- Name: webhook_deliveries; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_deliveries (
    id text NOT NULL COLLATE pg_catalog."C",
    endpoint_id text NOT NULL COLLATE pg_catalog."C",
    event_uuid text COLLATE pg_catalog."C",
    attempt_count bigint DEFAULT 1 NOT NULL,
    gitlab_event_header text COLLATE pg_catalog."C",
    object_kind text COLLATE pg_catalog."C",
    event_type text COLLATE pg_catalog."C",
    repo_path text COLLATE pg_catalog."C",
    stream_hint text COLLATE pg_catalog."C",
    mr_fact_key text COLLATE pg_catalog."C",
    mr_stream_key text COLLATE pg_catalog."C",
    mr_stream_revision bigint,
    mr_state_after text COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    status_reason text COLLATE pg_catalog."C",
    replayed_from_delivery_id text COLLATE pg_catalog."C",
    received_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    body_json text COLLATE pg_catalog."C"
);


--
-- Name: webhook_endpoints; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_endpoints (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    provider text NOT NULL COLLATE pg_catalog."C",
    url_token text NOT NULL COLLATE pg_catalog."C",
    secret_enc text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    preferred_clone_protocol text DEFAULT 'http'::text NOT NULL COLLATE pg_catalog."C",
    last_delivery_at bigint,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: webhook_mr_control_effects; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_mr_control_effects (
    id text NOT NULL COLLATE pg_catalog."C",
    delivery_id text NOT NULL COLLATE pg_catalog."C",
    endpoint_id text NOT NULL COLLATE pg_catalog."C",
    stream_key text NOT NULL COLLATE pg_catalog."C",
    binding text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    observed_event_type text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    lease_owner text COLLATE pg_catalog."C",
    lease_expires_at bigint,
    attempt_count bigint DEFAULT 0 NOT NULL,
    next_attempt_at bigint NOT NULL,
    last_error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: webhook_mr_control_targets; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_mr_control_targets (
    effect_id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    prior_status text COLLATE pg_catalog."C",
    fence_outcome text NOT NULL COLLATE pg_catalog."C",
    cancel_outcome text NOT NULL COLLATE pg_catalog."C",
    release_outcome text NOT NULL COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: webhook_mr_launch_guards; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_mr_launch_guards (
    id text NOT NULL COLLATE pg_catalog."C",
    endpoint_id text NOT NULL COLLATE pg_catalog."C",
    stream_key text NOT NULL COLLATE pg_catalog."C",
    binding text NOT NULL COLLATE pg_catalog."C",
    launch_revision bigint NOT NULL,
    delivery_id text NOT NULL COLLATE pg_catalog."C",
    fire_id text NOT NULL COLLATE pg_catalog."C",
    trigger_id text COLLATE pg_catalog."C",
    trigger_name_snapshot text NOT NULL COLLATE pg_catalog."C",
    task_id text COLLATE pg_catalog."C",
    launch_owner_key text COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: webhook_mr_stream_states; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_mr_stream_states (
    endpoint_id text NOT NULL COLLATE pg_catalog."C",
    stream_key text NOT NULL COLLATE pg_catalog."C",
    project_id text NOT NULL COLLATE pg_catalog."C",
    mr_iid text NOT NULL COLLATE pg_catalog."C",
    state text NOT NULL COLLATE pg_catalog."C",
    revision bigint NOT NULL,
    last_terminal_revision bigint,
    last_delivery_id text NOT NULL COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: webhook_trigger_fires; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_trigger_fires (
    id text NOT NULL COLLATE pg_catalog."C",
    delivery_id text NOT NULL COLLATE pg_catalog."C",
    trigger_id text NOT NULL COLLATE pg_catalog."C",
    stream_key text NOT NULL COLLATE pg_catalog."C",
    outcome text NOT NULL COLLATE pg_catalog."C",
    superseded_task_id text COLLATE pg_catalog."C",
    task_id text COLLATE pg_catalog."C",
    employee_case_id text COLLATE pg_catalog."C",
    error text COLLATE pg_catalog."C",
    fired_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: webhook_trigger_streams; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_trigger_streams (
    trigger_id text NOT NULL COLLATE pg_catalog."C",
    stream_key text NOT NULL COLLATE pg_catalog."C",
    consecutive_fires bigint DEFAULT 0 NOT NULL,
    last_fire_at bigint,
    reset_at bigint,
    reset_by text COLLATE pg_catalog."C"
);


--
-- Name: webhook_triggers; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.webhook_triggers (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    endpoint_id text NOT NULL COLLATE pg_catalog."C",
    owner_user_id text NOT NULL COLLATE pg_catalog."C",
    enabled boolean DEFAULT true NOT NULL,
    repo_scope text NOT NULL COLLATE pg_catalog."C",
    event_types text NOT NULL COLLATE pg_catalog."C",
    branch_filter text COLLATE pg_catalog."C",
    command_prefix text COLLATE pg_catalog."C",
    ignore_usernames text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    launch_kind text NOT NULL COLLATE pg_catalog."C",
    launch_ref_id text NOT NULL COLLATE pg_catalog."C",
    launch_payload text NOT NULL COLLATE pg_catalog."C",
    template_syntax_version bigint DEFAULT 1 NOT NULL,
    max_consecutive_fires bigint DEFAULT 3 NOT NULL,
    auto_register_repos boolean DEFAULT true NOT NULL,
    cancel_on_mr_terminal boolean DEFAULT false NOT NULL,
    last_fired_at bigint,
    last_status text COLLATE pg_catalog."C",
    last_error text COLLATE pg_catalog."C",
    last_task_id text COLLATE pg_catalog."C",
    consecutive_failures bigint DEFAULT 0 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: workflows; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workflows (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    definition text NOT NULL COLLATE pg_catalog."C",
    version bigint DEFAULT 1 NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    builtin boolean DEFAULT false NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: workgroup_assignments; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroup_assignments (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    round bigint DEFAULT 0 NOT NULL,
    source text NOT NULL COLLATE pg_catalog."C",
    created_by_run_id text COLLATE pg_catalog."C",
    created_by_user_id text COLLATE pg_catalog."C",
    assignee_member_id text COLLATE pg_catalog."C",
    title text NOT NULL COLLATE pg_catalog."C",
    brief_md text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL COLLATE pg_catalog."C",
    node_run_id text COLLATE pg_catalog."C",
    result_message_id text COLLATE pg_catalog."C",
    dedup_key text COLLATE pg_catalog."C",
    attempt_count bigint DEFAULT 0 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: workgroup_member_cursors; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroup_member_cursors (
    task_id text NOT NULL COLLATE pg_catalog."C",
    member_id text NOT NULL COLLATE pg_catalog."C",
    last_consumed_message_id text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: workgroup_members; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroup_members (
    id text NOT NULL COLLATE pg_catalog."C",
    workgroup_id text NOT NULL COLLATE pg_catalog."C",
    member_type text NOT NULL COLLATE pg_catalog."C",
    agent_name text COLLATE pg_catalog."C",
    agent_id text COLLATE pg_catalog."C",
    user_id text COLLATE pg_catalog."C",
    display_name text NOT NULL COLLATE pg_catalog."C",
    role_desc text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    sort_order bigint DEFAULT 0 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: workgroup_messages; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroup_messages (
    id text NOT NULL COLLATE pg_catalog."C",
    task_id text NOT NULL COLLATE pg_catalog."C",
    round bigint DEFAULT 0 NOT NULL,
    author_kind text NOT NULL COLLATE pg_catalog."C",
    author_member_id text COLLATE pg_catalog."C",
    author_user_id text COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    body_md text NOT NULL COLLATE pg_catalog."C",
    template_key text COLLATE pg_catalog."C",
    template_params_json text COLLATE pg_catalog."C",
    mentions_json text DEFAULT '[]'::text NOT NULL COLLATE pg_catalog."C",
    assignment_id text COLLATE pg_catalog."C",
    trigger_message_id text COLLATE pg_catalog."C",
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: workgroup_task_state; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroup_task_state (
    task_id text NOT NULL COLLATE pg_catalog."C",
    gate_status text DEFAULT 'idle'::text NOT NULL COLLATE pg_catalog."C",
    gate_summary text COLLATE pg_catalog."C",
    gate_rejected_comment text COLLATE pg_catalog."C",
    pause_reason text COLLATE pg_catalog."C",
    dw_state_json text COLLATE pg_catalog."C",
    result_message_id text COLLATE pg_catalog."C",
    updated_at bigint NOT NULL
);


--
-- Name: workgroups; Type: TABLE; Schema: agent_workflow; Owner: -
--

CREATE TABLE agent_workflow.workgroups (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL COLLATE pg_catalog."C",
    description text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    instructions text DEFAULT ''::text NOT NULL COLLATE pg_catalog."C",
    mode text DEFAULT 'leader_worker'::text NOT NULL COLLATE pg_catalog."C",
    output_contract text DEFAULT 'files'::text NOT NULL COLLATE pg_catalog."C",
    leader_member_id text COLLATE pg_catalog."C",
    share_outputs boolean DEFAULT true NOT NULL,
    direct_messages boolean DEFAULT false NOT NULL,
    blackboard boolean DEFAULT false NOT NULL,
    max_rounds bigint DEFAULT 20 NOT NULL,
    completion_gate boolean DEFAULT false NOT NULL,
    clarify_budget bigint DEFAULT 3 NOT NULL,
    fan_out boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    owner_user_id text COLLATE pg_catalog."C",
    visibility text DEFAULT 'public'::text NOT NULL COLLATE pg_catalog."C",
    acl_revision bigint DEFAULT 0 NOT NULL,
    schema_version bigint DEFAULT 1 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM clock_timestamp()) * (1000)::numeric))::bigint NOT NULL
);


--
-- Name: database_generations; Type: TABLE; Schema: agent_workflow_meta; Owner: -
--

CREATE TABLE agent_workflow_meta.database_generations (
    generation_id text NOT NULL,
    operation_id text NOT NULL,
    source_generation_id text NOT NULL,
    contract_digest text NOT NULL,
    state text NOT NULL,
    activated_at bigint,
    first_live_write_at bigint,
    CONSTRAINT database_generations_state_check CHECK ((state = ANY (ARRAY['prepared'::text, 'active'::text, 'retired'::text])))
);


--
-- Name: logical_copy_chunks; Type: TABLE; Schema: agent_workflow_meta; Owner: -
--

CREATE TABLE agent_workflow_meta.logical_copy_chunks (
    operation_id text NOT NULL,
    table_id text NOT NULL,
    chunk_index bigint NOT NULL,
    chunk_digest text NOT NULL,
    row_count bigint NOT NULL,
    first_key_json text,
    last_key_json text,
    committed_at bigint NOT NULL
);


--
-- Name: logical_copy_operations; Type: TABLE; Schema: agent_workflow_meta; Owner: -
--

CREATE TABLE agent_workflow_meta.logical_copy_operations (
    operation_id text NOT NULL,
    source_generation_id text NOT NULL,
    contract_digest text NOT NULL,
    plan_digest text NOT NULL,
    stage text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT logical_copy_operations_stage_check CHECK ((stage = ANY (ARRAY['prepared'::text, 'copying'::text, 'verified'::text, 'activated'::text, 'finalized'::text])))
);


--
-- Name: schema_contract; Type: TABLE; Schema: agent_workflow_meta; Owner: -
--

CREATE TABLE agent_workflow_meta.schema_contract (
    singleton boolean DEFAULT true NOT NULL,
    contract_digest text NOT NULL,
    active_table_count bigint NOT NULL,
    archive_only_table_count bigint NOT NULL,
    CONSTRAINT schema_contract_singleton_check CHECK (singleton)
);


--
-- Name: schema_migrations; Type: TABLE; Schema: agent_workflow_meta; Owner: -
--

CREATE TABLE agent_workflow_meta.schema_migrations (
    baseline_id text NOT NULL,
    contract_digest text NOT NULL,
    plan_digest text NOT NULL,
    applied_at bigint NOT NULL
);


--
-- Data for Name: action_template_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.action_template_revisions (template_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: action_templates; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.action_templates (id, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at, capability_id) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.agents (id, name, description, outputs, inputs, sync_outputs_on_iterate, runtime, permission, skills, depends_on, mcp, plugins, frontmatter_extra, body_md, owner_user_id, visibility, acl_revision, builtin, schema_version, created_at, updated_at) FROM stdin;
00000000000000000000000001	aw-skill-merger	Built-in skill-fusion worker: merges approved memories into a managed skill (RFC-101).	["summary"]	[]	t	\N	{}	[]	[]	[]	[]	{}	You are aw-skill-merger, the agent-workflow platform's skill-fusion worker.\n\nYour job: fuse the APPROVED MEMORIES listed in your prompt into the target SKILL whose files are in your current working directory, following skill-authoring conventions, then report what you incorporated.\n\n## Mandatory ask-back (you are in clarify mode)\nYou MUST ask the merger at least one clarifying question BEFORE editing anything. Confirm the merge goal, surface any conflict (a memory contradicting the skill, or two memories contradicting each other) and ask how to resolve it, and resolve every ambiguity. Do NOT edit files or emit output while clarifying — only emit the workflow-clarify envelope using the exact opening tag and required nonce supplied by the user prompt protocol. Keep asking until the merger stops clarifying.\n\n## After the merger stops clarifying — do the merge\n1. Read SKILL.md and the existing support files in your working directory.\n2. Integrate the memories' knowledge into the skill, honoring the merger's answers:\n   - De-duplicate; reconcile conflicts exactly as the merger decided.\n   - Preserve the skill's existing useful content; do not drop it.\n   - Follow conventions: SKILL.md frontmatter keeps a third-person, trigger-rich `description`; the body is imperative, < 500 lines; push detail into `references/` with clear pointers (progressive disclosure); keep `name` matching the directory.\n   - Edit files IN PLACE (SKILL.md and support files). You may add references/ examples/ scripts/.\n3. Write a manifest to `.agent-workflow/fusion/result.json` (create the `.agent-workflow/fusion/` dir) — JSON:\n   {"incorporatedMemoryIds": ["<id>", ...], "skipped": [{"memoryId": "<id>", "reason": "..."}], "changelog": "<what changed, markdown>"}\n   List EVERY selected memory in exactly one of incorporated/skipped. Skip a memory only if its knowledge is redundant or the merger declined it — never silently drop.\n4. Emit a short summary in the workflow-output envelope, using the exact opening tag and required nonce supplied by the user prompt protocol, with one `summary` port containing a one-paragraph summary.\n\nThe `.agent-workflow/fusion/` directory is framework scaffolding and is never written into the skill — put ONLY the manifest there.	__system__	public	0	t	1	1793429200871	1793429200871
00000000000000DECODEWRITER	digital-employee-code-writer	根据冻结的工作合同和上下文实现代码修改，只返回数字员工 exact envelope。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"code-writing","schemaVersion":2,"executionContracts":[{"contractId":"development.analyze-implement","version":1},{"contractId":"development.repair-conflict","version":1}]}	你是数字员工操作系统内置的代码编写者。只处理输入 envelope 中已授权的业务文件和目标；不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得自行选择下一步。先理解需求与现有代码，再完成最小且完整的实现和必要验证。只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200879	1793429200879
00000000000000DECONFLICTFIX	digital-employee-conflict-repairer	在平台冻结的冲突现场中修复授权冲突文件，只返回 exact envelope。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"conflict-repair","schemaVersion":2,"executionContracts":[{"contractId":"development.repair-conflict","version":1}]}	你是数字员工操作系统内置的代码冲突修复者。只在平台冻结的冲突现场中理解双方变更意图，修改合同授权的冲突文件，并完成最小验证。不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得改变固定父提交或自行选择下一步。只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200882	1793429200882
00000000000000DEDIAGNOSE	digital-employee-problem-diagnoser	基于冻结现场定位根因并形成可执行结论，只返回数字员工 exact envelope。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"problem-diagnosis","schemaVersion":3,"executionContracts":[{"contractId":"development.classify-pipeline","version":1}],"dispatchRouteDefinitions":[{"routeRef":"compile-error","displayName":"编译与构建错误","description":"编译、类型检查、链接或构建步骤失败","fallback":false},{"routeRef":"test-failure","displayName":"测试失败","description":"单元、集成、端到端或其他自动化测试失败","fallback":false},{"routeRef":"quality-gate-failure","displayName":"质量门禁失败","description":"格式、Lint、静态扫描或质量阈值未通过","fallback":false},{"routeRef":"dependency-or-environment","displayName":"依赖或环境错误","description":"依赖解析、工具链、权限、网络或运行环境异常","fallback":false},{"routeRef":"other-pipeline-failure","displayName":"其他流水线错误","description":"未命中前序问题类型的确定性兜底","fallback":true}]}	你是数字员工操作系统内置的问题定位者。只依据输入 envelope、仓库现场和 artifact 引用收集证据，区分事实、推断与未知项；不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得自行选择下一步。定位最小根因并给出合同要求的结构化产出。最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200880	1793429200880
00000000000000DEFEATUREDEV	digital-employee-business-implementer	面向新需求与业务逻辑实现，依据验收目标完成最小完整代码变更。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"business-implementation","schemaVersion":2,"executionContracts":[{"contractId":"development.analyze-implement","version":1}]}	你是数字员工操作系统内置的业务需求实现者。依据冻结需求、验收目标和仓库事实理解既有领域边界，完成最小且完整的业务代码、必要测试与说明。不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得自行选择下一步。只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200882	1793429200882
00000000000001DEFEATUREDEV	digital-employee-feature-implementer-v2	业务需求实现：围绕验收目标完成最小完整变更。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"business-implementation","executionContracts":[{"contractId":"development.implement-change","version":2}],"implementationIntent":"feature"}	你负责实现业务需求。围绕验收目标理解现有领域边界，完成最小且完整的业务代码、必要测试和验证，不扩展无关范围。需要核实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。不要替平台提交、推送、合并或更新 MR。	__system__	public	0	t	1	1793429200887	1793429200887
00000000000000DEISSUEFIX	digital-employee-issue-repairer	面向问题单与缺陷修复，先定位可验证根因，再完成最小修复和回归验证。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"issue-repair","schemaVersion":2,"executionContracts":[{"contractId":"development.analyze-implement","version":1}]}	你是数字员工操作系统内置的代码问题修复者。先用冻结问题材料、复现证据和仓库事实定位可验证根因，再实施最小修复并补充针对性回归验证；不要借机重构无关代码。不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得自行选择下一步。只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200883	1793429200883
00000000000000DEPIPEFIX	digital-employee-pipeline-repairer	读取流水线证据包和大日志引用，按闭集失败类型修复代码，只返回 exact envelope。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"pipeline-repair","schemaVersion":2,"executionContracts":[{"contractId":"development.repair-pipeline","version":1}]}	你是数字员工操作系统内置的流水线修复者。读取输入 envelope 的 platformPaths.pipelineDirectory 指向的精确证据目录，不要把大日志复述进输出。只修复指定失败类型和授权业务文件；不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得自行选择下一步。完成最小验证后，只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出工作合同要求的 JSON envelope；不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200881	1793429200881
00000000000000DEPLANANALYZE	digital-employee-implementation-planner	只读分析需求、材料与仓库，形成供人工评审的实现方案，不修改任何文件。	["analysis-plan"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"implementation-planning","schemaVersion":3,"executionContracts":[{"contractId":"development.analyze-plan","version":1,"outputPort":"analysis-plan","outputKind":"path<md>"}],"outputKinds":{"analysis-plan":"path<md>"}}	你是数字员工操作系统内置的实现方案分析者。先逐项阅读平台列出的需求正文、上传文件、外部材料目录和仓库现状，区分确定事实、假设与待确认项。只允许在平台注入的 platformPaths.implementationPlanPath 写入包含目标理解、影响范围、实现步骤、测试计划、风险与待确认问题的 Markdown 方案，并向 analysis-plan 端口只输出该相对路径。不得修改其他文件，不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得输出 agent-result。收到评审意见后必须逐条回应并覆写同一方案文件形成完整替代方案。	__system__	public	0	t	1	1793429200883	1793429200883
00000000000000DEREVIEWFIX	digital-employee-review-feedback-repairer	读取每棵检视线程的根评论和全部多轮回复，修复代码并逐线程输出处理说明。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"review-repair","schemaVersion":2,"executionContracts":[{"contractId":"development.repair-feedback","version":1}]}	你是数字员工操作系统内置的检视意见修复者。输入中的每个 reviewThread 都包含根评论和全部多轮回复，必须结合整棵线程理解审阅者意图并修复授权业务文件。不得执行 git、commit、push、merge、approve，不得调用代码托管平台，也不得直接回复或 resolve 评论。输出 envelope 必须在顶层 reviewReplies 按输入顺序为每个 threadRef 与 revision 恰好返回一条 disposition 和具体 replyBody，说明如何修复或为什么需要人工决策；不得编辑平台保存的 acknowledgement 回执。平台会在发布提交后把 replyBody 写回原线程。只要本轮修改了代码，输出 envelope 就必须在顶层 deliveryContent 中给出完整 commitMessage、mergeRequestTitle、mergeRequestDescription。不得编辑平台 Context；平台会校验并保存业务内容，再负责 commit、push 和创建或更新 MR。不得把交付文案只写在 summary。 最终只向 agent-result 输出 JSON envelope，不得夹带 Markdown、解释文字或额外端口。	__system__	public	0	t	1	1793429200881	1793429200881
00000000000001DECODEWRITER	digital-employee-change-implementer-v2	通用代码实现：读取需求材料，完成最小且完整的代码修改和验证。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"code-writing","executionContracts":[{"contractId":"development.implement-change","version":2}],"implementationIntent":"unspecified"}	你负责实现代码变更。先读取需求材料和相关仓库代码，理解既有边界，再完成最小且完整的实现与必要验证。需要核实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。不要替平台发布提交、推送、合并、评论或审批。	__system__	public	0	t	1	1793429200884	1793429200884
00000000000001DECONFLICTFIX	digital-employee-merge-conflict-resolver-v2	合并冲突处理：只解决平台列出的冲突文件。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"conflict-repair","executionContracts":[{"contractId":"development.resolve-merge-conflicts","version":2}]}	你负责解决列出的合并冲突。结合源版本、目标版本、需求材料和双方代码意图，只修改冲突文件并完成必要验证。可以使用现有网络以及仓库、Git 和代码托管读取能力。不要改变版本选择，也不要替平台创建合并提交、推送或更新 MR。	__system__	public	0	t	1	1793429200886	1793429200886
00000000000001DEDIAGNOSE	digital-employee-pipeline-failure-classifier-v2	流水线失败分类：把每个失败检查恰好归入一个配置类型。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"problem-diagnosis","executionContracts":[{"contractId":"development.classify-pipeline-failures","version":2}]}	你负责分类流水线失败。逐项阅读失败检查及其证据，按给定类型的名称和说明判断；每个检查只归入一个类型，无法匹配时使用兜底分类。分类顺序不代表修复顺序，也不要选择处理工具。需要补充事实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。	__system__	public	0	t	1	1793429200885	1793429200885
00000000000001DEISSUEFIX	digital-employee-defect-repairer-v2	缺陷修复：先确认根因，再完成最小修复和回归验证。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"issue-repair","executionContracts":[{"contractId":"development.implement-change","version":2}],"implementationIntent":"defect"}	你负责修复缺陷。先用问题材料、复现证据和仓库事实确认可验证根因，再实施最小修复并补充针对性回归验证，不借机重构无关代码。需要核实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。不要替平台提交、推送、合并或更新 MR。	__system__	public	0	t	1	1793429200887	1793429200887
00000000000001DEPIPEFIX	digital-employee-pipeline-failure-repairer-v2	流水线失败修复：处理一个失败类型下的全部问题。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"pipeline-repair","executionContracts":[{"contractId":"development.repair-pipeline-failures","version":2}]}	你负责修复本轮指定类型的全部流水线问题。阅读每条问题及其证据文件，定位共同或独立根因，完成最小代码修改与针对性验证。需要核实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。不要处理其他失败类型，也不要替平台提交、推送或更新 MR。	__system__	public	0	t	1	1793429200885	1793429200885
00000000000001DEPLANANALYZE	digital-employee-implementation-plan-writer-v2	编写实现方案：基于需求材料和仓库事实写出可评审方案。	["analysis-plan"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"implementation-planning","executionContracts":[{"contractId":"development.plan-implementation","version":2,"outputPort":"analysis-plan","outputKind":"path<md>"}],"outputKinds":{"analysis-plan":"path<md>"}}	你负责写实现方案。读取需求材料和相关仓库代码，必要时使用现有网络以及仓库、Git 和代码托管读取能力核实事实；在指定文件中写明目标理解、影响范围、实现步骤、测试计划、风险、假设和待确认问题。不要修改业务文件，也不要替平台发布外部变更。	__system__	public	0	t	1	1793429200888	1793429200888
00000000000001DEREVIEWFIX	digital-employee-review-feedback-resolver-v2	检视意见处理：理解完整线程，逐条回复，需要时修改代码。	["agent-result"]	[]	t	\N	{}	[]	[]	[]	[]	{"digitalEmployeeTemplate":"review-repair","executionContracts":[{"contractId":"development.resolve-review-feedback","version":2}]}	你负责处理检视意见。按线程阅读根评论和全部回复，逐条形成具体答复；只有确实需要时才修改代码，并完成相应验证。需要核实时，可以使用现有网络以及仓库、Git 和代码托管读取能力。不要直接发布评论，也不要替平台提交、推送或更新 MR。	__system__	public	0	t	1	1793429200886	1793429200886
aw-demo-reviewer	[demo] reviewer	Sample reviewer used by the demo binding and workflows. 示例数据，可以安全删除；删除后不会再次生成。 / Sample data — safe to delete.	["findings"]	[]	t	\N	{}	[]	[]	[]	[]	{"readonly":true}	You review a merge request diff and report findings.\n\n> 示例数据，可以安全删除；删除后不会再次生成。 / Sample data — safe to delete.	__system__	public	0	f	1	1700000000000	1700000000000
\.


--
-- Data for Name: auth_login_policy; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.auth_login_policy (id, password_login_enabled, oidc_default_role, bootstrap_completed_at, updated_at) FROM stdin;
global	t	guest	\N	1793429200000
\.


--
-- Data for Name: automation_policies; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.automation_policies (id, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at) FROM stdin;
\.


--
-- Data for Name: automation_policy_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.automation_policy_revisions (policy_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: cached_repos; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.cached_repos (id, url_hash, url_enc, url_redacted, local_path, default_branch, last_fetched_at, created_at, has_submodules, last_submodule_sync_ok, last_submodule_sync_error, last_auto_refresh_at) FROM stdin;
\.


--
-- Data for Name: capability_templates; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.capability_templates (id, name, description, capability, scripts_json, hooks_json, param_schema_json, param_defaults_json, agent_by_slot_json, prompt_by_slot_json, params_json, stage_contract_ver, upstream_id, upstream_version, base_digest, base_snapshot_json, owner_user_id, visibility, acl_revision, builtin, created_at, updated_at) FROM stdin;
aw-demo-template-mr-review	[demo] MR review template	The whole configuration for one capability: scripts, hooks, parameters, and which agent fills each AI slot. 示例数据，可以安全删除；删除后不会再次生成。 / Sample data — safe to delete.	mr-review	{"collect":{"language":"bash","script":"#!/usr/bin/env bash\\n# [demo] Sample collect script.\\n# Real ones ask the code host what changed; this one just reports a\\n# fixed shape so the sample runs nowhere and needs nothing.\\nset -euo pipefail\\necho '{\\"packages\\": []}'"}}	[{"stage":"review-shard","phase":"pre","language":"bash","script":"#!/usr/bin/env bash\\n# [demo] Runs before each sharded review.\\n#\\n# It returns only the contract-declared extraContext key.\\nset -euo pipefail\\necho '{\\"extraContext\\": \\"Prefer concrete, reproducible findings.\\"}'","blocking":true,"stageContractVer":4}]	[{"name":"maxFindings","kind":"number","required":false},{"name":"skipDraft","kind":"boolean","required":false}]	{"maxFindings":20,"skipDraft":true}	{"reviewer":"aw-demo-reviewer"}	{"reviewer":"Review the diff. Report only findings you can point at a line for."}	{"maxFindings":10}	4	\N	\N	\N	\N	__system__	public	0	f	1700000000000	1700000000000
\.


--
-- Data for Name: clarify_rounds; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.clarify_rounds (id, task_id, kind, asking_node_id, asking_node_run_id, asking_shard_key, intermediary_node_id, intermediary_node_run_id, target_consumer_node_id, loop_iter, container_run_id, iteration, questions_json, answers_json, directive, status, truncation_warnings_json, designer_run_triggered_at, abandoned_at, created_at, answered_at, answered_by, submitted_by_role, answer_attributions_json, draft_answers_json) FROM stdin;
\.


--
-- Data for Name: code_ai_attempts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_ai_attempts (id, round_id, stage_name, shard_key, rerun_seq, attempt_seq, status, validation_outcome, session_ref, node_run_id, started_at, ended_at) FROM stdin;
\.


--
-- Data for Name: code_findings; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_findings (id, code_host_endpoint_id, stable_project_id, anchor_kind, anchor_id, capability, fingerprint, generation, lifecycle, severity, title, file_path, anchor_line, external_id, published_round_id, disappeared_round_id, resolved_at, resolved_round_id, code_changed_at, code_changed_round_id, created_at, last_seen_at, closed_at) FROM stdin;
\.


--
-- Data for Name: code_host_connections; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_host_connections (provider, base_url, repository_url_prefixes_json, transport_mappings_json, connection_generation, reject_unauthorized, token_enc, token_hint, last_test_json, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: code_round_stages; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_round_stages (id, round_id, stage_seq, stage_name, stage_kind, status, counts_json, error, started_at, ended_at) FROM stdin;
aw-demo-round-0	aw-demo-round	0	resolve-target	program	done	\N	\N	1700000000000	1700000015000
aw-demo-round-1	aw-demo-round	1	prepare-worktree	program	done	\N	\N	1700000015000	1700000030000
aw-demo-round-10	aw-demo-round	10	publish	program	done	\N	\N	1700000150000	1700000165000
aw-demo-round-11	aw-demo-round	11	settle-stale	program	done	\N	\N	1700000165000	1700000180000
aw-demo-round-12	aw-demo-round	12	ledger	program	done	\N	\N	1700000180000	1700000195000
aw-demo-round-2	aw-demo-round	2	fetch-diff	program	done	\N	\N	1700000030000	1700000045000
aw-demo-round-3	aw-demo-round	3	split-diff	program	done	\N	\N	1700000045000	1700000060000
aw-demo-round-4	aw-demo-round	4	review-shard	ai	done	\N	\N	1700000060000	1700000075000
aw-demo-round-5	aw-demo-round	5	review-global	ai	done	\N	\N	1700000075000	1700000090000
aw-demo-round-6	aw-demo-round	6	validate-findings	program	done	\N	\N	1700000090000	1700000105000
aw-demo-round-7	aw-demo-round	7	gate	program	done	\N	\N	1700000105000	1700000120000
aw-demo-round-8	aw-demo-round	8	resolve-positions	program	done	\N	\N	1700000120000	1700000135000
aw-demo-round-9	aw-demo-round	9	reconcile	program	done	\N	\N	1700000135000	1700000150000
\.


--
-- Data for Name: code_trigger_deliveries; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_trigger_deliveries (id, correlation_id, code_host_endpoint_id, stable_project_id, anchor_kind, anchor_id, capability, step, outcome, reason, queued_at, queue_position, waiting_on, round_id, is_probe, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: code_work_items; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_work_items (id, code_host_endpoint_id, stable_project_id, capability, anchor_kind, anchor_id, status, epoch, current_round_id, pending_generation, handed_off_fingerprint, publishing_epoch, pending_revision, anchor_meta, initiator_user_id, created_at, updated_at, closed_at) FROM stdin;
aw-demo-work-item	aw-demo-endpoint	demo/sample-project	mr-review	mr	42	settled	1	aw-demo-round	\N	\N	\N	\N	\N	\N	1700000000000	1700000000000	\N
\.


--
-- Data for Name: code_work_rounds; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.code_work_rounds (id, work_item_id, round_seq, epoch, task_id, baseline_sha, work_package, template_snapshot, stage_contract_ver, outcome, started_at, ended_at) FROM stdin;
aw-demo-round	aw-demo-work-item	1	1	\N	0000000000000000000000000000000000000000	\N	\N	4	published	1700000000000	1700000214000
\.


--
-- Data for Name: collaboration_gate_artifacts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.collaboration_gate_artifacts (operation_id, artifact_key, artifact_kind, staged_path, final_path, sha256, byte_size, state, receipt_json, updated_at) FROM stdin;
\.


--
-- Data for Name: collaboration_gate_operations; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.collaboration_gate_operations (id, task_id, gate_kind, operation_kind, gate_ref, idempotency_key, request_hash, actor_user_id, expected_task_revision, expected_gate_revision, result_gate_revision, state, claim_epoch, claim_expires_at, schema_version, manifest_json, receipt_json, failure_json, created_at, updated_at, committed_at, completed_at) FROM stdin;
\.


--
-- Data for Name: committed_event_aggregate_heads; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.committed_event_aggregate_heads (producer, family, aggregate_kind, aggregate_id, last_seq, updated_at) FROM stdin;
\.


--
-- Data for Name: committed_event_deliveries; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.committed_event_deliveries (event_id, consumer_id, delivery_class, state, attempt_count, next_attempt_at, claimed_by, lease_epoch, claim_expires_at, last_error_code, last_error_summary, replay_generation, created_at, updated_at, accepted_at, dead_letter_at) FROM stdin;
\.


--
-- Data for Name: committed_event_family_cutovers; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.committed_event_family_cutovers (producer, family, mode, epoch, changed_at, change_ref) FROM stdin;
collaboration	clarify	dispatchable	2	1789833612066	rfc341:collaboration-cutover
collaboration	questions	dispatchable	2	1789833612066	rfc341:collaboration-cutover
collaboration	review	dispatchable	2	1789833612066	rfc341:collaboration-cutover
task-execution	task-lifecycle	dispatchable	2	1789574412066	rfc341:task-lifecycle-cutover
\.


--
-- Data for Name: committed_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.committed_events (id, event_group_id, event_group_ordinal, producer, family, event_type, schema_version, aggregate_kind, aggregate_id, aggregate_seq, operation_ref, correlation_ref, causation_ref, occurred_at, payload_json, payload_digest, delivery_mode, producer_epoch, created_at) FROM stdin;
\.


--
-- Data for Name: custom_event_source_definitions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.custom_event_source_definitions (id, draft_json, published_revision, owner_user_id, created_at, updated_at, retired_at) FROM stdin;
\.


--
-- Data for Name: custom_event_source_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.custom_event_source_revisions (source_id, revision, content_json, content_digest, validation_receipt_json, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: development_action_runs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_action_runs (id, mission_id, mission_revision, decision_id, capability_id, capability_contract_version, template_id, template_revision, work_set_digest, input_fact_digest, baseline_ref, writable, status, result_ref, failure_json, created_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_adapter_definition_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_adapter_definition_revisions (adapter_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: development_adapter_definitions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_adapter_definitions (id, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at, purpose) FROM stdin;
\.


--
-- Data for Name: development_agent_attempts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_agent_attempts (id, action_run_id, rerun_seq, attempt_seq, execution_ref, baseline_ref, nonce_digest, input_digest, status, rejection_json, outcome_ref, pre_snapshot_ref, created_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_approval_sagas; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_approval_sagas (id, mission_id, step_run_id, adapter_id, adapter_revision, draft_ref, submit_intent_digest, idempotency_key, correlation_ref, external_request_ref, submitted_revision, latest_status, observed_revision, evidence_ref, deadline_at, attempt_ordinal, next_observe_at, created_at, updated_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_bundle_refs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_bundle_refs (id, mission_id, purpose, evidence_ref, manifest_digest, file_count, total_bytes, retention_state, created_at) FROM stdin;
\.


--
-- Data for Name: development_decisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_decisions (id, mission_id, mission_revision, policy_id, policy_revision, employee_id, employee_revision, fact_snapshot_id, fact_digest, work_set_json, guard_trace_json, rule_trace_json, selected_json, canonical_digest, decision_input_digest, decided_at) FROM stdin;
\.


--
-- Data for Name: development_deferred_wakes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_deferred_wakes (id, mission_id, decision_id, reason, resume_at, wake_sources_json, attempt_ordinal, state, created_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_effects; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_effects (id, mission_id, action_run_id, effect_kind, intent_digest, idempotency_key, epoch, state, receipt_ref, failure_json, created_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_fact_snapshots; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_fact_snapshots (id, mission_id, mission_revision, captured_at, cells_json, refs_json, digest, created_at) FROM stdin;
\.


--
-- Data for Name: development_feedback_ledger; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_feedback_ledger (id, mission_id, thread_ref, revision, head_sha, fingerprint, author_class, state, action_run_id, reply_effect_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: development_mission_links; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_mission_links (id, parent_mission_id, parent_step_run_id, target_repository_id, target_employee_id, target_employee_revision, input_digest, idempotency_key, child_mission_id, completion, state, latest_child_revision, latest_status, completion_satisfied, output_ref, observed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: development_mission_sources; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_mission_sources (id, mission_id, generation, source_kind, external_id, adapter_id, adapter_revision, source_revision, bundle_ref, manifest_digest, file_count, total_bytes, state, created_at) FROM stdin;
\.


--
-- Data for Name: development_missions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_missions (id, revision, epoch, status, automation_mode, transition_fence, repository_id, source_kind, source_content_digest, requested_source_key, external_id, resolved_source_key, resolved_adapter_id, resolved_adapter_revision, delivery_kind, delivery_target_ref, delivery_source_branch, adopted_mr_ref, assignment_id, employee_id, employee_revision, policy_id, policy_revision, requirement_bundle_ref, repository_facts_ref, upload_plan_ref, upload_placement_ref, upload_publication_ref, mr_claim_id, current_action_run_id, readiness_json, block_code, block_detail, terminal_kind, terminal_upload_fulfillment, terminal_at, reopened_from_mission_id, launch_idempotency_key, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: development_mr_claims; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_mr_claims (id, code_host_endpoint_ref, stable_project_ref, mr_iid, mission_id, epoch, head_sha, state, created_at, released_at) FROM stdin;
\.


--
-- Data for Name: development_repository_upload_plan_entries; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_repository_upload_plan_entries (plan_id, ordinal, file_id, upload_blob_ref, upload_sha256, repository_target_path, content_policy, target_file_mode, expected_target_kind, expected_target_sha256, expected_target_file_mode) FROM stdin;
\.


--
-- Data for Name: development_repository_upload_plans; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_repository_upload_plans (id, mission_id, mission_revision, repository_id, baseline_snapshot_ref, baseline_sha, plan_digest, created_at) FROM stdin;
\.


--
-- Data for Name: development_repository_upload_receipts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_repository_upload_receipts (id, plan_id, baseline_snapshot_ref, receipt_kind, seed_change_ref, seed_tree_digest, fulfillment_kind, commit_sha, entries_json, created_at) FROM stdin;
\.


--
-- Data for Name: development_step_joins; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_step_joins (mission_id, group_id, member_step_id, mode, quorum, deadline_at, member_state, receipt_revision, settled_result, updated_at) FROM stdin;
\.


--
-- Data for Name: development_step_runs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_step_runs (id, mission_id, employee_id, employee_revision, step_id, attempt, input_digest, producer_kind, state, decision_id, action_run_id, deadline_at, output_ref, output_revision, failure_category, failure_code, created_at, updated_at, settled_at) FROM stdin;
\.


--
-- Data for Name: development_wake_hints; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.development_wake_hints (id, mission_id, source, delivery_key, observed_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: digital_employee_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.digital_employee_revisions (employee_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: digital_employees; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.digital_employees (id, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at) FROM stdin;
\.


--
-- Data for Name: doc_versions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.doc_versions (id, task_id, review_node_id, review_node_run_id, source_node_id, source_port_name, version_index, review_iteration, body_path, comments_json, decision, decision_reason, prompt_snapshot, source_file_path, item_index, selection, item_path, selection_stale, round_generation, created_at, decided_at, decided_by, decided_by_role) FROM stdin;
\.


--
-- Data for Name: employee_approval_sagas; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_approval_sagas (id, case_id, submit_round_id, adapter_id, adapter_revision, validated_draft_ref, deadline_at, idempotency_key, intent_digest, correlation_ref, external_request_ref, submitted_revision, submitted_at, latest_status, observed_revision, evidence_ref, observed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_attention_bindings; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_attention_bindings (id, case_id, context_id, context_revision, event_type_id, event_type_revision, subject_type, subject_ref, desired_identity_key, event_subscription_id, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_case_event_origins; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_case_event_origins (case_id, event_subscription_id, event_delivery_id, created_at) FROM stdin;
\.


--
-- Data for Name: employee_case_inbox; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_case_inbox (id, case_id, delivery_id, event_id, event_type_id, event_type_revision, source_id, source_revision, subject_type, subject_ref, delivery_class, priority, occurred_at, summary, payload_artifact_ref, state, round_id, accepted_at, settled_at) FROM stdin;
\.


--
-- Data for Name: employee_case_members; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_case_members (case_id, user_id, role, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: employee_case_metering_receipts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_case_metering_receipts (source_ref, case_id, round_id, duration_ms, total_tokens, created_at) FROM stdin;
\.


--
-- Data for Name: employee_case_workspaces; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_case_workspaces (case_id, repository_id, cached_repo_id, baseline_sha, target_branch, source_branch, remote_head_sha, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_cases; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_cases (id, name, employee_id, employee_revision, type_id, type_revision, primary_context_id, execution_policy_revision, max_duration_ms, consumed_duration_ms, max_total_tokens, consumed_total_tokens, owner_user_id, launch_origin, state, terminal_kind, block_reason, current_work_item_ref, active_round_id, revision, writer_generation, created_at, updated_at, terminal_at) FROM stdin;
\.


--
-- Data for Name: employee_change_candidates; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_change_candidates (candidate_ref, case_id, round_id, baseline_sha, tree_oid, receipt_json, summary_source, state, commit_sha, push_receipt_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_channel_results; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_channel_results (id, channel_id, milestone_type, envelope_json, envelope_digest, monotonic, created_at) FROM stdin;
\.


--
-- Data for Name: employee_channels; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_channels (id, invocation_id, parent_case_id, child_case_id, correlation_ref, result_contract_ref_json, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_context_links; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_context_links (id, case_id, from_context_id, relation, to_context_id, created_at) FROM stdin;
\.


--
-- Data for Name: employee_context_records; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_context_records (id, case_id, type_id, schema_version, current_revision, lifecycle_state, state_json, artifact_refs_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_context_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_context_revisions (context_id, revision, state_json, artifact_refs_json, content_digest, created_at) FROM stdin;
\.


--
-- Data for Name: employee_definition_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_definition_revisions (employee_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: employee_definitions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_definitions (id, name, type_id, type_revision, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at) FROM stdin;
\.


--
-- Data for Name: employee_execution_policy_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_execution_policy_revisions (revision, content_json, content_digest, published_at, published_by) FROM stdin;
1	{"schemaVersion":1,"sameSceneAttempts":3,"freshSceneAttempts":1,"initialBackoffMs":2000,"maxBackoffMs":120000,"roundBudgetMs":7200000,"caseBudgetMs":2592000000,"externalWaitDeadlineMs":1209600000,"handoffOnExhausted":true}	9f610cc7054a4d38964ce0a35d6075d3de14ba430c9dcd74c62a57df978d5041	1793429201153	\N
\.


--
-- Data for Name: employee_external_context_bindings; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_external_context_bindings (subject_type, subject_ref, case_id, context_id, binding_revision, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_input_uploads; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_input_uploads (id, actor_user_id, original_name, bytes, sha256, blob_ref, upload_idempotency_key, state, claimed_by_case_id, expires_at, created_at, claimed_at) FROM stdin;
\.


--
-- Data for Name: employee_invocations; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_invocations (id, idempotency_key, parent_case_id, parent_round_id, target_employee_id, target_employee_revision, target_work_scope_ref_json, input_envelope_ref, input_digest, completion_contract_ref_json, deadline_at, child_case_id, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_job_template_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_job_template_revisions (template_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: employee_job_templates; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_job_templates (id, type_id, type_revision, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at) FROM stdin;
\.


--
-- Data for Name: employee_os_outbox; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_os_outbox (id, case_id, kind, payload_json, dedupe_key, state, attempt_count, next_attempt_at, claimed_by, claim_expires_at, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_os_settings; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_os_settings (singleton_key, execution_policy_revision, updated_at) FROM stdin;
global	1	1793429201153
\.


--
-- Data for Name: employee_os_writer_state; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_os_writer_state (id, active_generation, mode, legacy_admissions_enabled, legacy_open_mission_count, updated_at) FROM stdin;
global	1	os-active	f	0	1793429216937
\.


--
-- Data for Name: employee_reaction_rounds; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_reaction_rounds (id, case_id, case_revision, inbox_id, employee_id, employee_revision, rule_id, work_item_ref, work_contract_id, work_contract_version, tool_id, tool_revision, execution_policy_revision, input_context_refs_json, plan_json, state, execution_ref, output_json, attempt_ordinal, created_at, updated_at, settled_at) FROM stdin;
\.


--
-- Data for Name: employee_round_workspace_states; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_round_workspace_states (round_id, attempt_ordinal, case_id, baseline_sha, pre_state_json, checkpoint_digest, validation_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_tool_registration_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_tool_registration_revisions (tool_id, revision, content_json, content_digest, validation_receipt_json, state, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: employee_tool_registrations; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_tool_registrations (id, type_id, type_revision, work_item_ref, draft_json, published_revision, owner_user_id, name, visibility, acl_revision, created_at, updated_at, retired_at) FROM stdin;
\.


--
-- Data for Name: employee_type_packages; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_type_packages (type_id, revision, descriptor_json, descriptor_digest, state, registered_at) FROM stdin;
development	10	{"schemaVersion":1,"typeRef":{"typeId":"development","revision":10},"displayName":{"zh-CN":"开发数字员工","en-US":"Development employee"},"description":{"zh-CN":"负责需求开发、问题定位并提交 MR；随后持续看护检视、流水线和冲突，直到 MR 外部合入或关闭。","en-US":"Develops requirements, diagnoses problems, opens a merge request, and then watches reviews, pipelines, and conflicts until external merge or close."},"workScopeContractId":"development.repository-scope.v1","workScopeAuthoring":{"schemaVersion":1,"label":{"zh-CN":"负责范围","en-US":"Responsibility scope"},"description":{"zh-CN":"决定这名员工可以受理哪些仓库的工作。","en-US":"Determines which repositories this employee may accept work for."},"variants":[{"kind":"repository","label":{"zh-CN":"单个仓库","en-US":"Repository"},"description":{"zh-CN":"只负责一个代码仓库","en-US":"Owns work for one repository"},"fields":[{"fieldRef":"repositoryId","label":{"zh-CN":"仓库","en-US":"Repository"},"description":{"zh-CN":"从平台已有仓库中选择","en-US":"Choose an existing platform repository"},"inputKind":"repository-picker","required":true,"placeholder":{"zh-CN":"请选择仓库","en-US":"Choose a repository"}}]},{"kind":"repository-group","label":{"zh-CN":"仓库组","en-US":"Repository group"},"description":{"zh-CN":"负责一个仓库组中的工作","en-US":"Owns work for a repository group"},"fields":[{"fieldRef":"repositoryGroupId","label":{"zh-CN":"仓库组","en-US":"Repository group"},"description":{"zh-CN":"从平台已有仓库组中选择","en-US":"Choose an existing repository group"},"inputKind":"repository-group-picker","required":true,"placeholder":{"zh-CN":"请选择仓库组","en-US":"Choose a repository group"}}]},{"kind":"task","label":{"zh-CN":"任务启动时指定仓库","en-US":"Choose repository when starting a task"},"description":{"zh-CN":"员工不固定仓库，每次交给它工作时再选择目标仓库","en-US":"The employee is not bound to a repository; choose one for each new task"},"fields":[]}]},"workIntakeAuthoring":{"schemaVersion":1,"label":{"zh-CN":"交给员工一项工作","en-US":"Give the employee work"},"description":{"zh-CN":"可以写正文、上传并指定入库路径，或提交外部需求/问题 ID。","en-US":"Provide a body, upload files with repository target paths, or submit an external requirement or issue ID."},"targetFields":[{"fieldRef":"repositoryId","label":{"zh-CN":"目标仓库","en-US":"Target repository"},"description":{"zh-CN":"这项工作最终修改并提交到哪个仓库","en-US":"Repository that will receive the resulting change"},"inputKind":"repository-picker","required":true,"placeholder":{"zh-CN":"请选择目标仓库","en-US":"Choose the target repository"}}],"acceptedKinds":["body","files","body-and-files","external-id"],"kindRequirements":[{"kind":"external-id","workItemRef":"prepare-materials","slotRef":"default"}],"executionOptions":[{"optionRef":"review-implementation-plan","label":{"zh-CN":"实现前评审方案","en-US":"Review implementation plan"},"description":{"zh-CN":"先输出实现方案，等待人工评论、驳回/迭代或批准，再开始修改代码","en-US":"Produce a plan and wait for human comments, iteration, or approval before changing code"},"defaultValue":false,"requiredWorkItemRef":"analyze-implement","requiredSlotRef":"plan","requiredExecutorKind":"agent"}],"advancedOptions":[{"optionRef":"working-branch","control":"repository-branch","label":{"zh-CN":"工作分支","en-US":"Working branch"},"description":{"zh-CN":"留空时由平台为本次数字员工任务生成隔离分支","en-US":"Leave blank to let the platform generate an isolated branch for this employee task"}}],"body":{"label":{"zh-CN":"需求或问题正文","en-US":"Requirement or problem body"},"description":{"zh-CN":"说明目标、现象和验收条件","en-US":"Describe the goal, symptoms, and acceptance criteria"},"placeholder":{"zh-CN":"写下需要完成的工作…","en-US":"Describe the work to be completed…"},"maxBytes":2097152},"files":{"label":{"zh-CN":"需求或问题文档","en-US":"Requirement or problem documents"},"description":{"zh-CN":"每个文件可选择随 MR 入库，或放入平台临时材料目录仅供分析与实现读取。","en-US":"Each file can be committed with the MR or placed in the platform temporary material directory for analysis and implementation only."},"maxFiles":200,"maxFileBytes":33554432,"targetPathRequired":true,"placementModes":["repository","temporary"]},"externalId":{"label":{"zh-CN":"外部需求或问题 ID","en-US":"External requirement or issue ID"},"description":{"zh-CN":"作为平台标准工作请求交给材料准备工具，不选择 provider Adapter","en-US":"Passed to the material-preparation tool as a platform-standard request without selecting a provider Adapter"},"placeholder":{"zh-CN":"例如 ISSUE-1234","en-US":"For example ISSUE-1234"}}},"authoringManifest":{"schemaVersion":1,"lifecycleRegions":[{"regionId":"delivery","label":{"zh-CN":"需求开发与问题定位","en-US":"Delivery and diagnosis"},"description":{"zh-CN":"目标是形成一个可看护的 MR","en-US":"Produces a merge request that can be watched"},"order":0,"responsibilityLanes":[{"laneId":"delivery-main","label":{"zh-CN":"交付主线","en-US":"Delivery spine"},"description":{"zh-CN":"从工作材料到提交 MR","en-US":"From work material to merge request"},"order":0,"kind":"spine","optional":false,"adapterSlots":[]}]},{"regionId":"care","label":{"zh-CN":"MR 看护与修绿","en-US":"MR care and repair"},"description":{"zh-CN":"响应 review、流水线、冲突和生命周期事件，保持随时可合入","en-US":"Reacts to review, pipeline, conflict, and lifecycle events to keep the MR merge-ready"},"order":1,"responsibilityLanes":[{"laneId":"care-attention","label":{"zh-CN":"MR 事件入口","en-US":"MR event hub"},"description":{"zh-CN":"订阅或扫描变化，再按事件进入对应职责","en-US":"Observe changes, then dispatch to the matching duty"},"order":0,"kind":"spine","optional":false,"adapterSlots":[]},{"laneId":"care-review","label":{"zh-CN":"检视意见","en-US":"Review feedback"},"description":{"zh-CN":"识别意见并完成修复","en-US":"Classify and repair review feedback"},"order":10,"kind":"branch","optional":true,"adapterSlots":[]},{"laneId":"care-pipeline","label":{"zh-CN":"流水线门禁","en-US":"Pipeline gates"},"description":{"zh-CN":"取得证据、归类失败，再由岗位按配置顺序逐类修绿","en-US":"Collect evidence, classify failures, then repair each type in the job-configured order"},"order":20,"kind":"branch","optional":true,"adapterSlots":[{"slotRef":"primary","label":{"zh-CN":"企业流水线连接","en-US":"Enterprise pipeline connection"},"description":{"zh-CN":"平台通过该连接取得当前 MR head 的门禁事实","en-US":"The platform uses this connection to collect gate facts for the current merge-request head"},"purpose":"pipeline-gate","requiredWhenLaneEnabled":true}]},{"laneId":"care-conflict","label":{"zh-CN":"代码冲突","en-US":"Merge conflicts"},"description":{"zh-CN":"修复冲突并刷新 MR head","en-US":"Repair conflicts and refresh the MR head"},"order":30,"kind":"branch","optional":true,"adapterSlots":[]},{"laneId":"care-collaboration","label":{"zh-CN":"员工协同","en-US":"Employee collaboration"},"description":{"zh-CN":"调起其他数字员工并等待其工作结果","en-US":"Invoke another digital employee and wait for its result"},"order":40,"kind":"branch","optional":true,"adapterSlots":[]},{"laneId":"care-approval","label":{"zh-CN":"外部审批门禁","en-US":"External approval gate"},"description":{"zh-CN":"独立准备、提交并等待外部系统审批","en-US":"Independently prepare, submit, and await external approval"},"order":50,"kind":"branch","optional":true,"adapterSlots":[{"slotRef":"primary","label":{"zh-CN":"企业审批连接","en-US":"Enterprise approval connection"},"description":{"zh-CN":"审批草稿、提交与等待统一使用该冻结连接","en-US":"Approval drafting, submission, and observation share this frozen connection"},"purpose":"approval-gateway","requiredWhenLaneEnabled":true}]},{"laneId":"care-readiness","label":{"zh-CN":"合入判断","en-US":"Merge readiness"},"description":{"zh-CN":"持续判断随时可合入并等待 committer","en-US":"Stay merge-ready and await a committer"},"order":60,"kind":"branch","optional":false,"adapterSlots":[]}]}],"workIngresses":[{"ingressRef":"ui-input","regionId":"delivery","responsibilityLaneId":"delivery-main","order":0,"label":{"zh-CN":"界面输入","en-US":"UI input"},"valueLabel":{"zh-CN":"任务","en-US":"Task"},"description":{"zh-CN":"从统一新建任务界面输入正文、文件或外部需求编号","en-US":"Enter a body, files, or an external requirement ID in unified task creation"},"sourceClass":"manual","eventTypeRefs":[],"configurationSurface":"task-creation","nextWorkItemRef":"prepare-materials"},{"ingressRef":"issue","regionId":"delivery","responsibilityLaneId":"delivery-main","order":10,"label":{"zh-CN":"ISSUE","en-US":"ISSUE"},"valueLabel":{"zh-CN":"Webhook","en-US":"Webhook"},"description":{"zh-CN":"在 Webhook 自动化规则中把 ISSUE 事件交给这名数字员工","en-US":"Route ISSUE events to this employee with a Webhook automation rule"},"sourceClass":"issue","eventTypeRefs":[{"id":"code-host.issue.labeled","revision":1},{"id":"code-host.issue.comment-received","revision":1}],"configurationSurface":"event-response-rules","nextWorkItemRef":"prepare-materials"}],"workItems":[{"workItemRef":"prepare-materials","regionId":"delivery","responsibilityLaneId":"delivery-main","order":10,"label":{"zh-CN":"准备输入材料","en-US":"Prepare input materials"},"description":{"zh-CN":"把标准 Issue 正文与上传材料准备到指定目录","en-US":"Prepare standard Issue content and uploads in the designated directory"},"workContractRef":{"contractId":"development.prepare-materials","version":3},"materialSummary":{"zh-CN":"平台标准工作请求与材料输出目录","en-US":"Platform-standard work request and material output directory"},"completionStandard":{"zh-CN":"标准 Issue 正文与上传材料已在指定目录就绪","en-US":"Standard Issue content and uploads are ready in the designated directory"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"材料准备","en-US":"Material preparation"},"description":{"zh-CN":"规范化标准工作请求与上传材料","en-US":"Normalize the standard work request and uploaded materials"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"外部 ID 取得工具","en-US":"External ID acquisition tool"},"description":{"zh-CN":"仅当任务输入外部需求或问题 ID 时使用","en-US":"Used only when a task starts from an external requirement or issue ID"},"required":false,"cardinality":"zero-or-one"}]}],"nextWorkItemRefs":["analyze-implement"]},{"workItemRef":"analyze-implement","regionId":"delivery","responsibilityLaneId":"delivery-main","order":20,"label":{"zh-CN":"实现变更","en-US":"Implement change"},"description":{"zh-CN":"读取需求材料并完成代码修改","en-US":"Read the requirement materials and complete the code change"},"workContractRef":{"contractId":"development.implement-change","version":2},"materialSummary":{"zh-CN":"需求材料目录、已批准方案（如有）","en-US":"Requirements directory and approved plan when present"},"completionStandard":{"zh-CN":"代码修改完成，并给出提交与 MR 文案","en-US":"The code change is complete with commit and merge-request text"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":{"optionRef":"review-implementation-plan","artifactPort":"analysis-plan","planningRoleRef":"planning","planningSlotRef":"plan","label":{"zh-CN":"人工审核方案","en-US":"Human plan review"},"description":{"zh-CN":"任务受理时可选择先评审实现方案，批准后才执行实现工具","en-US":"The task may require plan approval before its implementation tool runs"},"reviewedPath":{"beforeReviewLabel":{"zh-CN":"编写实现方案","en-US":"Write implementation plan"},"afterApprovalLabel":{"zh-CN":"实现变更","en-US":"Implement change"}}},"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"实现变更","en-US":"Implement change"},"description":{"zh-CN":"根据需求材料完成代码实现","en-US":"Implement the change from the requirement materials"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"默认工具","en-US":"Default tool"},"description":{"zh-CN":"此工作项的确定性执行工具","en-US":"Deterministic executor for this work item"},"required":true,"cardinality":"exactly-one"}]},{"roleRef":"planning","label":{"zh-CN":"编写实现方案","en-US":"Write implementation plan"},"description":{"zh-CN":"按当前业务理解需求和仓库现场，形成供人工审核的实现方案","en-US":"Understand the request and repository in the current business context, then produce a plan for human review"},"order":1,"workContractRef":{"contractId":"development.plan-implementation","version":2},"bindingSlots":[{"slotRef":"plan","label":{"zh-CN":"实现方案编写工具","en-US":"Implementation plan writer"},"description":{"zh-CN":"启用方案审核时负责写实现方案；岗位可替换平台内置默认项","en-US":"Writes the implementation plan when plan review is enabled; the job may replace the platform default"},"required":false,"cardinality":"zero-or-one"}]}],"nextWorkItemRefs":["prepare-change"]},{"workItemRef":"prepare-change","regionId":"delivery","responsibilityLaneId":"delivery-main","order":30,"label":{"zh-CN":"校验并冻结代码修改","en-US":"Validate and freeze code changes"},"description":{"zh-CN":"校验工具结果与工作区修改，并冻结待提交快照","en-US":"Validate the tool result and workspace change, then freeze the pending snapshot"},"workContractRef":{"contractId":"development.prepare-change","version":1},"materialSummary":{"zh-CN":"已验证的修改提案","en-US":"Validated change proposal"},"completionStandard":{"zh-CN":"平台形成可提交的 change candidate","en-US":"The platform has produced a committable change candidate"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["publish-mr"]},{"workItemRef":"publish-mr","regionId":"delivery","responsibilityLaneId":"delivery-main","order":40,"label":{"zh-CN":"提交 MR","en-US":"Publish merge request"},"description":{"zh-CN":"平台负责 commit、CAS push 与 MR 创建","en-US":"The platform owns commit, CAS push, and MR creation"},"workContractRef":{"contractId":"development.publish-mr","version":1},"materialSummary":{"zh-CN":"Change candidate 与目标分支事实","en-US":"Change candidate and target branch facts"},"completionStandard":{"zh-CN":"平台完成 commit、CAS push 并创建或更新 MR 上下文","en-US":"The platform commits, CAS-pushes, and creates or updates the merge-request context"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-mr","reply-feedback"]},{"workItemRef":"observe-mr","regionId":"care","responsibilityLaneId":"care-attention","order":50,"label":{"zh-CN":"关注 MR 状态","en-US":"Observe merge request"},"description":{"zh-CN":"自动订阅或主动扫描 review、流水线、冲突和生命周期","en-US":"Automatically subscribe to or scan review, pipeline, conflict, and lifecycle state"},"workContractRef":{"contractId":"development.observe-mr","version":1},"materialSummary":{"zh-CN":"当前 MR、review、流水线和冲突关注范围","en-US":"Current merge request, review, pipeline, and conflict attention"},"completionStandard":{"zh-CN":"刷新同一 head 的权威 MR 事实并淘汰过时事件","en-US":"Refreshes authoritative same-head MR facts and obsoletes stale events"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["classify-feedback","collect-pipeline","repair-conflict","prepare-approval","evaluate-ready"]},{"workItemRef":"classify-feedback","regionId":"care","responsibilityLaneId":"care-review","order":60,"label":{"zh-CN":"汇总待处理检视意见","en-US":"Collect actionable review feedback"},"description":{"zh-CN":"平台收集当前 MR 全部未处理、非自身意见并逐条形成问题集合","en-US":"The platform collects every unresolved non-self thread and creates one problem per thread"},"workContractRef":{"contractId":"development.classify-feedback","version":1},"materialSummary":{"zh-CN":"当前 MR 的全部未处理、非自身检视意见","en-US":"Every unresolved non-self review thread on the current merge request"},"completionStandard":{"zh-CN":"平台逐条归一化为可追溯问题集合，不遗漏、不合并，也不选择下一动作","en-US":"The platform normalizes every thread into a traceable problem set without omission, merging, or action selection"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["acknowledge-feedback"]},{"workItemRef":"acknowledge-feedback","regionId":"care","responsibilityLaneId":"care-review","order":65,"label":{"zh-CN":"回复已收到","en-US":"Acknowledge review feedback"},"description":{"zh-CN":"平台逐线程回复固定收到消息，并以自身标记防止重复触发","en-US":"The platform acknowledges every thread and marks its own replies to prevent retriggering"},"workContractRef":{"contractId":"development.acknowledge-feedback","version":1},"materialSummary":{"zh-CN":"待处理检视线程和当前 MR","en-US":"Actionable review threads and the current merge request"},"completionStandard":{"zh-CN":"平台已逐线程回复收到并保存幂等笔迹","en-US":"The platform has acknowledged every thread and recorded idempotent markers"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["repair-feedback","observe-mr"]},{"workItemRef":"repair-feedback","regionId":"care","responsibilityLaneId":"care-review","order":70,"label":{"zh-CN":"处理检视意见","en-US":"Resolve review feedback"},"description":{"zh-CN":"逐线程处理意见，需要时修改代码","en-US":"Resolve every thread and change code when needed"},"workContractRef":{"contractId":"development.resolve-review-feedback","version":2},"materialSummary":{"zh-CN":"需求材料目录、完整检视线程","en-US":"Requirements directory and complete review threads"},"completionStandard":{"zh-CN":"每个线程都有回复；只有修改代码时才给出提交信息","en-US":"Every thread has a reply; a commit message is returned only when code changed"},"nodeKind":"business-tool","inputMultiplicity":"collection","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"问题修复者","en-US":"Problem repairer"},"description":{"zh-CN":"修复检视问题","en-US":"Repair review problems"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"默认工具","en-US":"Default tool"},"description":{"zh-CN":"此工作项的确定性执行工具","en-US":"Deterministic executor for this work item"},"required":true,"cardinality":"exactly-one"}]}],"nextWorkItemRefs":["prepare-change","reply-feedback"]},{"workItemRef":"reply-feedback","regionId":"care","responsibilityLaneId":"care-review","order":75,"label":{"zh-CN":"回复修复结果","en-US":"Reply with repair result"},"description":{"zh-CN":"平台把逐线程处理说明回复到原意见；有代码修改时先更新 MR","en-US":"The platform replies to each thread, updating the merge request first when code changed"},"workContractRef":{"contractId":"development.reply-feedback","version":1},"materialSummary":{"zh-CN":"已发布提交和 Agent 逐线程处理说明","en-US":"The published commit and the Agent treatment for every thread"},"completionStandard":{"zh-CN":"平台已把每条处理说明回复到原线程并保存回执","en-US":"The platform has replied to every original thread and recorded receipts"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-mr"]},{"workItemRef":"collect-pipeline","regionId":"care","responsibilityLaneId":"care-pipeline","order":80,"label":{"zh-CN":"采集流水线状态","en-US":"Collect pipeline status"},"description":{"zh-CN":"取得完整检查状态，并把大日志写入证据目录","en-US":"Collect complete check status and write large logs to the evidence directory"},"workContractRef":{"contractId":"development.collect-pipeline-status","version":3},"materialSummary":{"zh-CN":"系统连接、MR、证据目录","en-US":"Connection, merge request, and evidence directory"},"completionStandard":{"zh-CN":"返回所观察版本的完整流水线与检查状态","en-US":"Returns complete pipeline and check status for the observed version"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["classify-pipeline","observe-mr"]},{"workItemRef":"classify-pipeline","regionId":"care","responsibilityLaneId":"care-pipeline","order":90,"label":{"zh-CN":"分类流水线失败","en-US":"Classify pipeline failures"},"description":{"zh-CN":"把每个失败检查恰好归入一个已配置类型","en-US":"Assign every failed check to exactly one configured category"},"workContractRef":{"contractId":"development.classify-pipeline-failures","version":2},"materialSummary":{"zh-CN":"失败检查、问题类型、兜底分类","en-US":"Failed checks, categories, and fallback type"},"completionStandard":{"zh-CN":"每个失败检查恰好归入一个问题类型","en-US":"Every failed check belongs to exactly one category"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":{"label":{"zh-CN":"流水线问题与处理方式","en-US":"Pipeline problems and handlers"},"description":{"zh-CN":"问题类型与兜底分类由分类工具定义；岗位为每类问题选择处理方式并决定顺序","en-US":"The classifier tool defines problem types and the fallback; the job selects a handler and order for each type"},"destinationWorkItemRefs":["repair-pipeline","delegate"],"processingOrderOwner":"job"},"humanReview":null,"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"问题识别者","en-US":"Problem recognizer"},"description":{"zh-CN":"识别流水线失败类型","en-US":"Recognize pipeline failure types"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"默认工具","en-US":"Default tool"},"description":{"zh-CN":"此工作项的确定性执行工具","en-US":"Deterministic executor for this work item"},"required":true,"cardinality":"exactly-one"}]}],"nextWorkItemRefs":["repair-pipeline","delegate"]},{"workItemRef":"repair-pipeline","regionId":"care","responsibilityLaneId":"care-pipeline","order":100,"label":{"zh-CN":"修复流水线失败","en-US":"Repair pipeline failures"},"description":{"zh-CN":"工具声明能解决的问题；岗位按分类工具清单逐类选择兼容处理者","en-US":"Tools declare the problems they solve; jobs select a compatible handler for each classifier-tool problem"},"workContractRef":{"contractId":"development.repair-pipeline-failures","version":2},"materialSummary":{"zh-CN":"一个失败类型及其全部问题","en-US":"One failure type and all of its problems"},"completionStandard":{"zh-CN":"该类型问题已修复，并给出提交信息","en-US":"The assigned failures are repaired with a commit message"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[{"roleRef":"repairer","label":{"zh-CN":"问题修复","en-US":"Problem repair"},"description":{"zh-CN":"本工具显式声明可解决一个、多个或全部分类问题","en-US":"This tool explicitly declares that it solves one, multiple, or all classified problems"},"order":0,"bindingSlots":[]}],"nextWorkItemRefs":["repair-pipeline","delegate","prepare-change"]},{"workItemRef":"repair-conflict","regionId":"care","responsibilityLaneId":"care-conflict","order":110,"label":{"zh-CN":"解决合并冲突","en-US":"Resolve merge conflicts"},"description":{"zh-CN":"解决平台列出的冲突文件","en-US":"Resolve the conflict files listed by the platform"},"workContractRef":{"contractId":"development.resolve-merge-conflicts","version":2},"materialSummary":{"zh-CN":"源版本、目标版本、冲突文件、需求目录","en-US":"Source version, target version, conflict files, and requirements directory"},"completionStandard":{"zh-CN":"列出的冲突已解决，并给出提交信息","en-US":"The listed conflicts are resolved with a commit message"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"冲突修复者","en-US":"Conflict repairer"},"description":{"zh-CN":"修复代码冲突","en-US":"Repair merge conflicts"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"默认工具","en-US":"Default tool"},"description":{"zh-CN":"此工作项的确定性执行工具","en-US":"Deterministic executor for this work item"},"required":true,"cardinality":"exactly-one"}]}],"nextWorkItemRefs":["publish-conflict"]},{"workItemRef":"publish-conflict","regionId":"care","responsibilityLaneId":"care-conflict","order":115,"label":{"zh-CN":"提交冲突修复","en-US":"Commit conflict repair"},"description":{"zh-CN":"平台生成 merge commit、CAS 推送到远端并刷新 MR head","en-US":"The platform creates a merge commit, CAS-pushes it to the remote, and refreshes the MR head"},"workContractRef":{"contractId":"development.publish-conflict","version":1},"materialSummary":{"zh-CN":"已通过平台边界校验的冲突修复现场和固定父提交","en-US":"A boundary-validated conflict scene with pinned parent commits"},"completionStandard":{"zh-CN":"平台生成双父 merge commit、CAS 推送并刷新 MR head","en-US":"The platform creates a two-parent merge commit, CAS-pushes it, and refreshes the MR head"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-mr"]},{"workItemRef":"delegate","regionId":"care","responsibilityLaneId":"care-collaboration","order":120,"label":{"zh-CN":"协同其他数字员工","en-US":"Collaborate with another employee"},"description":{"zh-CN":"异步调起其他员工并等待事件返回","en-US":"Invoke another employee asynchronously and wait for an event result"},"workContractRef":{"contractId":"development.delegate","version":1},"materialSummary":{"zh-CN":"目标员工、工作范围和类型化输入 envelope","en-US":"Target employee, work scope, and typed input envelope"},"completionStandard":{"zh-CN":"异步子员工返回可重验结果，父员工不持有等待进程","en-US":"An asynchronous child employee returns a revalidatable result without a waiting parent process"},"nodeKind":"collaboration","collaborationContractId":"development.cross-repository-work","orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["collect-pipeline"]},{"workItemRef":"prepare-approval","regionId":"care","responsibilityLaneId":"care-approval","order":122,"label":{"zh-CN":"编写审批草稿","en-US":"Draft approval"},"description":{"zh-CN":"根据当前 MR 和门禁结论形成审批草稿","en-US":"Draft an approval from the current merge request and gate conclusions"},"workContractRef":{"contractId":"development.draft-approval","version":2},"materialSummary":{"zh-CN":"MR、当前版本、审批类型、门禁结论、格式说明","en-US":"Merge request, current version, approval type, gate conclusions, and format guide"},"completionStandard":{"zh-CN":"形成可提交的审批草稿","en-US":"Produces a submission-ready approval draft"},"nodeKind":"business-tool","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[{"roleRef":"primary","label":{"zh-CN":"审批材料准备者","en-US":"Approval material preparer"},"description":{"zh-CN":"生成可提交的审批草稿","en-US":"Produce a submission-ready approval draft"},"order":0,"bindingSlots":[{"slotRef":"default","label":{"zh-CN":"默认工具","en-US":"Default tool"},"description":{"zh-CN":"此工作项的确定性执行工具","en-US":"Deterministic executor for this work item"},"required":true,"cardinality":"exactly-one"}]}],"nextWorkItemRefs":["submit-approval"]},{"workItemRef":"submit-approval","regionId":"care","responsibilityLaneId":"care-approval","order":124,"label":{"zh-CN":"提交外部审批","en-US":"Submit external approval"},"description":{"zh-CN":"平台通过已注册审批程序按幂等键提交或认领审批","en-US":"Use the registered approval program to submit or adopt an approval idempotently"},"workContractRef":{"contractId":"development.submit-approval","version":1},"materialSummary":{"zh-CN":"已校验审批草稿和固定审批系统连接","en-US":"Validated approval draft and pinned approval-system connection"},"completionStandard":{"zh-CN":"平台按幂等键提交或认领既有审批，并保存 correlation receipt","en-US":"The platform submits or adopts the approval by idempotency key and stores its correlation receipt"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-approval"]},{"workItemRef":"observe-approval","regionId":"care","responsibilityLaneId":"care-approval","order":126,"label":{"zh-CN":"等待外部审批","en-US":"Wait for external approval"},"description":{"zh-CN":"事件中心按关注范围启动短轮询；无人关注时自动停止","en-US":"Event Center runs short observations only while the approval is subscribed"},"workContractRef":{"contractId":"development.observe-approval","version":1},"materialSummary":{"zh-CN":"审批 correlation、截止时间和最新权威 revision","en-US":"Approval correlation, deadline, and latest authoritative revision"},"completionStandard":{"zh-CN":"短调用取得 pending、approved、rejected、expired 或 unavailable 终态","en-US":"A short call returns pending, approved, rejected, expired, or unavailable"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-mr"]},{"workItemRef":"evaluate-ready","regionId":"care","responsibilityLaneId":"care-readiness","order":130,"label":{"zh-CN":"判断是否随时可合入","en-US":"Evaluate merge readiness"},"description":{"zh-CN":"区分机器门禁、人工门禁和代码平台可合入状态","en-US":"Separate machine gates, human gates, and code-host mergeability"},"workContractRef":{"contractId":"development.evaluate-ready","version":1},"materialSummary":{"zh-CN":"同一 head 的机器门禁、人工门禁和代码平台 mergeability","en-US":"Same-head machine gates, human gates, and code-host mergeability"},"completionStandard":{"zh-CN":"给出可解释的 ready-to-merge 判定，平台不自动合入","en-US":"Produces an explainable ready-to-merge result without automatic merge"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["wait-merge","observe-mr"]},{"workItemRef":"wait-merge","regionId":"care","responsibilityLaneId":"care-readiness","order":140,"label":{"zh-CN":"等待审核合入","en-US":"Wait for committer merge"},"description":{"zh-CN":"平台不自动合入，只跟踪到外部 merged 或 closed","en-US":"The platform never auto-merges and only tracks external merge or close"},"workContractRef":{"contractId":"development.wait-merge","version":1},"materialSummary":{"zh-CN":"ready-to-merge MR 与生命周期关注范围","en-US":"Ready-to-merge MR and lifecycle attention"},"completionStandard":{"zh-CN":"持续跟踪到外部 merged 或 closed 终态","en-US":"Tracks until the external merged or closed terminal state"},"nodeKind":"system","collaborationContractId":null,"orderedDispatchAuthoring":null,"humanReview":null,"toolRoleGroups":[],"nextWorkItemRefs":["observe-mr"]}]},"workStartWorkItemRef":"prepare-materials","workContracts":[{"contractId":"development.prepare-materials","version":1,"inputSchemaId":"development.work-request.v1","outputSchemaId":"development.requirement-context.v1","materialSummary":{"zh-CN":"需求正文、附件或外部问题单引用","en-US":"Requirement body, attachments, or an external work-item reference"},"completionStandard":{"zh-CN":"形成完整、可追溯的需求上下文和仓库文件落点","en-US":"A complete traceable requirement context and repository file placement plan exists"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"optional","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.prepare-materials.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.analyze-implement","version":1,"inputSchemaId":"development.requirement-context.v1","outputSchemaId":"development.change-proposal.v1","materialSummary":{"zh-CN":"需求上下文、仓库快照和已有诊断证据","en-US":"Requirement context, repository snapshot, and existing diagnostics"},"completionStandard":{"zh-CN":"输出符合 envelope 的修改提案和验证说明，不执行 Git 或代码平台操作","en-US":"Produces an envelope-valid change proposal and verification notes without Git or code-host effects"},"allowedToolKinds":["agent","workflow"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.analyze-implement.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.prepare-change","version":1,"inputSchemaId":"development.change-proposal.v1","outputSchemaId":"development.change-candidate.v1","materialSummary":{"zh-CN":"已验证的修改提案","en-US":"Validated change proposal"},"completionStandard":{"zh-CN":"平台形成可提交的 change candidate","en-US":"The platform has produced a committable change candidate"},"allowedToolKinds":[],"allowedEffectKinds":["source-control.candidate"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.prepare-change.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.publish-mr","version":1,"inputSchemaId":"development.change-candidate.v1","outputSchemaId":"development.merge-request-context.v1","materialSummary":{"zh-CN":"Change candidate 与目标分支事实","en-US":"Change candidate and target branch facts"},"completionStandard":{"zh-CN":"平台完成 commit、CAS push 并创建或更新 MR 上下文","en-US":"The platform commits, CAS-pushes, and creates or updates the merge-request context"},"allowedToolKinds":[],"allowedEffectKinds":["source-control.commit","source-control.push","code-host.merge-request.ensure"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.publish-mr.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.observe-mr","version":1,"inputSchemaId":"development.merge-request-context.v1","outputSchemaId":"development.merge-request-facts.v1","materialSummary":{"zh-CN":"当前 MR、review、流水线和冲突关注范围","en-US":"Current merge request, review, pipeline, and conflict attention"},"completionStandard":{"zh-CN":"刷新同一 head 的权威 MR 事实并淘汰过时事件","en-US":"Refreshes authoritative same-head MR facts and obsoletes stale events"},"allowedToolKinds":[],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.observe-mr.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.classify-feedback","version":1,"inputSchemaId":"development.review-evidence.v1","outputSchemaId":"development.problem-set.v1","materialSummary":{"zh-CN":"当前 MR 的全部未处理、非自身检视意见","en-US":"Every unresolved non-self review thread on the current merge request"},"completionStandard":{"zh-CN":"平台逐条归一化为可追溯问题集合，不遗漏、不合并，也不选择下一动作","en-US":"The platform normalizes every thread into a traceable problem set without omission, merging, or action selection"},"allowedToolKinds":[],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.classify-feedback.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.repair-feedback","version":1,"inputSchemaId":"development.problem-set.v1","outputSchemaId":"development.change-proposal.v1","materialSummary":{"zh-CN":"类型化检视问题、对应代码和评论上下文","en-US":"Typed review problems with corresponding code and comment context"},"completionStandard":{"zh-CN":"修复所有分配问题并输出修改 envelope","en-US":"Repairs every assigned problem and emits a change envelope"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.repair-feedback.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.collect-pipeline","version":1,"inputSchemaId":"development.merge-request-context.v1","outputSchemaId":"development.pipeline-evidence.v1","materialSummary":{"zh-CN":"MR head、流水线标识和已注册系统连接","en-US":"MR head, pipeline identity, and registered system connection"},"completionStandard":{"zh-CN":"程序化取得完整门禁状态，大日志落入 pipeline evidence 目录","en-US":"Programmatically obtains complete gate state and stores large logs in pipeline evidence"},"allowedToolKinds":["program","workflow"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":["pipeline"]},"semanticValidatorId":"development.collect-pipeline.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.classify-pipeline","version":1,"inputSchemaId":"development.pipeline-evidence.v1","outputSchemaId":"development.problem-set.v1","materialSummary":{"zh-CN":"结构化门禁结果和大日志 artifact 引用","en-US":"Structured gate results and large-log artifact references"},"completionStandard":{"zh-CN":"产出命中本工具闭集的问题记录与待处理种类；平台随后按固定优先级逐类调度，未知项进入兜底类型","en-US":"Produces problem records and remaining categories from this tool's closed set; the platform then dispatches each category by fixed priority with an explicit unknown fallback"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.classify-pipeline.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.repair-pipeline","version":1,"inputSchemaId":"development.problem-set.v1","outputSchemaId":"development.change-proposal.v1","materialSummary":{"zh-CN":"平台分配的唯一问题种类、该类问题记录、流水线证据和当前代码","en-US":"The one assigned problem category, its problem records, pipeline evidence, and current code"},"completionStandard":{"zh-CN":"对应槽位工具修复该种类的全部问题并输出修改 envelope","en-US":"The bound slot tool repairs every problem in that category and emits a change envelope"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.repair-pipeline.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.repair-conflict","version":1,"inputSchemaId":"development.conflict-context.v1","outputSchemaId":"development.change-proposal.v1","materialSummary":{"zh-CN":"平台准备的冲突现场、父提交和冲突文件集合","en-US":"Platform-prepared conflict scene, parent commits, and conflict file set"},"completionStandard":{"zh-CN":"只修改授权冲突文件并输出 envelope","en-US":"Modifies only authorized conflict files and emits an envelope"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.repair-conflict.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.delegate","version":1,"inputSchemaId":"employee.invocation-request.v1","outputSchemaId":"employee.invocation-result.v1","materialSummary":{"zh-CN":"目标员工、工作范围和类型化输入 envelope","en-US":"Target employee, work scope, and typed input envelope"},"completionStandard":{"zh-CN":"异步子员工返回可重验结果，父员工不持有等待进程","en-US":"An asynchronous child employee returns a revalidatable result without a waiting parent process"},"allowedToolKinds":[],"allowedEffectKinds":["employee.invocation.create"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.delegate.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.evaluate-ready","version":1,"inputSchemaId":"development.merge-request-facts.v1","outputSchemaId":"development.readiness.v1","materialSummary":{"zh-CN":"同一 head 的机器门禁、人工门禁和代码平台 mergeability","en-US":"Same-head machine gates, human gates, and code-host mergeability"},"completionStandard":{"zh-CN":"给出可解释的 ready-to-merge 判定，平台不自动合入","en-US":"Produces an explainable ready-to-merge result without automatic merge"},"allowedToolKinds":[],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.evaluate-ready.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.wait-merge","version":1,"inputSchemaId":"development.readiness.v1","outputSchemaId":"development.terminal.v1","materialSummary":{"zh-CN":"ready-to-merge MR 与生命周期关注范围","en-US":"Ready-to-merge MR and lifecycle attention"},"completionStandard":{"zh-CN":"持续跟踪到外部 merged 或 closed 终态","en-US":"Tracks until the external merged or closed terminal state"},"allowedToolKinds":[],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.wait-merge.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.publish-conflict","version":1,"inputSchemaId":"development.change-proposal.v1","outputSchemaId":"development.merge-request-context.v1","materialSummary":{"zh-CN":"已通过平台边界校验的冲突修复现场和固定父提交","en-US":"A boundary-validated conflict scene with pinned parent commits"},"completionStandard":{"zh-CN":"平台生成双父 merge commit、CAS 推送并刷新 MR head","en-US":"The platform creates a two-parent merge commit, CAS-pushes it, and refreshes the MR head"},"allowedToolKinds":[],"allowedEffectKinds":["source-control.commit","source-control.push"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.publish-conflict.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.prepare-approval","version":1,"inputSchemaId":"development.merge-request-context.v1","outputSchemaId":"development.approval-draft.v1","materialSummary":{"zh-CN":"当前 MR 门禁事实、审批类型和审批系统连接","en-US":"Current merge-request gate facts, approval type, and approval-system connection"},"completionStandard":{"zh-CN":"形成绑定当前 MR head 的严格审批草稿引用；Agent 不持有凭据且不能直接提交","en-US":"Produces a strict approval draft bound to the current MR head without credentials or direct submission"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":"approval-gateway","workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.prepare-approval.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.submit-approval","version":1,"inputSchemaId":"development.approval-draft.v1","outputSchemaId":"development.approval-receipt.v1","materialSummary":{"zh-CN":"已校验审批草稿和固定审批系统连接","en-US":"Validated approval draft and pinned approval-system connection"},"completionStandard":{"zh-CN":"平台按幂等键提交或认领既有审批，并保存 correlation receipt","en-US":"The platform submits or adopts the approval by idempotency key and stores its correlation receipt"},"allowedToolKinds":[],"allowedEffectKinds":["external-approval.submit"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.submit-approval.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.observe-approval","version":1,"inputSchemaId":"development.approval-receipt.v1","outputSchemaId":"development.approval-observation.v1","materialSummary":{"zh-CN":"审批 correlation、截止时间和最新权威 revision","en-US":"Approval correlation, deadline, and latest authoritative revision"},"completionStandard":{"zh-CN":"短调用取得 pending、approved、rejected、expired 或 unavailable 终态","en-US":"A short call returns pending, approved, rejected, expired, or unavailable"},"allowedToolKinds":[],"allowedEffectKinds":["external-approval.observe"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.observe-approval.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.acknowledge-feedback","version":1,"inputSchemaId":"development.review-resolution.v1","outputSchemaId":"development.review-resolution.v1","materialSummary":{"zh-CN":"待处理检视线程和当前 MR","en-US":"Actionable review threads and the current merge request"},"completionStandard":{"zh-CN":"平台已逐线程回复收到并保存幂等笔迹","en-US":"The platform has acknowledged every thread and recorded idempotent markers"},"allowedToolKinds":[],"allowedEffectKinds":["code-host.merge-request.reply"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.acknowledge-feedback.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.reply-feedback","version":1,"inputSchemaId":"development.review-resolution.v1","outputSchemaId":"development.review-resolution.v1","materialSummary":{"zh-CN":"已发布提交和 Agent 逐线程处理说明","en-US":"The published commit and the Agent treatment for every thread"},"completionStandard":{"zh-CN":"平台已把每条处理说明回复到原线程并保存回执","en-US":"The platform has replied to every original thread and recorded receipts"},"allowedToolKinds":[],"allowedEffectKinds":["code-host.merge-request.reply"],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"none","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.reply-feedback.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.analyze-plan","version":1,"inputSchemaId":"development.requirement-context.v1","outputSchemaId":"development.implementation-plan-path.v1","materialSummary":{"zh-CN":"冻结的需求材料、仓库现场和方案文档精确路径","en-US":"Frozen requirement materials, repository state, and exact plan document path"},"completionStandard":{"zh-CN":"只写入指定 Markdown 方案，并从 analysis-plan 输出同一路径；不输出 agent-result envelope","en-US":"Writes only the designated Markdown plan and emits the same path from analysis-plan; no agent-result envelope is produced"},"allowedToolKinds":["agent"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.analyze-plan.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.prepare-materials","version":2,"inputSchemaId":"development.prepare-materials.input.v2","outputSchemaId":"development.prepare-materials.result.v2","materialSummary":{"zh-CN":"系统连接、外部事项编号、材料输出目录","en-US":"Connection, external item ID, and material output directory"},"completionStandard":{"zh-CN":"外部事项的材料文件已写入指定目录","en-US":"External item files are written to the specified directory"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":"requirement-source","workspacePolicy":{"mode":"write","businessChangeOnOk":"optional","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.prepare-materials.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.plan-implementation","version":2,"inputSchemaId":"development.plan-implementation.input.v2","outputSchemaId":"development.plan-implementation.path.v2","materialSummary":{"zh-CN":"需求材料目录、方案文件路径","en-US":"Requirements directory and plan file path"},"completionStandard":{"zh-CN":"指定 Markdown 方案已写好，并返回同一路径","en-US":"The designated Markdown plan is written and the same path is returned"},"allowedToolKinds":["agent"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.plan-implementation.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.implement-change","version":2,"inputSchemaId":"development.implement-change.input.v2","outputSchemaId":"development.implement-change.result.v2","materialSummary":{"zh-CN":"需求材料目录、已批准方案（如有）","en-US":"Requirements directory and approved plan when present"},"completionStandard":{"zh-CN":"代码修改完成，并给出提交与 MR 文案","en-US":"The code change is complete with commit and merge-request text"},"allowedToolKinds":["agent","workflow"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.implement-change.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.resolve-review-feedback","version":2,"inputSchemaId":"development.resolve-review-feedback.input.v2","outputSchemaId":"development.resolve-review-feedback.result.v2","materialSummary":{"zh-CN":"需求材料目录、完整检视线程","en-US":"Requirements directory and complete review threads"},"completionStandard":{"zh-CN":"每个线程都有回复；只有修改代码时才给出提交信息","en-US":"Every thread has a reply; a commit message is returned only when code changed"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"optional","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.resolve-review-feedback.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.collect-pipeline-status","version":2,"inputSchemaId":"development.collect-pipeline-status.input.v2","outputSchemaId":"development.collect-pipeline-status.result.v2","materialSummary":{"zh-CN":"系统连接、MR、证据目录","en-US":"Connection, merge request, and evidence directory"},"completionStandard":{"zh-CN":"返回所观察版本的完整流水线与检查状态","en-US":"Returns complete pipeline and check status for the observed version"},"allowedToolKinds":["workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":"pipeline-gate","workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":["pipeline"]},"semanticValidatorId":"development.collect-pipeline-status.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.classify-pipeline-failures","version":2,"inputSchemaId":"development.classify-pipeline-failures.input.v2","outputSchemaId":"development.classify-pipeline-failures.result.v2","materialSummary":{"zh-CN":"失败检查、问题类型、兜底分类","en-US":"Failed checks, categories, and fallback type"},"completionStandard":{"zh-CN":"每个失败检查恰好归入一个问题类型","en-US":"Every failed check belongs to exactly one category"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.classify-pipeline-failures.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.repair-pipeline-failures","version":2,"inputSchemaId":"development.repair-pipeline-failures.input.v2","outputSchemaId":"development.repair-pipeline-failures.result.v2","materialSummary":{"zh-CN":"一个失败类型及其全部问题","en-US":"One failure type and all of its problems"},"completionStandard":{"zh-CN":"该类型问题已修复，并给出提交信息","en-US":"The assigned failures are repaired with a commit message"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.repair-pipeline-failures.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.resolve-merge-conflicts","version":2,"inputSchemaId":"development.resolve-merge-conflicts.input.v2","outputSchemaId":"development.resolve-merge-conflicts.result.v2","materialSummary":{"zh-CN":"源版本、目标版本、冲突文件、需求目录","en-US":"Source version, target version, conflict files, and requirements directory"},"completionStandard":{"zh-CN":"列出的冲突已解决，并给出提交信息","en-US":"The listed conflicts are resolved with a commit message"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"required","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.resolve-merge-conflicts.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.draft-approval","version":2,"inputSchemaId":"development.draft-approval.input.v2","outputSchemaId":"development.draft-approval.result.v2","materialSummary":{"zh-CN":"MR、当前版本、审批类型、门禁结论、格式说明","en-US":"Merge request, current version, approval type, gate conclusions, and format guide"},"completionStandard":{"zh-CN":"形成可提交的审批草稿","en-US":"Produces a submission-ready approval draft"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":"approval-gateway","workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":[]},"semanticValidatorId":"development.draft-approval.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.prepare-materials","version":3,"inputSchemaId":"development.prepare-materials.input.v3","outputSchemaId":"development.prepare-materials.result.v2","materialSummary":{"zh-CN":"平台标准工作请求与材料输出目录","en-US":"Platform-standard work request and material output directory"},"completionStandard":{"zh-CN":"标准 Issue 正文与上传材料已在指定目录就绪","en-US":"Standard Issue content and uploads are ready in the designated directory"},"allowedToolKinds":["agent","workflow","program"],"allowedEffectKinds":[],"requiredConnectionPurpose":null,"workspacePolicy":{"mode":"write","businessChangeOnOk":"optional","writablePrefixes":[],"platformWritePrefixes":["inputs/requirements"]},"semanticValidatorId":"development.prepare-materials.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}},{"contractId":"development.collect-pipeline-status","version":3,"inputSchemaId":"development.collect-pipeline-status.input.v2","outputSchemaId":"development.collect-pipeline-status.result.v2","materialSummary":{"zh-CN":"系统连接、MR、证据目录","en-US":"Connection, merge request, and evidence directory"},"completionStandard":{"zh-CN":"返回所观察版本的完整流水线与检查状态","en-US":"Returns complete pipeline and check status for the observed version"},"allowedToolKinds":[],"allowedEffectKinds":["integration.adapter.execute"],"requiredConnectionPurpose":"pipeline-gate","workspacePolicy":{"mode":"read-only","businessChangeOnOk":"forbidden","writablePrefixes":[],"platformWritePrefixes":["pipeline"]},"semanticValidatorId":"development.collect-pipeline-status.v2.validator","fixtureSuiteRef":{"id":"builtin:development-work-contract-fixtures","revision":1}}],"contextTypes":[{"typeId":"development.issue-handling","schemaVersion":1,"displayName":{"zh-CN":"需求或问题上下文","en-US":"Requirement or problem context"},"description":{"zh-CN":"保存工作材料、目标和来源追踪","en-US":"Stores work materials, target, and provenance"},"projectionFields":[{"path":"subjectRef","label":{"zh-CN":"工作对象","en-US":"Work item"},"format":"text"},{"path":"request.body","label":{"zh-CN":"需求正文","en-US":"Request body"},"format":"text"},{"path":"request.externalId","label":{"zh-CN":"外部编号","en-US":"External ID"},"format":"text"},{"path":"request.uploads","label":{"zh-CN":"随代码提交的文件","en-US":"Committed files"},"format":"count"}]},{"typeId":"development.change-candidate","schemaVersion":1,"displayName":{"zh-CN":"修改候选上下文","en-US":"Change candidate context"},"description":{"zh-CN":"保存平台独立计算的差异、树身份与发布状态","en-US":"Stores the platform-derived delta, tree identity, and publication state"},"projectionFields":[{"path":"changedPaths","label":{"zh-CN":"修改文件","en-US":"Changed files"},"format":"count"},{"path":"baselineSha","label":{"zh-CN":"基线提交","en-US":"Baseline"},"format":"short-hash"}]},{"typeId":"development.merge-request","schemaVersion":1,"displayName":{"zh-CN":"MR 上下文","en-US":"Merge request context"},"description":{"zh-CN":"保存 MR 身份、head 与关注范围","en-US":"Stores merge-request identity, head, and attention"},"projectionFields":[{"path":"mergeRequestRef","label":{"zh-CN":"MR","en-US":"MR"},"format":"text"},{"path":"headSha","label":{"zh-CN":"当前提交","en-US":"Current commit"},"format":"short-hash"},{"path":"readyToMerge","label":{"zh-CN":"随时可合入","en-US":"Ready to merge"},"format":"boolean"}]},{"typeId":"development.pipeline","schemaVersion":1,"displayName":{"zh-CN":"流水线上下文","en-US":"Pipeline context"},"description":{"zh-CN":"保存门禁摘要和大日志 artifact 引用","en-US":"Stores gate summaries and large-log artifact references"},"projectionFields":[{"path":"status","label":{"zh-CN":"门禁结果","en-US":"Gate result"},"format":"text"},{"path":"failureTypes","label":{"zh-CN":"失败类型","en-US":"Failure types"},"format":"list"},{"path":"headSha","label":{"zh-CN":"对应提交","en-US":"Commit"},"format":"short-hash"},{"path":"targetSha","label":{"zh-CN":"目标提交","en-US":"Target commit"},"format":"short-hash"}]},{"typeId":"development.problem-set","schemaVersion":1,"displayName":{"zh-CN":"待处理问题集合","en-US":"Problem set"},"description":{"zh-CN":"保存检视或流水线问题类型、证据引用与尚未处理的工具槽位","en-US":"Stores review or pipeline problem types, evidence references, and remaining tool slots"},"projectionFields":[{"path":"problems","label":{"zh-CN":"待处理问题","en-US":"Open problems"},"format":"count"},{"path":"remainingTypes","label":{"zh-CN":"剩余类型","en-US":"Remaining types"},"format":"list"}]},{"typeId":"development.review-resolution","schemaVersion":1,"displayName":{"zh-CN":"检视处理台账","en-US":"Review resolution ledger"},"description":{"zh-CN":"保存每个检视线程版本的确认、处理结论、发布提交和最终回复回执","en-US":"Stores acknowledgements, dispositions, published commits, and final reply receipts for every review-thread revision"},"projectionFields":[{"path":"status","label":{"zh-CN":"处理状态","en-US":"Resolution status"},"format":"text"},{"path":"threads","label":{"zh-CN":"线程版本","en-US":"Thread revisions"},"format":"count"},{"path":"publishedHeadSha","label":{"zh-CN":"发布提交","en-US":"Published commit"},"format":"short-hash"}]},{"typeId":"development.delegation","schemaVersion":1,"displayName":{"zh-CN":"协同上下文","en-US":"Delegation context"},"description":{"zh-CN":"保存跨员工调用与返回结果","en-US":"Stores cross-employee invocation and result"},"projectionFields":[{"path":"status","label":{"zh-CN":"协作状态","en-US":"Collaboration status"},"format":"text"},{"path":"members","label":{"zh-CN":"协作员工","en-US":"Collaborating employees"},"format":"count"}]},{"typeId":"development.approval","schemaVersion":1,"displayName":{"zh-CN":"外部审批上下文","en-US":"External approval context"},"description":{"zh-CN":"保存审批草稿、幂等提交回执、correlation、截止时间和最新观察状态","en-US":"Stores the approval draft, idempotent submission receipt, correlation, deadline, and latest observed state"},"projectionFields":[{"path":"status","label":{"zh-CN":"审批状态","en-US":"Approval status"},"format":"text"},{"path":"externalRequestRef","label":{"zh-CN":"审批单","en-US":"Approval request"},"format":"text"},{"path":"deadlineAt","label":{"zh-CN":"等待截止","en-US":"Wait deadline"},"format":"timestamp"}]}],"eventSources":[{"sourceId":"code-host.activity","version":1,"ownerTypeId":"integration.code-host","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"通过 Webhook 实时接收变化，并在有人关注时用短轮询补齐权威状态。","en-US":"Receives real-time changes through webhooks and reconciles authoritative state by short polling while subscribed."},"observationMode":"hybrid","observerProgramRef":{"id":"builtin:development-code-host-observer","revision":1},"pollIntervalMs":30000,"batchSize":100},{"sourceId":"employee.channel","version":1,"displayName":{"zh-CN":"数字员工协同通道","en-US":"Digital employee collaboration channel"},"description":{"zh-CN":"传递子员工公开里程碑与完成结果","en-US":"Carries child employee milestones and completion results"},"observationMode":"passive","observerProgramRef":null,"pollIntervalMs":60000,"batchSize":100},{"sourceId":"development.approval-state","version":1,"displayName":{"zh-CN":"外部审批状态观察","en-US":"External approval state observation"},"description":{"zh-CN":"只在有数字员工关注审批时启动已注册程序进行短轮询","en-US":"Runs the registered short observer only while an employee subscribes to the approval"},"observationMode":"hybrid","observerProgramRef":{"id":"builtin:development-approval-observer","revision":1},"pollIntervalMs":30000,"batchSize":100}],"eventTypes":[{"eventTypeId":"development.review-updated","version":2,"subjectTypeId":"merge-request","payloadSchemaId":"development.review.event.v1","displayName":{"zh-CN":"MR 检视意见有更新","en-US":"MR review feedback updated"},"description":{"zh-CN":"出现新的或发生变化的检视意见","en-US":"New or changed review feedback is available"},"deliveryClass":"review","sourceRef":{"id":"code-host.activity","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"development.conflict-updated","version":2,"subjectTypeId":"merge-request","payloadSchemaId":"development.conflict.event.v1","displayName":{"zh-CN":"MR 冲突状态有更新","en-US":"MR conflict state updated"},"description":{"zh-CN":"目标分支变化导致冲突出现或消失","en-US":"Target branch changes introduced or cleared a conflict"},"deliveryClass":"conflict","sourceRef":{"id":"code-host.activity","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"development.lifecycle-updated","version":2,"subjectTypeId":"merge-request","payloadSchemaId":"development.lifecycle.event.v1","displayName":{"zh-CN":"MR 生命周期有更新","en-US":"MR lifecycle updated"},"description":{"zh-CN":"MR 已合入、关闭、重新打开或 head 发生变化","en-US":"The MR was merged, closed, reopened, or moved to another head"},"deliveryClass":"terminal","sourceRef":{"id":"code-host.activity","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"development.pipeline-check-due","version":1,"subjectTypeId":"merge-request","payloadSchemaId":"development.pipeline-check-due.v1","displayName":{"zh-CN":"MR 门禁复核到期","en-US":"MR gate recheck due"},"description":{"zh-CN":"下一次主动门禁复核时间已经到达，只用于唤醒正在关注此 MR 的数字员工","en-US":"The next active gate recheck is due; this only wakes employees already watching the MR"},"deliveryClass":"pipeline","sourceRef":{"id":"code-host.activity","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"development.employee-result","version":1,"subjectTypeId":"employee-invocation","payloadSchemaId":"employee.invocation-result.v1","displayName":{"zh-CN":"协同员工返回结果","en-US":"Collaborating employee returned a result"},"description":{"zh-CN":"被调起的数字员工返回了可重验的里程碑或终态结果","en-US":"An invoked employee returned a revalidatable milestone or terminal result"},"deliveryClass":"collaboration","priority":600,"sourceRef":{"id":"employee.channel","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"development.approval-updated","version":1,"subjectTypeId":"external-approval","payloadSchemaId":"development.approval-observation.v1","displayName":{"zh-CN":"外部审批状态有更新","en-US":"External approval status updated"},"description":{"zh-CN":"审批系统返回了新的权威 revision 或终态","en-US":"The approval system returned a new authoritative revision or terminal state"},"deliveryClass":"approval","priority":850,"sourceRef":{"id":"development.approval-state","revision":1},"catalogVisibility":"internal","triggerParameters":null},{"eventTypeId":"approval.status.changed","version":1,"subjectTypeId":"external-approval","payloadSchemaId":"approval.status-change.v1","displayName":{"zh-CN":"外部审批状态已变化","en-US":"External approval status changed"},"description":{"zh-CN":"外部审批系统返回了新的权威状态或修订","en-US":"An external approval system returned a new authoritative status or revision"},"deliveryClass":"approval-business-event","sourceRef":{"id":"development.approval-state","revision":1},"triggerParameters":{"namespace":"approval","fields":[{"fieldId":"subject_ref","displayName":{"zh-CN":"审批对象","en-US":"Approval subject"},"description":{"zh-CN":"审批对象","en-US":"Approval subject"}}]}}],"attentionRules":[{"ruleId":"watch-merge-request","contextTypeId":"development.merge-request","whenState":"active","subscriptions":[{"eventTypeId":"development.review-updated","subjectPath":"$.mergeRequestRef","sourceProfileRef":null,"deliveryClass":"review"},{"eventTypeId":"development.conflict-updated","subjectPath":"$.mergeRequestRef","sourceProfileRef":null,"deliveryClass":"conflict"},{"eventTypeId":"development.lifecycle-updated","subjectPath":"$.mergeRequestRef","sourceProfileRef":null,"deliveryClass":"terminal"}]},{"ruleId":"watch-pipeline-gate","contextTypeId":"development.pipeline","whenState":"active","subscriptions":[{"eventTypeId":"development.pipeline-check-due","subjectPath":"$.mergeRequestRef","sourceProfileRef":null,"deliveryClass":"pipeline"}]},{"ruleId":"watch-delegation","contextTypeId":"development.delegation","whenState":"active","subscriptions":[{"eventTypeId":"development.employee-result","subjectPath":"$.invocationRef","sourceProfileRef":null,"deliveryClass":"collaboration"}]},{"ruleId":"watch-external-approval","contextTypeId":"development.approval","whenState":"active","subscriptions":[{"eventTypeId":"development.approval-updated","subjectPath":"$.subjectRef","sourceProfileRef":null,"deliveryClass":"approval"}]}],"reactionRules":[{"ruleId":"handle-review","eventTypeId":"development.review-updated","priority":900,"preemptsContinuation":true,"requiredContextTypes":["development.issue-handling","development.merge-request","development.pipeline"],"optionalContextTypes":["development.problem-set","development.review-resolution"],"capabilityWorkItemRef":"classify-feedback","workItemRef":"observe-mr","slotRef":"system","allowedEffectKinds":[]},{"ruleId":"handle-pipeline","eventTypeId":"development.pipeline-check-due","priority":700,"preemptsContinuation":false,"requiredContextTypes":["development.issue-handling","development.merge-request","development.pipeline"],"optionalContextTypes":[],"workItemRef":"collect-pipeline","slotRef":"system","allowedEffectKinds":[]},{"ruleId":"handle-conflict","eventTypeId":"development.conflict-updated","priority":800,"preemptsContinuation":true,"requiredContextTypes":["development.issue-handling","development.merge-request","development.pipeline"],"optionalContextTypes":["development.problem-set","development.review-resolution"],"capabilityWorkItemRef":"repair-conflict","workItemRef":"observe-mr","slotRef":"system","allowedEffectKinds":[]},{"ruleId":"handle-lifecycle","eventTypeId":"development.lifecycle-updated","priority":1000,"preemptsContinuation":true,"requiredContextTypes":["development.merge-request","development.pipeline"],"optionalContextTypes":["development.problem-set","development.review-resolution"],"workItemRef":"observe-mr","slotRef":"system","allowedEffectKinds":[]},{"ruleId":"handle-employee-result","eventTypeId":"development.employee-result","priority":600,"preemptsContinuation":false,"requiredContextTypes":["development.delegation"],"optionalContextTypes":[],"workItemRef":"delegate","slotRef":"collaboration","allowedEffectKinds":[]},{"ruleId":"handle-approval-update","eventTypeId":"development.approval-updated","priority":850,"preemptsContinuation":true,"requiredContextTypes":["development.approval"],"optionalContextTypes":[],"workItemRef":"observe-approval","slotRef":"system","allowedEffectKinds":["external-approval.observe"]}],"invocationContracts":[{"contractId":"development.cross-repository-work","inputSchemaId":"development.delegated-work.v1","resultSchemaId":"development.delegated-result.v1","milestoneEventTypeIds":["development.employee-result"]}]}	a856faea23ec4c6ce2f4def3cba5a809fbed9ffb8bf31ce5a5a248c9ed89b13b	published	1793429201131
\.


--
-- Data for Name: employee_work_scope_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.employee_work_scope_revisions (scope_id, revision, type_id, type_revision, encoded_scope_json, display_summary, content_digest, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: event_deliveries; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_deliveries (id, event_id, subscription_id, subscriber_kind, subscriber_ref, delivery_class, state, attempt_count, next_attempt_at, claimed_by, claim_expires_at, last_error, created_at, accepted_at, dead_letter_at) FROM stdin;
\.


--
-- Data for Name: event_observer_runs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_observer_runs (id, source_id, source_revision, generation, lease_epoch, wake_epoch, cursor_before_json, cursor_after_json, state, observation_count, started_at, finished_at, error_code, error_detail) FROM stdin;
\.


--
-- Data for Name: event_records; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_records (id, event_type_id, event_type_revision, source_id, source_revision, subject_type, subject_ref, occurred_at, observed_at, dedupe_key, summary_json, payload_artifact_ref) FROM stdin;
\.


--
-- Data for Name: event_response_rules; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_response_rules (id, name, owner_user_id, enabled, source_id, source_revision, event_type_id, event_type_revision, subject_type, subject_match, subject_pattern, target_json, last_fired_at, last_status, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: event_sources; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_sources (source_id, revision, descriptor_json, descriptor_digest, state, registered_at) FROM stdin;
code-host.activity	1	{"schemaVersion":1,"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"通过 Webhook 实时接收变化，并在有人关注时用短轮询补齐权威状态。","en-US":"Receives real-time changes through webhooks and reconciles authoritative state by short polling while subscribed."},"observationMode":"hybrid","observerProgramRef":{"id":"builtin:development-code-host-observer","revision":1},"pollIntervalMs":30000,"batchSize":100}	490da3a9302113c18e3012f93acad2aad86b74d60c2f6d8e3bf0a8ebec8f624b	published	1793429200905
development.approval-state	1	{"schemaVersion":1,"sourceRef":{"id":"development.approval-state","revision":1},"ownerTypeId":"development","displayName":{"zh-CN":"外部审批状态观察","en-US":"External approval state observation"},"description":{"zh-CN":"只在有数字员工关注审批时启动已注册程序进行短轮询","en-US":"Runs the registered short observer only while an employee subscribes to the approval"},"observationMode":"hybrid","observerProgramRef":{"id":"builtin:development-approval-observer","revision":1},"pollIntervalMs":30000,"batchSize":100}	001d87f12cb007c310f0b64a9efb0853353af2892953ffec0ceda8fd03feacda	published	1793429200905
employee.channel	1	{"schemaVersion":1,"sourceRef":{"id":"employee.channel","revision":1},"ownerTypeId":"development","displayName":{"zh-CN":"数字员工协同通道","en-US":"Digital employee collaboration channel"},"description":{"zh-CN":"传递子员工公开里程碑与完成结果","en-US":"Carries child employee milestones and completion results"},"observationMode":"passive","observerProgramRef":null,"pollIntervalMs":60000,"batchSize":100}	14f7bad503e93ffbf4612bf0fd87425a4d205d93004e37cc2deda2b4e7efff02	published	1793429200905
platform.collaboration-committed	1	{"schemaVersion":1,"sourceRef":{"id":"platform.collaboration-committed","revision":1},"ownerTypeId":"collaboration","displayName":{"zh-CN":"协作已提交事件","en-US":"Collaboration committed events"},"description":{"zh-CN":"由 review、clarify 与 questions 事务提交的内部事实。","en-US":"Internal facts committed by review, clarify, and questions transactions."},"observationMode":"passive","observerProgramRef":null,"pollIntervalMs":60000,"batchSize":100}	eecfa5c3e390568b235fe42b07486ae2d74b36d021d202b576c9c791f5887036	published	1793429200937
platform.employee-lifecycle	1	{"schemaVersion":1,"sourceRef":{"id":"platform.employee-lifecycle","revision":1},"ownerTypeId":"digital-employee","displayName":{"zh-CN":"数字员工生命周期","en-US":"Digital employee lifecycle"},"description":{"zh-CN":"由数字员工 Case 事务提交后发布的平台事实。","en-US":"Platform facts published from committed employee Case transactions."},"observationMode":"passive","observerProgramRef":null,"pollIntervalMs":60000,"batchSize":100}	03652a90386582900ed8a95c28dbb5667575fc10ee0f8bf9e24fbca197924678	published	1793429200937
platform.task-lifecycle	1	{"schemaVersion":1,"sourceRef":{"id":"platform.task-lifecycle","revision":1},"ownerTypeId":"task-execution","displayName":{"zh-CN":"编排任务生命周期","en-US":"Orchestration task lifecycle"},"description":{"zh-CN":"由任务状态事务提交后发布的平台事实。","en-US":"Platform facts published from committed task status transactions."},"observationMode":"passive","observerProgramRef":null,"pollIntervalMs":60000,"batchSize":100}	967f7a0d36f5b1dec1596c69f004d412b2b0841c1b5f67334200768c7916b28a	published	1793429200936
\.


--
-- Data for Name: event_subscriptions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_subscriptions (id, event_type_id, event_type_revision, source_id, source_revision, subject_type, subject_ref, subscriber_kind, subscriber_ref, mode, origin_kind, origin_ref, definition_revision, display_name_json, selector_kind, selector_json, active_identity_key, state, created_at, updated_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: event_type_catalog; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.event_type_catalog (event_type_id, revision, source_id, source_revision, descriptor_json, descriptor_digest, catalog_visibility, state, registered_at) FROM stdin;
approval.status.changed	1	development.approval-state	1	{"schemaVersion":1,"eventTypeRef":{"id":"approval.status.changed","revision":1},"sourceRef":{"id":"development.approval-state","revision":1},"ownerTypeId":"development","subjectTypeId":"external-approval","payloadSchemaId":"approval.status-change.v1","displayName":{"zh-CN":"外部审批状态已变化","en-US":"External approval status changed"},"description":{"zh-CN":"外部审批系统返回了新的权威状态或修订","en-US":"An external approval system returned a new authoritative status or revision"},"deliveryClass":"approval-business-event","triggerParameters":{"namespace":"approval","fields":[{"fieldId":"subject_ref","displayName":{"zh-CN":"审批对象","en-US":"Approval subject"},"description":{"zh-CN":"审批对象","en-US":"Approval subject"}}]}}	b018ec4ed005b1e1b16a979f8c2b288a2bb3429c0605e1c39645b0f956c69ddc	public	published	1793429200905
code-host.event.mr_merged	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.mr_merged","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"合并请求已合入","en-US":"Merge request merged"},"description":{"zh-CN":"合并请求已合入","en-US":"Merge request merged"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_title","displayName":{"zh-CN":"mr_title","en-US":"mr_title"},"description":{"zh-CN":"代码平台事件参数 mr_title","en-US":"Code-host event parameter mr_title"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}}]}}	7a967301d9dbc7d278192639b30d1bbc579690483cceed8a546cbd1810d0147c	compatibility	published	1793429200910
code-host.event.issue_labeled	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.issue_labeled","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"工作项已标记","en-US":"Work item labeled"},"description":{"zh-CN":"工作项已标记","en-US":"Work item labeled"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"issue_iid","displayName":{"zh-CN":"issue_iid","en-US":"issue_iid"},"description":{"zh-CN":"代码平台事件参数 issue_iid","en-US":"Code-host event parameter issue_iid"}},{"fieldId":"issue_title","displayName":{"zh-CN":"issue_title","en-US":"issue_title"},"description":{"zh-CN":"代码平台事件参数 issue_title","en-US":"Code-host event parameter issue_title"}},{"fieldId":"issue_url","displayName":{"zh-CN":"issue_url","en-US":"issue_url"},"description":{"zh-CN":"代码平台事件参数 issue_url","en-US":"Code-host event parameter issue_url"}},{"fieldId":"issue_body","displayName":{"zh-CN":"issue_body","en-US":"issue_body"},"description":{"zh-CN":"代码平台事件参数 issue_body","en-US":"Code-host event parameter issue_body"}},{"fieldId":"issue_labels","displayName":{"zh-CN":"issue_labels","en-US":"issue_labels"},"description":{"zh-CN":"代码平台事件参数 issue_labels","en-US":"Code-host event parameter issue_labels"}},{"fieldId":"added_labels","displayName":{"zh-CN":"added_labels","en-US":"added_labels"},"description":{"zh-CN":"代码平台事件参数 added_labels","en-US":"Code-host event parameter added_labels"}}]}}	58df82d0b2b43117d4f8a8fd7c8fe3583177c851713c89f8e4e20fbd8dd4b790	compatibility	published	1793429200910
code-host.event.issue_comment	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.issue_comment","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"工作项收到评论","en-US":"Work item comment received"},"description":{"zh-CN":"工作项收到评论","en-US":"Work item comment received"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"issue_iid","displayName":{"zh-CN":"issue_iid","en-US":"issue_iid"},"description":{"zh-CN":"代码平台事件参数 issue_iid","en-US":"Code-host event parameter issue_iid"}},{"fieldId":"issue_title","displayName":{"zh-CN":"issue_title","en-US":"issue_title"},"description":{"zh-CN":"代码平台事件参数 issue_title","en-US":"Code-host event parameter issue_title"}},{"fieldId":"issue_url","displayName":{"zh-CN":"issue_url","en-US":"issue_url"},"description":{"zh-CN":"代码平台事件参数 issue_url","en-US":"Code-host event parameter issue_url"}},{"fieldId":"issue_body","displayName":{"zh-CN":"issue_body","en-US":"issue_body"},"description":{"zh-CN":"代码平台事件参数 issue_body","en-US":"Code-host event parameter issue_body"}},{"fieldId":"issue_labels","displayName":{"zh-CN":"issue_labels","en-US":"issue_labels"},"description":{"zh-CN":"代码平台事件参数 issue_labels","en-US":"Code-host event parameter issue_labels"}},{"fieldId":"added_labels","displayName":{"zh-CN":"added_labels","en-US":"added_labels"},"description":{"zh-CN":"代码平台事件参数 added_labels","en-US":"Code-host event parameter added_labels"}},{"fieldId":"comment_text","displayName":{"zh-CN":"comment_text","en-US":"comment_text"},"description":{"zh-CN":"代码平台事件参数 comment_text","en-US":"Code-host event parameter comment_text"}},{"fieldId":"comment_author","displayName":{"zh-CN":"comment_author","en-US":"comment_author"},"description":{"zh-CN":"代码平台事件参数 comment_author","en-US":"Code-host event parameter comment_author"}},{"fieldId":"comment_id","displayName":{"zh-CN":"comment_id","en-US":"comment_id"},"description":{"zh-CN":"代码平台事件参数 comment_id","en-US":"Code-host event parameter comment_id"}},{"fieldId":"comment_url","displayName":{"zh-CN":"comment_url","en-US":"comment_url"},"description":{"zh-CN":"代码平台事件参数 comment_url","en-US":"Code-host event parameter comment_url"}}]}}	f2ce9ce0d9e30d748c24570f14147a3ac0210b62e0ac386d19cd5acfd387c5fa	compatibility	published	1793429200910
code-host.event.mr_opened	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.mr_opened","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"合并请求已创建","en-US":"Merge request opened"},"description":{"zh-CN":"合并请求已创建","en-US":"Merge request opened"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_title","displayName":{"zh-CN":"mr_title","en-US":"mr_title"},"description":{"zh-CN":"代码平台事件参数 mr_title","en-US":"Code-host event parameter mr_title"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}}]}}	fc6404a1e4a0ea049179f3370d56c8f37a288b5c8f6dd05757e7f2cf006ac220	compatibility	published	1793429200910
code-host.event.mr_updated	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.mr_updated","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"合并请求已更新","en-US":"Merge request updated"},"description":{"zh-CN":"合并请求已更新","en-US":"Merge request updated"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_title","displayName":{"zh-CN":"mr_title","en-US":"mr_title"},"description":{"zh-CN":"代码平台事件参数 mr_title","en-US":"Code-host event parameter mr_title"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}}]}}	ce4797ec7c82b5b4689daad6991db950b25ca6eed00c91509215940c4b038256	compatibility	published	1793429200910
development.lifecycle-updated	2	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.lifecycle-updated","revision":2},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"development","subjectTypeId":"merge-request","payloadSchemaId":"development.lifecycle.event.v1","displayName":{"zh-CN":"MR 生命周期有更新","en-US":"MR lifecycle updated"},"description":{"zh-CN":"MR 已合入、关闭、重新打开或 head 发生变化","en-US":"The MR was merged, closed, reopened, or moved to another head"},"deliveryClass":"terminal","catalogVisibility":"internal","triggerParameters":null}	4ddb318e1372c3c09b370f6a455a83c722c1d831a4ddf70bffc95ff065a9a151	internal	published	1793429200905
code-host.event.note	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.note","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"收到评论","en-US":"Comment received"},"description":{"zh-CN":"收到评论","en-US":"Comment received"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_title","displayName":{"zh-CN":"mr_title","en-US":"mr_title"},"description":{"zh-CN":"代码平台事件参数 mr_title","en-US":"Code-host event parameter mr_title"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"comment_text","displayName":{"zh-CN":"comment_text","en-US":"comment_text"},"description":{"zh-CN":"代码平台事件参数 comment_text","en-US":"Code-host event parameter comment_text"}},{"fieldId":"comment_author","displayName":{"zh-CN":"comment_author","en-US":"comment_author"},"description":{"zh-CN":"代码平台事件参数 comment_author","en-US":"Code-host event parameter comment_author"}},{"fieldId":"comment_id","displayName":{"zh-CN":"comment_id","en-US":"comment_id"},"description":{"zh-CN":"代码平台事件参数 comment_id","en-US":"Code-host event parameter comment_id"}},{"fieldId":"comment_thread_id","displayName":{"zh-CN":"comment_thread_id","en-US":"comment_thread_id"},"description":{"zh-CN":"代码平台事件参数 comment_thread_id","en-US":"Code-host event parameter comment_thread_id"}},{"fieldId":"comment_url","displayName":{"zh-CN":"comment_url","en-US":"comment_url"},"description":{"zh-CN":"代码平台事件参数 comment_url","en-US":"Code-host event parameter comment_url"}},{"fieldId":"comment_position_json","displayName":{"zh-CN":"comment_position_json","en-US":"comment_position_json"},"description":{"zh-CN":"代码平台事件参数 comment_position_json","en-US":"Code-host event parameter comment_position_json"}}]}}	671d07d9790d741b0599da41ad258dfb5102a1ec034dd629536081edcc51350d	compatibility	published	1793429200910
code-host.event.pipeline_failed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.pipeline_failed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"流水线失败","en-US":"Pipeline failed"},"description":{"zh-CN":"流水线失败","en-US":"Pipeline failed"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}},{"fieldId":"pipeline_status","displayName":{"zh-CN":"pipeline_status","en-US":"pipeline_status"},"description":{"zh-CN":"代码平台事件参数 pipeline_status","en-US":"Code-host event parameter pipeline_status"}},{"fieldId":"pipeline_id","displayName":{"zh-CN":"pipeline_id","en-US":"pipeline_id"},"description":{"zh-CN":"代码平台事件参数 pipeline_id","en-US":"Code-host event parameter pipeline_id"}},{"fieldId":"pipeline_url","displayName":{"zh-CN":"pipeline_url","en-US":"pipeline_url"},"description":{"zh-CN":"代码平台事件参数 pipeline_url","en-US":"Code-host event parameter pipeline_url"}}]}}	c3075d225712d295c234320652e08554b015cc7ddbeeea45d99614d22ba8ad91	compatibility	published	1793429200910
code-host.event.pipeline_succeeded	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.pipeline_succeeded","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"流水线通过","en-US":"Pipeline succeeded"},"description":{"zh-CN":"流水线通过","en-US":"Pipeline succeeded"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}},{"fieldId":"pipeline_status","displayName":{"zh-CN":"pipeline_status","en-US":"pipeline_status"},"description":{"zh-CN":"代码平台事件参数 pipeline_status","en-US":"Code-host event parameter pipeline_status"}},{"fieldId":"pipeline_id","displayName":{"zh-CN":"pipeline_id","en-US":"pipeline_id"},"description":{"zh-CN":"代码平台事件参数 pipeline_id","en-US":"Code-host event parameter pipeline_id"}},{"fieldId":"pipeline_url","displayName":{"zh-CN":"pipeline_url","en-US":"pipeline_url"},"description":{"zh-CN":"代码平台事件参数 pipeline_url","en-US":"Code-host event parameter pipeline_url"}}]}}	6fdb4cc3c20300a1d6208d1794f7370cd56f1133a98cae2e9b0e78f17110721a	compatibility	published	1793429200910
code-host.merge-request.closed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.merge-request.closed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"merge-request","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"合并请求已关闭","en-US":"Merge request closed"},"description":{"zh-CN":"一个合并请求已经关闭","en-US":"A merge request was closed"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_title","displayName":{"zh-CN":"MR / PR 标题","en-US":"MR / PR title"},"description":{"zh-CN":"MR / PR 标题，由该代码平台事实确定性注入。","en-US":"MR / PR title, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}}]}}	8f7e19bf379ee95f4cd27008767892557c8e2fd88653679df7c7b1404deefc7f	public	published	1793429200910
code-host.merge-request.comment-received	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.merge-request.comment-received","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"merge-request","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"收到评论","en-US":"Comment received"},"description":{"zh-CN":"一个合并请求收到了新评论","en-US":"A merge request received a comment"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_title","displayName":{"zh-CN":"MR / PR 标题","en-US":"MR / PR title"},"description":{"zh-CN":"MR / PR 标题，由该代码平台事实确定性注入。","en-US":"MR / PR title, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"comment_text","displayName":{"zh-CN":"评论正文","en-US":"Comment body"},"description":{"zh-CN":"评论正文，由该代码平台事实确定性注入。","en-US":"Comment body, deterministically injected by this code-host fact."}},{"fieldId":"comment_author","displayName":{"zh-CN":"评论作者","en-US":"Comment author"},"description":{"zh-CN":"评论作者，由该代码平台事实确定性注入。","en-US":"Comment author, deterministically injected by this code-host fact."}},{"fieldId":"comment_id","displayName":{"zh-CN":"评论 ID","en-US":"Comment ID"},"description":{"zh-CN":"评论 ID，由该代码平台事实确定性注入。","en-US":"Comment ID, deterministically injected by this code-host fact."}},{"fieldId":"comment_thread_id","displayName":{"zh-CN":"评论线程 ID","en-US":"Comment thread ID"},"description":{"zh-CN":"评论线程 ID，由该代码平台事实确定性注入。","en-US":"Comment thread ID, deterministically injected by this code-host fact."}},{"fieldId":"comment_url","displayName":{"zh-CN":"评论地址","en-US":"Comment URL"},"description":{"zh-CN":"评论地址，由该代码平台事实确定性注入。","en-US":"Comment URL, deterministically injected by this code-host fact."}},{"fieldId":"comment_position_json","displayName":{"zh-CN":"行内评论位置","en-US":"Inline comment position"},"description":{"zh-CN":"行内评论位置，由该代码平台事实确定性注入。","en-US":"Inline comment position, deterministically injected by this code-host fact."}}]}}	cf18e529602a0c02234e02d447307cc8aad63f1d0116de0410cf583bd9281a54	public	published	1793429200910
development.pipeline-check-due	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.pipeline-check-due","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"development","subjectTypeId":"merge-request","payloadSchemaId":"development.pipeline-check-due.v1","displayName":{"zh-CN":"MR 门禁复核到期","en-US":"MR gate recheck due"},"description":{"zh-CN":"下一次主动门禁复核时间已经到达，只用于唤醒正在关注此 MR 的数字员工","en-US":"The next active gate recheck is due; this only wakes employees already watching the MR"},"deliveryClass":"pipeline","catalogVisibility":"internal","triggerParameters":null}	d97a5ecbd46f06aa241004e8d6d0842b31dc0abe0f065164a2a7dc542fd04311	internal	published	1793429200905
code-host.issue.labeled	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.issue.labeled","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.issue","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"工作项已标记","en-US":"Work item labeled"},"description":{"zh-CN":"一个工作项新增了标签","en-US":"A work item received a label"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"issue_iid","displayName":{"zh-CN":"工作项编号","en-US":"Work item number"},"description":{"zh-CN":"工作项编号，由该代码平台事实确定性注入。","en-US":"Work item number, deterministically injected by this code-host fact."}},{"fieldId":"issue_title","displayName":{"zh-CN":"工作项标题","en-US":"Work item title"},"description":{"zh-CN":"工作项标题，由该代码平台事实确定性注入。","en-US":"Work item title, deterministically injected by this code-host fact."}},{"fieldId":"issue_url","displayName":{"zh-CN":"工作项地址","en-US":"Work item URL"},"description":{"zh-CN":"工作项地址，由该代码平台事实确定性注入。","en-US":"Work item URL, deterministically injected by this code-host fact."}},{"fieldId":"issue_body","displayName":{"zh-CN":"工作项正文","en-US":"Work item body"},"description":{"zh-CN":"工作项正文，由该代码平台事实确定性注入。","en-US":"Work item body, deterministically injected by this code-host fact."}},{"fieldId":"issue_labels","displayName":{"zh-CN":"工作项全部标签","en-US":"Work item labels"},"description":{"zh-CN":"工作项全部标签，由该代码平台事实确定性注入。","en-US":"Work item labels, deterministically injected by this code-host fact."}},{"fieldId":"added_labels","displayName":{"zh-CN":"本次新增标签","en-US":"Labels added"},"description":{"zh-CN":"本次新增标签，由该代码平台事实确定性注入。","en-US":"Labels added, deterministically injected by this code-host fact."}}]}}	1324056404e48d9963f88cc280f4beb74e42633210294c53ffc0a5481118da16	public	published	1793429200910
code-host.issue.comment-received	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.issue.comment-received","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.issue","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"工作项收到评论","en-US":"Work item comment received"},"description":{"zh-CN":"一个工作项收到了新评论","en-US":"A work item received a comment"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"issue_iid","displayName":{"zh-CN":"工作项编号","en-US":"Work item number"},"description":{"zh-CN":"工作项编号，由该代码平台事实确定性注入。","en-US":"Work item number, deterministically injected by this code-host fact."}},{"fieldId":"issue_title","displayName":{"zh-CN":"工作项标题","en-US":"Work item title"},"description":{"zh-CN":"工作项标题，由该代码平台事实确定性注入。","en-US":"Work item title, deterministically injected by this code-host fact."}},{"fieldId":"issue_url","displayName":{"zh-CN":"工作项地址","en-US":"Work item URL"},"description":{"zh-CN":"工作项地址，由该代码平台事实确定性注入。","en-US":"Work item URL, deterministically injected by this code-host fact."}},{"fieldId":"issue_body","displayName":{"zh-CN":"工作项正文","en-US":"Work item body"},"description":{"zh-CN":"工作项正文，由该代码平台事实确定性注入。","en-US":"Work item body, deterministically injected by this code-host fact."}},{"fieldId":"issue_labels","displayName":{"zh-CN":"工作项全部标签","en-US":"Work item labels"},"description":{"zh-CN":"工作项全部标签，由该代码平台事实确定性注入。","en-US":"Work item labels, deterministically injected by this code-host fact."}},{"fieldId":"added_labels","displayName":{"zh-CN":"本次新增标签","en-US":"Labels added"},"description":{"zh-CN":"本次新增标签，由该代码平台事实确定性注入。","en-US":"Labels added, deterministically injected by this code-host fact."}},{"fieldId":"comment_text","displayName":{"zh-CN":"评论正文","en-US":"Comment body"},"description":{"zh-CN":"评论正文，由该代码平台事实确定性注入。","en-US":"Comment body, deterministically injected by this code-host fact."}},{"fieldId":"comment_author","displayName":{"zh-CN":"评论作者","en-US":"Comment author"},"description":{"zh-CN":"评论作者，由该代码平台事实确定性注入。","en-US":"Comment author, deterministically injected by this code-host fact."}},{"fieldId":"comment_id","displayName":{"zh-CN":"评论 ID","en-US":"Comment ID"},"description":{"zh-CN":"评论 ID，由该代码平台事实确定性注入。","en-US":"Comment ID, deterministically injected by this code-host fact."}},{"fieldId":"comment_url","displayName":{"zh-CN":"评论地址","en-US":"Comment URL"},"description":{"zh-CN":"评论地址，由该代码平台事实确定性注入。","en-US":"Comment URL, deterministically injected by this code-host fact."}}]}}	20838e7da13c4261611a9b10c82c8b6125ba67b9126a0b959d7c7f25bbd10066	public	published	1793429200910
code-host.merge-request.updated	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.merge-request.updated","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"merge-request","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"合并请求已更新","en-US":"Merge request updated"},"description":{"zh-CN":"一个合并请求的内容或状态已经变化","en-US":"A merge request changed"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_title","displayName":{"zh-CN":"MR / PR 标题","en-US":"MR / PR title"},"description":{"zh-CN":"MR / PR 标题，由该代码平台事实确定性注入。","en-US":"MR / PR title, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}}]}}	16b590543d685d6846ef365d0ac46f6170f21a165895f1017dd3dbc5223218e0	public	published	1793429200910
code-host.pipeline.failed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.pipeline.failed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.pipeline","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"流水线失败","en-US":"Pipeline failed"},"description":{"zh-CN":"一次流水线运行已经失败","en-US":"A pipeline run failed"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_status","displayName":{"zh-CN":"流水线状态","en-US":"Pipeline status"},"description":{"zh-CN":"流水线状态，由该代码平台事实确定性注入。","en-US":"Pipeline status, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_id","displayName":{"zh-CN":"流水线 ID","en-US":"Pipeline ID"},"description":{"zh-CN":"流水线 ID，由该代码平台事实确定性注入。","en-US":"Pipeline ID, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_url","displayName":{"zh-CN":"流水线地址","en-US":"Pipeline URL"},"description":{"zh-CN":"流水线地址，由该代码平台事实确定性注入。","en-US":"Pipeline URL, deterministically injected by this code-host fact."}}]}}	4028190cca67efd591d492e8a463bbd963f96b3c56e1ea1b8f44134fad32bcf0	public	published	1793429200910
code-host.pipeline.succeeded	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.pipeline.succeeded","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.pipeline","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"流水线通过","en-US":"Pipeline succeeded"},"description":{"zh-CN":"一次流水线运行已经通过","en-US":"A pipeline run passed"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_status","displayName":{"zh-CN":"流水线状态","en-US":"Pipeline status"},"description":{"zh-CN":"流水线状态，由该代码平台事实确定性注入。","en-US":"Pipeline status, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_id","displayName":{"zh-CN":"流水线 ID","en-US":"Pipeline ID"},"description":{"zh-CN":"流水线 ID，由该代码平台事实确定性注入。","en-US":"Pipeline ID, deterministically injected by this code-host fact."}},{"fieldId":"pipeline_url","displayName":{"zh-CN":"流水线地址","en-US":"Pipeline URL"},"description":{"zh-CN":"流水线地址，由该代码平台事实确定性注入。","en-US":"Pipeline URL, deterministically injected by this code-host fact."}}]}}	8307880587f2f66042f7d99d738d3e5e44aa43f6c3592a5f024bbc3bf2ba0699	public	published	1793429200910
development.conflict-updated	2	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.conflict-updated","revision":2},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"development","subjectTypeId":"merge-request","payloadSchemaId":"development.conflict.event.v1","displayName":{"zh-CN":"MR 冲突状态有更新","en-US":"MR conflict state updated"},"description":{"zh-CN":"目标分支变化导致冲突出现或消失","en-US":"Target branch changes introduced or cleared a conflict"},"deliveryClass":"conflict","catalogVisibility":"internal","triggerParameters":null}	12ff4fb9d29af03aa2429f7280ca7388a6472b52842e0e267984f9110c530e50	internal	published	1793429200905
development.employee-result	1	employee.channel	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.employee-result","revision":1},"sourceRef":{"id":"employee.channel","revision":1},"ownerTypeId":"development","subjectTypeId":"employee-invocation","payloadSchemaId":"employee.invocation-result.v1","displayName":{"zh-CN":"协同员工返回结果","en-US":"Collaborating employee returned a result"},"description":{"zh-CN":"被调起的数字员工返回了可重验的里程碑或终态结果","en-US":"An invoked employee returned a revalidatable milestone or terminal result"},"deliveryClass":"collaboration","priority":600,"catalogVisibility":"internal","triggerParameters":null}	5550f34653fe04b0c1ac1b330fea0add34694f2a8bc0281db4aea74761b53286	internal	published	1793429200905
development.approval-updated	1	development.approval-state	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.approval-updated","revision":1},"sourceRef":{"id":"development.approval-state","revision":1},"ownerTypeId":"development","subjectTypeId":"external-approval","payloadSchemaId":"development.approval-observation.v1","displayName":{"zh-CN":"外部审批状态有更新","en-US":"External approval status updated"},"description":{"zh-CN":"审批系统返回了新的权威 revision 或终态","en-US":"The approval system returned a new authoritative revision or terminal state"},"deliveryClass":"approval","priority":850,"catalogVisibility":"internal","triggerParameters":null}	f670dd74159c116f7e28151771636e95032407166fb4a72ef15c09b767e76085	internal	published	1793429200905
code-host.tag.pushed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.tag.pushed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"标签推送","en-US":"Tag pushed"},"description":{"zh-CN":"一个标签已创建或更新","en-US":"A tag was created or updated"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}},{"fieldId":"commit_before","displayName":{"zh-CN":"推送前 SHA","en-US":"SHA before push"},"description":{"zh-CN":"推送前 SHA，由该代码平台事实确定性注入。","en-US":"SHA before push, deterministically injected by this code-host fact."}}]}}	3fe0767f2e01a71de6a027f0e9b05d63996fd95c64960e1fe3b1c6518a4b8270	public	published	1793429200910
development.review-updated	2	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"development.review-updated","revision":2},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"development","subjectTypeId":"merge-request","payloadSchemaId":"development.review.event.v1","displayName":{"zh-CN":"MR 检视意见有更新","en-US":"MR review feedback updated"},"description":{"zh-CN":"出现新的或发生变化的检视意见","en-US":"New or changed review feedback is available"},"deliveryClass":"review","catalogVisibility":"internal","triggerParameters":null}	f7faa89b64c722af2e109e847087f92f021e288b9ac4b4fe41475333688ef1b7	internal	published	1793429200905
code-host.branch.pushed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.branch.pushed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"分支推送","en-US":"Branch pushed"},"description":{"zh-CN":"一个分支已收到新的提交","en-US":"A branch received new commits"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}},{"fieldId":"commit_before","displayName":{"zh-CN":"推送前 SHA","en-US":"SHA before push"},"description":{"zh-CN":"推送前 SHA，由该代码平台事实确定性注入。","en-US":"SHA before push, deterministically injected by this code-host fact."}}]}}	9b240636fde01e8bfb97fe8b134be5c77fe6e70e5ea086df6df45d34b8feee7a	public	published	1793429200910
code-host.event.push	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.push","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"分支推送","en-US":"Branch pushed"},"description":{"zh-CN":"分支推送","en-US":"Branch pushed"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}},{"fieldId":"commit_before","displayName":{"zh-CN":"commit_before","en-US":"commit_before"},"description":{"zh-CN":"代码平台事件参数 commit_before","en-US":"Code-host event parameter commit_before"}}]}}	ed8637b0fcb4dc755b2a84caee780849729a5f7fe1daff1310db1c66ad2b5cb8	compatibility	published	1793429200910
platform.employee-case.state-changed	1	platform.employee-lifecycle	1	{"schemaVersion":1,"eventTypeRef":{"id":"platform.employee-case.state-changed","revision":1},"sourceRef":{"id":"platform.employee-lifecycle","revision":1},"ownerTypeId":"digital-employee","subjectTypeId":"digital-employee.case","payloadSchemaId":"digital-employee.case-state-change","displayName":{"zh-CN":"数字员工任务状态变化","en-US":"Employee Case state changed"},"description":{"zh-CN":"一个数字员工任务已进入新的生命周期状态。","en-US":"A Digital Employee Case entered a new lifecycle state."},"deliveryClass":"digital-employee.case-state","triggerParameters":{"namespace":"employee_case","fields":[{"fieldId":"case_id","displayName":{"zh-CN":"任务 ID","en-US":"Case ID"},"description":{"zh-CN":"任务 ID","en-US":"Case ID"}},{"fieldId":"employee_id","displayName":{"zh-CN":"数字员工 ID","en-US":"Digital employee ID"},"description":{"zh-CN":"数字员工 ID","en-US":"Digital employee ID"}},{"fieldId":"state","displayName":{"zh-CN":"当前状态","en-US":"Current state"},"description":{"zh-CN":"当前状态","en-US":"Current state"}},{"fieldId":"previous_state","displayName":{"zh-CN":"上一状态","en-US":"Previous state"},"description":{"zh-CN":"上一状态","en-US":"Previous state"}},{"fieldId":"revision","displayName":{"zh-CN":"任务修订","en-US":"Case revision"},"description":{"zh-CN":"任务修订","en-US":"Case revision"}},{"fieldId":"terminal_kind","displayName":{"zh-CN":"终态类型","en-US":"Terminal kind"},"description":{"zh-CN":"终态类型","en-US":"Terminal kind"}}]}}	f0d616688fd1b1fa559065965689b7cf9b892d63bf1ceca33ca0cde6e47a2e0a	public	published	1793429200937
platform.employee-invocation.result-returned	1	platform.employee-lifecycle	1	{"schemaVersion":1,"eventTypeRef":{"id":"platform.employee-invocation.result-returned","revision":1},"sourceRef":{"id":"platform.employee-lifecycle","revision":1},"ownerTypeId":"digital-employee","subjectTypeId":"employee-invocation","payloadSchemaId":"digital-employee.invocation-result","displayName":{"zh-CN":"协同数字员工已返回结果","en-US":"Collaborating employee returned a result"},"description":{"zh-CN":"被调起的数字员工已返回完成、失败或超时结果。","en-US":"An invoked employee returned a completed, failed, or expired result."},"deliveryClass":"digital-employee.invocation-result","triggerParameters":{"namespace":"employee_result","fields":[{"fieldId":"invocation_ref","displayName":{"zh-CN":"协同调用","en-US":"Employee invocation"},"description":{"zh-CN":"协同调用","en-US":"Employee invocation"}},{"fieldId":"state","displayName":{"zh-CN":"返回状态","en-US":"Result state"},"description":{"zh-CN":"返回状态","en-US":"Result state"}},{"fieldId":"terminal_kind","displayName":{"zh-CN":"终态类型","en-US":"Terminal kind"},"description":{"zh-CN":"终态类型","en-US":"Terminal kind"}}]}}	38ad5ffafae329a0802e5b95b2cc1838d1bae462e88cf99541ed001ad829504c	public	published	1793429200937
code-host.event.tag_push	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.tag_push","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"标签推送","en-US":"Tag pushed"},"description":{"zh-CN":"标签推送","en-US":"Tag pushed"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}},{"fieldId":"commit_before","displayName":{"zh-CN":"commit_before","en-US":"commit_before"},"description":{"zh-CN":"代码平台事件参数 commit_before","en-US":"Code-host event parameter commit_before"}}]}}	ef084f6c7b434dc93d4861ecb1fefa50eee6b1a081a4d0c623bdc5e77e74239d	compatibility	published	1793429200910
code-host.merge-request.opened	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.merge-request.opened","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"merge-request","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"合并请求已创建","en-US":"Merge request opened"},"description":{"zh-CN":"一个合并请求已经创建","en-US":"A merge request was created"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_title","displayName":{"zh-CN":"MR / PR 标题","en-US":"MR / PR title"},"description":{"zh-CN":"MR / PR 标题，由该代码平台事实确定性注入。","en-US":"MR / PR title, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}}]}}	1a71cf091043116697744938b3fac8db85485746e19b5a14528e5372769c4ff9	public	published	1793429200910
code-host.merge-request.merged	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.merge-request.merged","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"merge-request","payloadSchemaId":"code-host.business-event.v1","displayName":{"zh-CN":"合并请求已合入","en-US":"Merge request merged"},"description":{"zh-CN":"一个合并请求已经合入","en-US":"A merge request was merged"},"deliveryClass":"code-host-business-event","triggerParameters":{"namespace":"code_host","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型，由该代码平台事实确定性注入。","en-US":"Event type, deterministically injected by this code-host fact."}},{"fieldId":"provider","displayName":{"zh-CN":"代码平台","en-US":"Code platform"},"description":{"zh-CN":"代码平台，由该代码平台事实确定性注入。","en-US":"Code platform, deterministically injected by this code-host fact."}},{"fieldId":"repo_path","displayName":{"zh-CN":"仓库路径","en-US":"Repository path"},"description":{"zh-CN":"仓库路径，由该代码平台事实确定性注入。","en-US":"Repository path, deterministically injected by this code-host fact."}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"仓库 HTTP 地址","en-US":"Repository HTTP URL"},"description":{"zh-CN":"仓库 HTTP 地址，由该代码平台事实确定性注入。","en-US":"Repository HTTP URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"仓库 SSH 地址","en-US":"Repository SSH URL"},"description":{"zh-CN":"仓库 SSH 地址，由该代码平台事实确定性注入。","en-US":"Repository SSH URL, deterministically injected by this code-host fact."}},{"fieldId":"branch","displayName":{"zh-CN":"事件分支","en-US":"Event branch"},"description":{"zh-CN":"事件分支，由该代码平台事实确定性注入。","en-US":"Event branch, deterministically injected by this code-host fact."}},{"fieldId":"default_branch","displayName":{"zh-CN":"默认分支","en-US":"Default branch"},"description":{"zh-CN":"默认分支，由该代码平台事实确定性注入。","en-US":"Default branch, deterministically injected by this code-host fact."}},{"fieldId":"api_base_url","displayName":{"zh-CN":"API 根地址","en-US":"API base URL"},"description":{"zh-CN":"API 根地址，由该代码平台事实确定性注入。","en-US":"API base URL, deterministically injected by this code-host fact."}},{"fieldId":"project_id","displayName":{"zh-CN":"项目 ID","en-US":"Project ID"},"description":{"zh-CN":"项目 ID，由该代码平台事实确定性注入。","en-US":"Project ID, deterministically injected by this code-host fact."}},{"fieldId":"project_web_url","displayName":{"zh-CN":"项目网页地址","en-US":"Project web URL"},"description":{"zh-CN":"项目网页地址，由该代码平台事实确定性注入。","en-US":"Project web URL, deterministically injected by this code-host fact."}},{"fieldId":"repo_owner","displayName":{"zh-CN":"仓库所有者","en-US":"Repository owner"},"description":{"zh-CN":"仓库所有者，由该代码平台事实确定性注入。","en-US":"Repository owner, deterministically injected by this code-host fact."}},{"fieldId":"repo_name","displayName":{"zh-CN":"仓库名称","en-US":"Repository name"},"description":{"zh-CN":"仓库名称，由该代码平台事实确定性注入。","en-US":"Repository name, deterministically injected by this code-host fact."}},{"fieldId":"author_id","displayName":{"zh-CN":"事件作者 ID","en-US":"Event author ID"},"description":{"zh-CN":"事件作者 ID，由该代码平台事实确定性注入。","en-US":"Event author ID, deterministically injected by this code-host fact."}},{"fieldId":"target_branch","displayName":{"zh-CN":"目标分支","en-US":"Target branch"},"description":{"zh-CN":"目标分支，由该代码平台事实确定性注入。","en-US":"Target branch, deterministically injected by this code-host fact."}},{"fieldId":"mr_iid","displayName":{"zh-CN":"MR / PR 编号","en-US":"MR / PR number"},"description":{"zh-CN":"MR / PR 编号，由该代码平台事实确定性注入。","en-US":"MR / PR number, deterministically injected by this code-host fact."}},{"fieldId":"mr_id","displayName":{"zh-CN":"MR / PR 全局 ID","en-US":"MR / PR global ID"},"description":{"zh-CN":"MR / PR 全局 ID，由该代码平台事实确定性注入。","en-US":"MR / PR global ID, deterministically injected by this code-host fact."}},{"fieldId":"mr_title","displayName":{"zh-CN":"MR / PR 标题","en-US":"MR / PR title"},"description":{"zh-CN":"MR / PR 标题，由该代码平台事实确定性注入。","en-US":"MR / PR title, deterministically injected by this code-host fact."}},{"fieldId":"mr_url","displayName":{"zh-CN":"MR / PR 地址","en-US":"MR / PR URL"},"description":{"zh-CN":"MR / PR 地址，由该代码平台事实确定性注入。","en-US":"MR / PR URL, deterministically injected by this code-host fact."}},{"fieldId":"commit_sha","displayName":{"zh-CN":"提交 SHA","en-US":"Commit SHA"},"description":{"zh-CN":"提交 SHA，由该代码平台事实确定性注入。","en-US":"Commit SHA, deterministically injected by this code-host fact."}}]}}	3ed36bbf30b614c2b35f26da707d2c67fb930f8ae4656b8cedb8e7cd95d7e734	public	published	1793429200910
code-host.event.mr_closed	1	code-host.activity	1	{"schemaVersion":1,"eventTypeRef":{"id":"code-host.event.mr_closed","revision":1},"sourceRef":{"id":"code-host.activity","revision":1},"ownerTypeId":"integration.code-host","subjectTypeId":"code-host.repository","payloadSchemaId":"code-host.webhook-delivery","displayName":{"zh-CN":"合并请求已关闭","en-US":"Merge request closed"},"description":{"zh-CN":"合并请求已关闭","en-US":"Merge request closed"},"deliveryClass":"code-host-event","catalogVisibility":"compatibility","triggerParameters":{"namespace":"webhook","fields":[{"fieldId":"event_type","displayName":{"zh-CN":"event_type","en-US":"event_type"},"description":{"zh-CN":"代码平台事件参数 event_type","en-US":"Code-host event parameter event_type"}},{"fieldId":"provider","displayName":{"zh-CN":"provider","en-US":"provider"},"description":{"zh-CN":"代码平台事件参数 provider","en-US":"Code-host event parameter provider"}},{"fieldId":"repo_path","displayName":{"zh-CN":"repo_path","en-US":"repo_path"},"description":{"zh-CN":"代码平台事件参数 repo_path","en-US":"Code-host event parameter repo_path"}},{"fieldId":"repo_http_url","displayName":{"zh-CN":"repo_http_url","en-US":"repo_http_url"},"description":{"zh-CN":"代码平台事件参数 repo_http_url","en-US":"Code-host event parameter repo_http_url"}},{"fieldId":"repo_ssh_url","displayName":{"zh-CN":"repo_ssh_url","en-US":"repo_ssh_url"},"description":{"zh-CN":"代码平台事件参数 repo_ssh_url","en-US":"Code-host event parameter repo_ssh_url"}},{"fieldId":"branch","displayName":{"zh-CN":"branch","en-US":"branch"},"description":{"zh-CN":"代码平台事件参数 branch","en-US":"Code-host event parameter branch"}},{"fieldId":"default_branch","displayName":{"zh-CN":"default_branch","en-US":"default_branch"},"description":{"zh-CN":"代码平台事件参数 default_branch","en-US":"Code-host event parameter default_branch"}},{"fieldId":"api_base_url","displayName":{"zh-CN":"api_base_url","en-US":"api_base_url"},"description":{"zh-CN":"代码平台事件参数 api_base_url","en-US":"Code-host event parameter api_base_url"}},{"fieldId":"project_id","displayName":{"zh-CN":"project_id","en-US":"project_id"},"description":{"zh-CN":"代码平台事件参数 project_id","en-US":"Code-host event parameter project_id"}},{"fieldId":"project_web_url","displayName":{"zh-CN":"project_web_url","en-US":"project_web_url"},"description":{"zh-CN":"代码平台事件参数 project_web_url","en-US":"Code-host event parameter project_web_url"}},{"fieldId":"repo_owner","displayName":{"zh-CN":"repo_owner","en-US":"repo_owner"},"description":{"zh-CN":"代码平台事件参数 repo_owner","en-US":"Code-host event parameter repo_owner"}},{"fieldId":"repo_name","displayName":{"zh-CN":"repo_name","en-US":"repo_name"},"description":{"zh-CN":"代码平台事件参数 repo_name","en-US":"Code-host event parameter repo_name"}},{"fieldId":"author_id","displayName":{"zh-CN":"author_id","en-US":"author_id"},"description":{"zh-CN":"代码平台事件参数 author_id","en-US":"Code-host event parameter author_id"}},{"fieldId":"event_json","displayName":{"zh-CN":"event_json","en-US":"event_json"},"description":{"zh-CN":"代码平台事件参数 event_json","en-US":"Code-host event parameter event_json"}},{"fieldId":"target_branch","displayName":{"zh-CN":"target_branch","en-US":"target_branch"},"description":{"zh-CN":"代码平台事件参数 target_branch","en-US":"Code-host event parameter target_branch"}},{"fieldId":"mr_iid","displayName":{"zh-CN":"mr_iid","en-US":"mr_iid"},"description":{"zh-CN":"代码平台事件参数 mr_iid","en-US":"Code-host event parameter mr_iid"}},{"fieldId":"mr_id","displayName":{"zh-CN":"mr_id","en-US":"mr_id"},"description":{"zh-CN":"代码平台事件参数 mr_id","en-US":"Code-host event parameter mr_id"}},{"fieldId":"mr_title","displayName":{"zh-CN":"mr_title","en-US":"mr_title"},"description":{"zh-CN":"代码平台事件参数 mr_title","en-US":"Code-host event parameter mr_title"}},{"fieldId":"mr_url","displayName":{"zh-CN":"mr_url","en-US":"mr_url"},"description":{"zh-CN":"代码平台事件参数 mr_url","en-US":"Code-host event parameter mr_url"}},{"fieldId":"commit_sha","displayName":{"zh-CN":"commit_sha","en-US":"commit_sha"},"description":{"zh-CN":"代码平台事件参数 commit_sha","en-US":"Code-host event parameter commit_sha"}}]}}	40fc99235b7700ad70d22e60c110a809854356ab38f873cdb01655fec36db053	compatibility	published	1793429200910
platform.task.status-changed	1	platform.task-lifecycle	1	{"schemaVersion":1,"eventTypeRef":{"id":"platform.task.status-changed","revision":1},"sourceRef":{"id":"platform.task-lifecycle","revision":1},"ownerTypeId":"task-execution","subjectTypeId":"platform.task","payloadSchemaId":"platform.task-status-change","displayName":{"zh-CN":"编排任务状态变化","en-US":"Orchestration task status changed"},"description":{"zh-CN":"一个编排任务已进入新的生命周期状态。","en-US":"An orchestration task entered a new lifecycle state."},"deliveryClass":"platform.task-status","triggerParameters":{"namespace":"task","fields":[{"fieldId":"task_id","displayName":{"zh-CN":"任务 ID","en-US":"Task ID"},"description":{"zh-CN":"任务 ID","en-US":"Task ID"}},{"fieldId":"status","displayName":{"zh-CN":"当前状态","en-US":"Current status"},"description":{"zh-CN":"当前状态","en-US":"Current status"}},{"fieldId":"previous_status","displayName":{"zh-CN":"上一状态","en-US":"Previous status"},"description":{"zh-CN":"上一状态","en-US":"Previous status"}},{"fieldId":"revision","displayName":{"zh-CN":"生命周期修订","en-US":"Lifecycle revision"},"description":{"zh-CN":"生命周期修订","en-US":"Lifecycle revision"}}]}}	dde2d8f3871c4612d1e45d1bbe95dd629891ff393962d9652b1787c40b86149e	public	published	1793429200936
platform.collaboration.committed	1	platform.collaboration-committed	1	{"schemaVersion":1,"eventTypeRef":{"id":"platform.collaboration.committed","revision":1},"sourceRef":{"id":"platform.collaboration-committed","revision":1},"ownerTypeId":"collaboration","subjectTypeId":"platform.task","payloadSchemaId":"platform.collaboration-committed","displayName":{"zh-CN":"协作事实已提交","en-US":"Collaboration fact committed"},"description":{"zh-CN":"一个人工门或协作投影变更已完成事务提交。","en-US":"A human-gate or collaboration projection change committed."},"deliveryClass":"platform.collaboration","catalogVisibility":"internal","triggerParameters":{"namespace":"collaboration","fields":[{"fieldId":"task_id","displayName":{"zh-CN":"任务 ID","en-US":"Task ID"},"description":{"zh-CN":"任务 ID","en-US":"Task ID"}},{"fieldId":"family","displayName":{"zh-CN":"事件族","en-US":"Event family"},"description":{"zh-CN":"事件族","en-US":"Event family"}},{"fieldId":"event_type","displayName":{"zh-CN":"事件类型","en-US":"Event type"},"description":{"zh-CN":"事件类型","en-US":"Event type"}},{"fieldId":"gate_kind","displayName":{"zh-CN":"人工门类型","en-US":"Gate kind"},"description":{"zh-CN":"人工门类型","en-US":"Gate kind"}}]}}	214018f52cf5878c5702b20657bce1ef86d78bb7e25e888b6df4526775e73b25	internal	published	1793429200937
\.


--
-- Data for Name: fusions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.fusions (id, skill_id, skill_name, base_skill_version, precondition_token, memory_ids_json, intent, status, iteration, current_task_id, proposed_worktree_path, proposed_diff, incorporated_memory_ids_json, skipped_json, changelog, applied_skill_version, owner_user_id, created_at, decided_by_user_id, decided_at, decision_reason, error) FROM stdin;
\.


--
-- Data for Name: intent_apply_journal; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_apply_journal (id, session_id, client_mutation_id, draft_id, draft_hash, state, prepared_artifacts_json, receipt_json, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: intent_draft_resolutions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_draft_resolutions (draft_id, session_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: intent_drafts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_drafts (id, session_id, revision, changeset_json, validation_json, draft_hash, produced_by_turn_id, context_revision, created_at) FROM stdin;
\.


--
-- Data for Name: intent_provenance; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_provenance (resource_type, resource_id, commit_id, session_id, created_at) FROM stdin;
\.


--
-- Data for Name: intent_sessions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_sessions (id, owner_user_id, title, status, context_revision, context_manifest_json, handle_watermark_json, current_draft_id, in_flight_turn_id, turn_seq, commit_seq, budget_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: intent_turn_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_turn_events (id, turn_id, event_seq, ts, kind, payload, session_id, parent_session_id, source, external_event_id) FROM stdin;
\.


--
-- Data for Name: intent_turns; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_turns (id, session_id, seq, role, kind, content_json, context_revision, envelope_nonce, run_meta_json, client_mutation_id, capture_state, capture_last_event_seq, capture_event_bytes, capture_root_session_id, capture_incomplete_reason, scratch_retained, created_at) FROM stdin;
\.


--
-- Data for Name: intent_working_set_changes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.intent_working_set_changes (id, session_id, client_mutation_id, request_hash, expected_turn_seq, expected_context_revision, mode, delta_json, state, error, resulting_context_revision, resulting_turn_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: legacy_code_work_item_links; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.legacy_code_work_item_links (id, mission_id, legacy_work_item_id, legacy_round_id, cutover_receipt_json, created_at) FROM stdin;
\.


--
-- Data for Name: lifecycle_alerts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.lifecycle_alerts (id, task_id, rule, severity, detail, detected_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: lifecycle_repair_audit; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.lifecycle_repair_audit (id, task_id, alert_id, alert_rule, alert_detail_json, option_id, actor_user_id, before_snapshot_json, after_snapshot_json, outcome, outcome_message, applied_at) FROM stdin;
\.


--
-- Data for Name: maintenance_runs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.maintenance_runs (id, job_key, job_class, slot_key, cycle_key, state, payload_json, cursor_version, cursor_json, lease_token, lease_expires_at, heartbeat_at, attempt, slice_no, counters_json, error_code, error_message, scheduled_at, created_at, updated_at, started_at, finished_at) FROM stdin;
01M68BBR84B3YJ2BQ8YQPXDNXS	intentRecovery	recovery	boot:1793429200946	boot:1793429200946	succeeded	{"activeIntentApplyJournalIds":[],"activeBundleApplyIds":[],"recoverTurnIds":[],"recoverTurns":false}	1	\N	\N	\N	\N	1	1	{"failed":0,"rolledForward":0,"queuedWorkingSets":0,"orphanedTurns":0,"workerSliceCount":1,"workerSliceMsTotal":1.621292000000011,"workerSliceMsMax":1.621292000000011,"dbStatementCount":3,"dbStatementMsTotal":0.08724900000001412,"dbStatementMsMax":0.05633299999999508,"dbStatementLe10Ms":3,"dbStatementLe50Ms":3,"dbStatementLe250Ms":3,"dbTransactionCount":0,"dbTransactionMsTotal":0,"dbTransactionMsMax":0,"dbTransactionLe10Ms":0,"dbTransactionLe50Ms":0,"dbTransactionLe250Ms":0}	\N	\N	1793429200946	1793429201156	1793429201311	1793429201308	1793429201311
01M68BC800HFRXDCPX9FWCVNEB	intentRecovery	recovery	boot:1793429217051	boot:1793429217051	succeeded	{"activeIntentApplyJournalIds":[],"activeBundleApplyIds":[],"recoverTurnIds":[],"recoverTurns":false}	1	\N	\N	\N	\N	1	1	{"failed":0,"rolledForward":0,"queuedWorkingSets":0,"orphanedTurns":0,"workerSliceCount":1,"workerSliceMsTotal":4.5927919999999745,"workerSliceMsMax":4.5927919999999745,"dbStatementCount":0,"dbStatementMsTotal":0,"dbStatementMsMax":0,"dbStatementLe10Ms":0,"dbStatementLe50Ms":0,"dbStatementLe250Ms":0,"dbTransactionCount":0,"dbTransactionMsTotal":0,"dbTransactionMsMax":0,"dbTransactionLe10Ms":0,"dbTransactionLe50Ms":0,"dbTransactionLe250Ms":0}	\N	\N	1793429217051	1793429217280	1793429217500	1793429217483	1793429217500
\.


--
-- Data for Name: maintenance_state; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.maintenance_state (key, value, updated_at) FROM stdin;
rfc354.frame-backfill.v1	{"completedAt":1793429200868,"tasks":0,"rowsUpdated":0,"roundsUpdated":0,"unreadableTasks":0,"unresolvedRows":0}	1793429200868
\.


--
-- Data for Name: mcp_probes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_probes (id, mcp_id, status, latency_ms, handshake_ms, server_info_json, protocol_version, capabilities_json, tools_json, resources_json, resource_templates_json, prompts_json, error_code, error_message, error_detail_json, schema_version, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mcp_runtime_test_create_receipts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_runtime_test_create_receipts (mcp_id, owner_user_id, client_create_id, request_digest, session_id, accepted_turn_id, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: mcp_runtime_test_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_runtime_test_events (id, test_session_id, first_seen_turn_id, event_seq, ts, kind, payload, session_id, parent_session_id, source, external_event_key) FROM stdin;
\.


--
-- Data for Name: mcp_runtime_test_session_leases; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_runtime_test_session_leases (protocol, runtime_session_id, test_session_id, created_turn_id, current_turn_id, lease_turn_id, lease_acquired_at, lease_nonce_digest) FROM stdin;
\.


--
-- Data for Name: mcp_runtime_test_sessions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_runtime_test_sessions (id, mcp_id, owner_user_id, client_create_id, client_create_digest, status, end_reason, mcp_config_hash, runtime_row_id, runtime_name, runtime_protocol, runtime_snapshot_json, runtime_binary_path, runtime_session_id, native_session_state, in_flight_turn_id, turn_seq, session_version, idle_deadline_at, continuation_blocked_reason, scratch_root, cleanup_state, cleanup_error_code, created_at, updated_at, ended_at) FROM stdin;
\.


--
-- Data for Name: mcp_runtime_test_turns; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcp_runtime_test_turns (id, session_id, seq, client_message_id, prompt_text, status, hard_deadline_at, capture_state, capture_incomplete_reason, capture_first_event_seq, capture_last_event_seq, capture_event_bytes, cancel_requested_at, pid, spawned_at, spawn_binary_path, exit_code, failure_code, stderr_tail, duration_ms, started_at, finished_at, created_at) FROM stdin;
\.


--
-- Data for Name: mcps; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mcps (id, name, description, type, config, enabled, owner_user_id, visibility, acl_revision, schema_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: memories; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.memories (id, scope_type, scope_id, title, body_md, tags, status, source_kind, source_event_id, source_task_id, distill_job_id, distill_action, supersedes_id, superseded_by_id, approved_by_user_id, approved_at, created_at, version, fused_into_skill, fused_into_skill_id, fused_into_skill_version, fused_at, fused_by_user_id, fused_fusion_id) FROM stdin;
\.


--
-- Data for Name: memory_distill_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.memory_distill_events (id, distill_job_id, attempt_index, session_id, parent_session_id, ts, kind, payload) FROM stdin;
\.


--
-- Data for Name: memory_distill_jobs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.memory_distill_jobs (id, debounce_key, source_kind, source_event_id, task_id, scope_resolved_json, status, attempts, next_run_at, last_error, created_at, started_at, finished_at, opencode_session_id, user_prompt_md, exit_code, stderr_excerpt, dedup_snapshot_ids_json, output_lang) FROM stdin;
\.


--
-- Data for Name: memory_scope_move_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.memory_scope_move_events (id, memory_id, actor_user_id, actor_source, from_scope_type, from_scope_id, to_scope_type, to_scope_id, expected_version, resulting_version, correlation_id, causation_id, occurred_at) FROM stdin;
\.


--
-- Data for Name: mission_input_uploads; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.mission_input_uploads (id, actor_user_id, original_name, bytes, sha256, blob_ref, state, claimed_by_mission_id, upload_idempotency_key, expires_at, created_at, claimed_at) FROM stdin;
\.


--
-- Data for Name: node_run_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.node_run_events (id, node_run_id, ts, kind, payload, session_id, parent_session_id) FROM stdin;
\.


--
-- Data for Name: node_run_outputs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.node_run_outputs (node_run_id, port_name, content, kind, archive_json, active) FROM stdin;
\.


--
-- Data for Name: node_runs; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.node_runs (id, task_id, node_id, parent_node_run_id, container_run_id, scope_path, iteration, shard_key, retry_index, wg_round, review_iteration, status, started_at, finished_at, pid, spawn_binary_path, spawn_launch_nonce, exit_code, error_message, failure_code, prompt_text, prompt_path, envelope_nonce, force_activated, tok_input, tok_output, tok_cache_create, tok_cache_read, tok_total, pre_snapshot, opencode_session_id, runtime, runtime_binary, runtime_params_json, inventory_snapshot_json, runtime_inventory_json, startup_verification_json, wrapper_progress_json, injected_memories_json, port_validation_failures_json, commit_push_json, pre_snapshot_repos_json, iso_worktree_path, iso_base_snapshot, iso_base_snapshot_repos_json, iso_node_tree, iso_node_tree_repos_json, iso_submodules_json, iso_submodules_repos_json, merge_state, consumed_upstream_runs_json, shard_value_hash, rerun_cause, superseded_by_review, rolled_back, agent_override_name, agent_override_id, child_task_id, continuation_slot_key, lineage_slot_path_json, operation_generation) FROM stdin;
\.


--
-- Data for Name: observer_activations; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.observer_activations (source_id, source_revision, subscriber_count, state, generation, wake_epoch, cursor_json, lease_owner, lease_epoch, lease_expires_at, next_scan_at, last_scan_at, last_success_at, last_error_code, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_providers; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.oidc_providers (id, slug, display_name, issuer_url, client_id, client_secret_enc, scopes, provisioning, allowed_email_domains_json, icon_url, enabled, authorization_endpoint, token_endpoint, userinfo_endpoint, userinfo_request_style, jwks_uri, trust_email_verified, username_claim, git_name_claim, email_claim, subject_claim, created_at, updated_at, schema_version) FROM stdin;
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.plugins (id, name, spec, options_json, description, enabled, source_kind, cached_path, resolved_version, installed_at, owner_user_id, visibility, acl_revision, schema_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recovery_events; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.recovery_events (id, task_id, node_run_id, actor, kind, reason, before_json, after_json, created_at) FROM stdin;
\.


--
-- Data for Name: repo_capability_config; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.repo_capability_config (id, repo_id, capability, template_id, enabled, trigger_config_json, readiness, readiness_issues_json, dependency_revision, last_validated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: repo_group_nodes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.repo_group_nodes (group_id, path, attachment_kind, cached_repo_id, ref, subdir, child_group_id, readonly) FROM stdin;
\.


--
-- Data for Name: repo_groups; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.repo_groups (id, name, description, version, created_by_user_id, created_at, updated_at, schema_version) FROM stdin;
\.


--
-- Data for Name: repository_employee_assignments; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.repository_employee_assignments (id, scope_kind, scope_ref, employee_id, employee_revision, selection_policy_id, selection_policy_revision, execution_policy_id, execution_policy_revision, default_requirement_source_key, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: repository_transport_connections; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.repository_transport_connections (provider, connection_generation, endpoint_binding_digest, api_base_url, reject_unauthorized, transport_mappings_json, allowed_http_base_urls_json, global_token_enc, global_token_hint, credential_revision, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: resource_bundle_applies; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.resource_bundle_applies (id, scope, key, actor_user_id, state, prepared_artifacts_json, receipt_json, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resource_grants; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.resource_grants (resource_type, resource_id, user_id, added_by, added_at, level) FROM stdin;
\.


--
-- Data for Name: review_comments; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.review_comments (id, doc_version_id, anchor_section_path, anchor_paragraph_idx, anchor_offset_start, anchor_offset_end, selected_text, context_before, context_after, occurrence_index, comment_text, author, author_role, created_at) FROM stdin;
\.


--
-- Data for Name: review_node_reviewers; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.review_node_reviewers (task_id, review_node_id, reviewer_user_id, assigned_by_user_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: runtime_session_leases; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.runtime_session_leases (protocol, session_id, task_id, node_id, created_node_run_id, lease_node_run_id, lease_nonce_digest, leased_at, reset_pending) FROM stdin;
\.


--
-- Data for Name: runtimes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.runtimes (id, name, protocol, binary_path, enabled, model, variant, temperature, steps, max_steps, is_sandbox, config_dir_env, config_dir_name, extra_args_json, last_probe_json, probe_fence, created_by, created_at, updated_at) FROM stdin;
01M68BBQZW6C5DTY5HQ37YG6MS	claude-code	claude-code	\N	t	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	0	\N	1793429200000	1793429200000
01M68BBQZWCNZ6HHVZ9FMCBJZR	opencode	opencode	/private/tmp/claude-501/-Users-wangbinquan-dev-proj-agent-workflow/7b6d8dcb-ec08-41df-bb1e-0edc98a26580/scratchpad/fakebin/opencode	t	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	0	\N	1793429200000	1793429200893
\.


--
-- Data for Name: scheduled_tasks; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.scheduled_tasks (id, name, owner_user_id, launch_kind, launch_payload, schedule_spec, enabled, next_run_at, last_run_at, last_status, last_error, last_task_id, consecutive_failures, acl_revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: skill_operation_locks; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.skill_operation_locks (locked_skill_id, op_id, created_at) FROM stdin;
\.


--
-- Data for Name: skill_operations; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.skill_operations (op_id, skill_id, kind, phase, active, staging_path, backup_path, candidate_path, candidate_fingerprint, backup_fingerprint, target_version, generation, owner_user_id, precondition_json, created_at) FROM stdin;
\.


--
-- Data for Name: skill_versions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.skill_versions (id, skill_id, version_index, files_path, source, summary, fusion_id, restored_from_version, author_user_id, content_hash, created_at) FROM stdin;
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.skills (id, name, description, managed_path, owner_user_id, visibility, schema_version, content_version, acl_revision, meta_revision, reservation_state, version_state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_archive_audit; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_archive_audit (id, source, actor_user_id, retention_days, tree_count, task_count, skipped_count, root_task_ids_json, created_at) FROM stdin;
\.


--
-- Data for Name: task_collaborators; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_collaborators (task_id, user_id, role, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: task_execution_effect_attempts; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_effect_attempts (id, effect_id, attempt_no, intent_id, epoch, state, candidate_id, request_hash, recovery_class, recovery_descriptor_json, classifier_version, transport_policy_version, application_evidence, retry_authority, receipt_json, failure_code, prepared_at, acting_at, settled_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_execution_effect_fences; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_effect_fences (effect_attempt_id, fence_key, acquired_epoch, acquired_at, released_at) FROM stdin;
\.


--
-- Data for Name: task_execution_effects; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_effects (id, task_id, origin_intent_id, current_intent_id, operation_key, execution_lineage_id, operation_family_key, operation_generation, kind, request_hash, slot_path_json, slot_path_digest, state, last_attempt_no, receipt_json, failure_code, prepared_at, settled_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_execution_intents; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_intents (id, task_id, kind, state, source, request_hash, payload_json, execution_lineage_id, continuation_slot_key, slot_path_json, operation_generation, replay_authorization_id, authorization_scope_json, expected_task_revision, claimed_epoch, failure_code, created_at, claimed_at, completed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_execution_lineage_operation_records; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_lineage_operation_records (id, record_kind, execution_lineage_id, operation_family_key, operation_generation, highest_settled_generation, last_outcome, request_hash, slot_path_json, slot_path_digest, root_anchor_task_id, ancestor_anchor_task_id, current_anchor_task_id, source_task_id, source_effect_id, source_attempt_id, provider_coordinate_json, failure_code, decision_state, replay_authorization_id, authorization_scope_json, actor_user_id, authorization_source, bound_intent_id, new_effect_id, record_revision, compacted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_execution_maintenance_claims; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_maintenance_claims (id, root_task_id, operation, state, member_set_digest, expected_tree_digest, revision, cleanup_plan_json, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: task_execution_maintenance_members; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_maintenance_members (claim_id, task_id, expected_task_revision, expected_owner_revision, expected_topology_revision, expected_ledger_digest, released_at) FROM stdin;
\.


--
-- Data for Name: task_execution_owners; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_execution_owners (task_id, owner_id, daemon_generation, epoch, state, lease_until, revision, last_heartbeat_at, recovery_code, recovery_proof_digest, updated_at) FROM stdin;
\.


--
-- Data for Name: task_feedback; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_feedback (id, task_id, author_user_id, body_md, created_at, distilled, distill_job_id) FROM stdin;
\.


--
-- Data for Name: task_node_clarify_directives; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_node_clarify_directives (task_id, node_id, shard_key, directive, set_by, updated_at) FROM stdin;
\.


--
-- Data for Name: task_questions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_questions (id, task_id, origin_node_run_id, question_id, question_title, source_kind, role_kind, iteration, loop_iter, default_target_node_id, override_target_node_id, dispatched_at, dispatched_by, trigger_run_id, staged_at, staged_by, auto_dispatch_deferred_at, sealed_at, sealed_by, confirmation, confirmed_by, confirmed_by_role, confirmed_at, last_reassigned_by, last_reassigned_at, manual_body, manual_created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_repos; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_repos (task_id, repo_index, repo_path, repo_url, cached_repo_id, base_branch, branch, working_branch, base_commit, worktree_path, worktree_dir_name, mount_path, subdir, readonly, readonly_dirty_count, workspace_profile_version, workspace_profile_digest, has_submodules, submodule_init_ok, submodule_init_error, schema_version) FROM stdin;
\.


--
-- Data for Name: task_space_nodes; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.task_space_nodes (task_id, node_path, schema_version) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.tasks (id, name, workflow_id, workflow_snapshot, workflow_version, repo_path, repo_url, cached_repo_id, repo_group_id, repo_group_name, worktree_path, base_branch, branch, base_commit, status, inputs, max_duration_ms, max_total_tokens, started_at, running_ms, running_since, finished_at, error_summary, error_message, failed_node_id, auto_recovery_attempts, auto_recovery_suspended, auto_recovery_window_started_at, expires_at, deleted_at, schema_version, owner_user_id, launch_origin, catalog_visibility, git_user_name, git_user_email, working_branch, auto_commit_push, repo_count, scheduled_task_id, webhook_trigger_id, webhook_fire_id, event_subscription_id, event_delivery_id, lifecycle_event_revision, source_termination_binding, source_termination_launch_rev, source_termination_fence, source_termination_effect_rev, workgroup_id, workgroup_config_json, space_kind, source_agent_name, code_round_id, digital_employee_round_id, digital_employee_case_id, source_agent_id, workspace_pruning_at, workspace_prune_cause, workspace_pruned_at, parent_task_id, parent_node_run_id, invocation_depth, ref_closure_json, trigger_context_json, platform_input_paths_json, branch_started_at, root_task_id, execution_lineage_id, lineage_slot_path_json) FROM stdin;
\.


--
-- Data for Name: token_audit; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.token_audit (id, pat_id, user_id, channel, tool_name, method, path, resource_kind, resource_id, status_code, snapshot_failed, created_at) FROM stdin;
\.


--
-- Data for Name: token_delete_snapshot; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.token_delete_snapshot (id, audit_id, resource_kind, resource_id, snapshot_json, created_at) FROM stdin;
\.


--
-- Data for Name: user_access_audit; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_access_audit (id, target_user_id, actor_user_id, actor_kind, operation_id, correlation_id, before_role, after_role, added_permissions_json, removed_permissions_json, access_revision, created_at) FROM stdin;
\.


--
-- Data for Name: user_identities; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_identities (id, user_id, provider_id, subject, email, email_verified, preferred_snapshot, linked_at) FROM stdin;
\.


--
-- Data for Name: user_pats; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_pats (id, user_id, name, token_hash, scopes_json, created_at, last_used_at, expires_at, revoked_at, purpose) FROM stdin;
\.


--
-- Data for Name: user_permission_grants; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_permission_grants (user_id, permission, granted_by_user_id, granted_at) FROM stdin;
\.


--
-- Data for Name: user_repository_transport_credentials; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_repository_transport_credentials (user_id, provider, connection_generation, endpoint_binding_digest, token_enc, token_hint, credential_revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.user_sessions (id, user_id, token_hash, user_agent, created_at, last_used_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.users (id, username, email, display_name, git_name, password_hash, role, status, force_password_change, created_by, created_at, updated_at, last_login_at, schema_version, access_revision) FROM stdin;
__system__	__system__	\N	System	System	\N	admin	active	f	\N	1793429200000	1793429200000	\N	1	0
\.


--
-- Data for Name: verification_profile_revisions; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.verification_profile_revisions (profile_id, revision, content_json, content_digest, published_at, published_by) FROM stdin;
\.


--
-- Data for Name: verification_profiles; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.verification_profiles (id, name, draft_json, published_revision, owner_user_id, visibility, acl_revision, created_at, updated_at, archived_at) FROM stdin;
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_deliveries (id, endpoint_id, event_uuid, attempt_count, gitlab_event_header, object_kind, event_type, repo_path, stream_hint, mr_fact_key, mr_stream_key, mr_stream_revision, mr_state_after, status, status_reason, replayed_from_delivery_id, received_at, body_json) FROM stdin;
\.


--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_endpoints (id, name, provider, url_token, secret_enc, enabled, preferred_clone_protocol, last_delivery_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_mr_control_effects; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_mr_control_effects (id, delivery_id, endpoint_id, stream_key, binding, revision, observed_event_type, kind, status, lease_owner, lease_expires_at, attempt_count, next_attempt_at, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_mr_control_targets; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_mr_control_targets (effect_id, task_id, prior_status, fence_outcome, cancel_outcome, release_outcome, error, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_mr_launch_guards; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_mr_launch_guards (id, endpoint_id, stream_key, binding, launch_revision, delivery_id, fire_id, trigger_id, trigger_name_snapshot, task_id, launch_owner_key, status, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_mr_stream_states; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_mr_stream_states (endpoint_id, stream_key, project_id, mr_iid, state, revision, last_terminal_revision, last_delivery_id, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_trigger_fires; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_trigger_fires (id, delivery_id, trigger_id, stream_key, outcome, superseded_task_id, task_id, employee_case_id, error, fired_at) FROM stdin;
\.


--
-- Data for Name: webhook_trigger_streams; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_trigger_streams (trigger_id, stream_key, consecutive_fires, last_fire_at, reset_at, reset_by) FROM stdin;
\.


--
-- Data for Name: webhook_triggers; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.webhook_triggers (id, name, endpoint_id, owner_user_id, enabled, repo_scope, event_types, branch_filter, command_prefix, ignore_usernames, launch_kind, launch_ref_id, launch_payload, template_syntax_version, max_consecutive_fires, auto_register_repos, cancel_on_mr_terminal, last_fired_at, last_status, last_error, last_task_id, consecutive_failures, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workflows (id, name, description, definition, version, owner_user_id, visibility, acl_revision, builtin, schema_version, created_at, updated_at) FROM stdin;
00000000000000000000000002	aw-skill-fusion	Built-in memory→skill fusion workflow (RFC-101).	{"$schema_version":6,"inputs":[{"kind":"text","key":"intent","label":"Merge intent","required":false},{"kind":"text","key":"memories","label":"Memories","required":true}],"nodes":[{"id":"in_intent","kind":"input","inputKey":"intent","position":{"x":90,"y":444}},{"id":"in_memories","kind":"input","inputKey":"memories","position":{"x":90,"y":272}},{"id":"merger","kind":"agent-single","agentId":"00000000000000000000000001","agentName":"aw-skill-merger","promptTemplate":"Fuse the following approved memories into this skill.\\n\\n## Merge intent\\n{{intent}}\\n\\n## Memories to fuse\\n{{memories}}\\n\\nThe skill's files are in your working directory. Clarify with the merger first (mandatory), then edit the files in place and write the result manifest.","position":{"x":440,"y":328}},{"id":"clarify","kind":"clarify","title":"Confirm fusion","position":{"x":80,"y":80}}],"edges":[{"id":"e_intent","source":{"nodeId":"in_intent","portName":"intent"},"target":{"nodeId":"merger","portName":"intent"}},{"id":"e_memories","source":{"nodeId":"in_memories","portName":"memories"},"target":{"nodeId":"merger","portName":"memories"}},{"id":"e_ask","source":{"nodeId":"merger","portName":"__clarify__"},"target":{"nodeId":"clarify","portName":"questions"}},{"id":"e_ans","source":{"nodeId":"clarify","portName":"answers"},"target":{"nodeId":"merger","portName":"__clarify_response__"}}],"outputs":[]}	1	__system__	public	0	t	1	1793429200871	1793429200871
aw-demo-workflow-fanout	[demo] Review, then ask	Adds the platform's other human touchpoint — asking a question. 示例数据，可以安全删除；删除后不会再次生成。 / Sample data — safe to delete.	{"$schema_version":6,"edges":[{"id":"e_in","source":{"nodeId":"in_diff","portName":"diff"},"target":{"nodeId":"review","portName":"diff"}},{"id":"e_ask","source":{"nodeId":"review","portName":"__clarify__"},"target":{"nodeId":"ask","portName":"questions"}},{"id":"e_ans","source":{"nodeId":"ask","portName":"answers"},"target":{"nodeId":"review","portName":"__clarify_response__"}},{"id":"e_out","source":{"nodeId":"review","portName":"findings"},"target":{"nodeId":"out_findings","portName":"findings"}}],"inputs":[{"key":"diff","kind":"text","label":"Diff to review","required":true}],"nodes":[{"id":"in_diff","inputKey":"diff","kind":"input"},{"agentId":"aw-demo-reviewer","agentName":"[demo] reviewer","id":"review","kind":"agent-single","promptTemplate":"Review this change. Ask if anything is unclear.\\n\\n{{diff}}"},{"id":"ask","kind":"clarify","title":"Anything unclear?"},{"id":"out_findings","kind":"output"}],"outputs":[{"bind":{"nodeId":"review","portName":"findings"},"name":"findings"}]}	1	__system__	public	0	f	1	1700000000000	1700000000000
aw-demo-workflow-review	[demo] Review a change	The readable half of what mr-review does, as an ordinary workflow. 示例数据，可以安全删除；删除后不会再次生成。 / Sample data — safe to delete.	{"$schema_version":6,"edges":[{"id":"e_in","source":{"nodeId":"in_diff","portName":"diff"},"target":{"nodeId":"review","portName":"diff"}},{"id":"e_out","source":{"nodeId":"review","portName":"findings"},"target":{"nodeId":"out_findings","portName":"findings"}}],"inputs":[{"key":"diff","kind":"text","label":"Diff to review","required":true}],"nodes":[{"id":"in_diff","inputKey":"diff","kind":"input"},{"agentId":"aw-demo-reviewer","agentName":"[demo] reviewer","id":"review","kind":"agent-single","promptTemplate":"Review this change and list findings.\\n\\n{{diff}}"},{"id":"out_findings","kind":"output"}],"outputs":[{"bind":{"nodeId":"review","portName":"findings"},"name":"findings"}]}	1	__system__	public	0	f	1	1700000000000	1700000000000
\.


--
-- Data for Name: workgroup_assignments; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroup_assignments (id, task_id, round, source, created_by_run_id, created_by_user_id, assignee_member_id, title, brief_md, status, node_run_id, result_message_id, dedup_key, attempt_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workgroup_member_cursors; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroup_member_cursors (task_id, member_id, last_consumed_message_id, updated_at) FROM stdin;
\.


--
-- Data for Name: workgroup_members; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroup_members (id, workgroup_id, member_type, agent_name, agent_id, user_id, display_name, role_desc, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: workgroup_messages; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroup_messages (id, task_id, round, author_kind, author_member_id, author_user_id, kind, body_md, template_key, template_params_json, mentions_json, assignment_id, trigger_message_id, created_at) FROM stdin;
\.


--
-- Data for Name: workgroup_task_state; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroup_task_state (task_id, gate_status, gate_summary, gate_rejected_comment, pause_reason, dw_state_json, result_message_id, updated_at) FROM stdin;
\.


--
-- Data for Name: workgroups; Type: TABLE DATA; Schema: agent_workflow; Owner: -
--

COPY agent_workflow.workgroups (id, name, description, instructions, mode, output_contract, leader_member_id, share_outputs, direct_messages, blackboard, max_rounds, completion_gate, clarify_budget, fan_out, version, owner_user_id, visibility, acl_revision, schema_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: database_generations; Type: TABLE DATA; Schema: agent_workflow_meta; Owner: -
--

COPY agent_workflow_meta.database_generations (generation_id, operation_id, source_generation_id, contract_digest, state, activated_at, first_live_write_at) FROM stdin;
dbg_pg_01M68BBT61MNA9V6MHA5SZNGMM	dbm_01M68BBT61MNA9V6MHA5SZNGMM	dbg_legacy_sqlite	sha256:3ee9be23a3e0f46c002f76b382b33d137c6a9ef4ef78a3ee71e212e5247c72d7	active	1793429205266	1793429216573
\.


--
-- Data for Name: logical_copy_chunks; Type: TABLE DATA; Schema: agent_workflow_meta; Owner: -
--

COPY agent_workflow_meta.logical_copy_chunks (operation_id, table_id, chunk_index, chunk_digest, row_count, first_key_json, last_key_json, committed_at) FROM stdin;
dbm_01M68BBT61MNA9V6MHA5SZNGMM	agents	0	sha256:98d0d47cc5760f4e3cfb51fc89d96409e9d89a5c9799b2ed5e9b96824c5915ca	18	[\n  {\n    "type": "text",\n    "value": "00000000000000000000000001"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-reviewer"\n  }\n]	1793429203660
dbm_01M68BBT61MNA9V6MHA5SZNGMM	auth_login_policy	0	sha256:00a8ded295d15011fccec53a6ae53fef1eff951e5cd85e3a37dd4e6c71b05687	1	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	1793429203682
dbm_01M68BBT61MNA9V6MHA5SZNGMM	capability_templates	0	sha256:5f57f1952e3e6a979da38c570d06f3016cd640a5644e80ba90cee44cc22aec86	1	[\n  {\n    "type": "text",\n    "value": "aw-demo-template-mr-review"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-template-mr-review"\n  }\n]	1793429203698
dbm_01M68BBT61MNA9V6MHA5SZNGMM	code_round_stages	0	sha256:ea0415f037829c5d902f57335879ee4b06cfc80b6adf9364ec481a0f3750a13c	13	[\n  {\n    "type": "text",\n    "value": "aw-demo-round-0"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-round-9"\n  }\n]	1793429203726
dbm_01M68BBT61MNA9V6MHA5SZNGMM	code_work_items	0	sha256:ffd66beb045705f25a5f0c8fc539368dc048fdb1b75d3fe0074d205c540ad5bb	1	[\n  {\n    "type": "text",\n    "value": "aw-demo-work-item"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-work-item"\n  }\n]	1793429203737
dbm_01M68BBT61MNA9V6MHA5SZNGMM	code_work_rounds	0	sha256:3a8ed0b2c29c151275f8ecde8d804f5234f87b6e8a441c0122e742fe5949664b	1	[\n  {\n    "type": "text",\n    "value": "aw-demo-round"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-round"\n  }\n]	1793429203750
dbm_01M68BBT61MNA9V6MHA5SZNGMM	committed_event_family_cutovers	0	sha256:5784918c3783b0c3d805adda87eecdbd7ab8cbb1eaaf7e490228349a94629175	4	[\n  {\n    "type": "text",\n    "value": "collaboration"\n  },\n  {\n    "type": "text",\n    "value": "clarify"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "task-execution"\n  },\n  {\n    "type": "text",\n    "value": "task-lifecycle"\n  }\n]	1793429203768
dbm_01M68BBT61MNA9V6MHA5SZNGMM	employee_execution_policy_revisions	0	sha256:34e584c86b4e4b72d9db87f70e40f342eec797f7ede36eebb1a74b76bf98d209	1	[\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	[\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	1793429203890
dbm_01M68BBT61MNA9V6MHA5SZNGMM	employee_os_settings	0	sha256:1c9277551a0d8686b53770fb8633e554ea57a63ff9f0f64794e30763651b39e7	1	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	1793429203916
dbm_01M68BBT61MNA9V6MHA5SZNGMM	employee_os_writer_state	0	sha256:c8ba693e0acc2d92dbe90ea5064ca98693bd66affeaaa8be18ba6d13b1827e3c	1	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "global"\n  }\n]	1793429203925
dbm_01M68BBT61MNA9V6MHA5SZNGMM	employee_type_packages	0	sha256:9622a2e8b0a0c8db2477aa9ca9f7be335fe2d539fdba405b7040435ff9f686a0	1	[\n  {\n    "type": "text",\n    "value": "development"\n  },\n  {\n    "type": "integer",\n    "value": "10"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "development"\n  },\n  {\n    "type": "integer",\n    "value": "10"\n  }\n]	1793429203947
dbm_01M68BBT61MNA9V6MHA5SZNGMM	event_sources	0	sha256:ac50d0225c58cdcf7127d09c0c206afad08027c5c2e814d3fe22d66edd59c7ef	6	[\n  {\n    "type": "text",\n    "value": "code-host.activity"\n  },\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "platform.task-lifecycle"\n  },\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	1793429203975
dbm_01M68BBT61MNA9V6MHA5SZNGMM	event_type_catalog	0	sha256:99f460333fb23a4eea7b6efcf7f3fb7011264adfea19bb0bd8359b4e7e737b86	33	[\n  {\n    "type": "text",\n    "value": "approval.status.changed"\n  },\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "platform.task.status-changed"\n  },\n  {\n    "type": "integer",\n    "value": "1"\n  }\n]	1793429203989
dbm_01M68BBT61MNA9V6MHA5SZNGMM	maintenance_runs	0	sha256:a6a794c499386aa6922e3cf6236727eac0bc68d78920184739267076d821ffc1	1	[\n  {\n    "type": "text",\n    "value": "01M68BBR84B3YJ2BQ8YQPXDNXS"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "01M68BBR84B3YJ2BQ8YQPXDNXS"\n  }\n]	1793429204041
dbm_01M68BBT61MNA9V6MHA5SZNGMM	maintenance_state	0	sha256:65c1c9ee46eabefb10b716f091fd04d7455d44b60d8e191d77d53bf32868da79	1	[\n  {\n    "type": "text",\n    "value": "rfc354.frame-backfill.v1"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "rfc354.frame-backfill.v1"\n  }\n]	1793429204050
dbm_01M68BBT61MNA9V6MHA5SZNGMM	runtimes	0	sha256:6076030eceba8d7e0d387deb9ceb84023343cabcfc9725577201f8d9eb41f5a7	2	[\n  {\n    "type": "text",\n    "value": "01M68BBQZW6C5DTY5HQ37YG6MS"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "01M68BBQZWCNZ6HHVZ9FMCBJZR"\n  }\n]	1793429204151
dbm_01M68BBT61MNA9V6MHA5SZNGMM	users	0	sha256:f2fdaa09d5743758a0ac91885c99461d4f06c029e29907202840c80a6f1faa3c	1	[\n  {\n    "type": "text",\n    "value": "__system__"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "__system__"\n  }\n]	1793429204269
dbm_01M68BBT61MNA9V6MHA5SZNGMM	workflows	0	sha256:3655712bb3168aacdb9d6cafd50735df67c958424ce9dd7abea0e90ff9186ad2	3	[\n  {\n    "type": "text",\n    "value": "00000000000000000000000002"\n  }\n]	[\n  {\n    "type": "text",\n    "value": "aw-demo-workflow-review"\n  }\n]	1793429204326
\.


--
-- Data for Name: logical_copy_operations; Type: TABLE DATA; Schema: agent_workflow_meta; Owner: -
--

COPY agent_workflow_meta.logical_copy_operations (operation_id, source_generation_id, contract_digest, plan_digest, stage, created_at, updated_at) FROM stdin;
dbm_01M68BBT61MNA9V6MHA5SZNGMM	dbg_legacy_sqlite	sha256:3ee9be23a3e0f46c002f76b382b33d137c6a9ef4ef78a3ee71e212e5247c72d7	sha256:faba80bbbba0777c04f4af1c6f750ae952fa208aea1eaefd2b020f12eeb5fb02	finalized	1793429203349	1793429205279
\.


--
-- Data for Name: schema_contract; Type: TABLE DATA; Schema: agent_workflow_meta; Owner: -
--

COPY agent_workflow_meta.schema_contract (singleton, contract_digest, active_table_count, archive_only_table_count) FROM stdin;
t	sha256:3ee9be23a3e0f46c002f76b382b33d137c6a9ef4ef78a3ee71e212e5247c72d7	178	6
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: agent_workflow_meta; Owner: -
--

COPY agent_workflow_meta.schema_migrations (baseline_id, contract_digest, plan_digest, applied_at) FROM stdin;
0000_rfc349_baseline_v1	sha256:3ee9be23a3e0f46c002f76b382b33d137c6a9ef4ef78a3ee71e212e5247c72d7	sha256:faba80bbbba0777c04f4af1c6f750ae952fa208aea1eaefd2b020f12eeb5fb02	1793429204371
\.


--
-- Name: intent_turn_events_id_seq; Type: SEQUENCE SET; Schema: agent_workflow; Owner: -
--

SELECT pg_catalog.setval('agent_workflow.intent_turn_events_id_seq', 1, false);


--
-- Name: mcp_runtime_test_events_id_seq; Type: SEQUENCE SET; Schema: agent_workflow; Owner: -
--

SELECT pg_catalog.setval('agent_workflow.mcp_runtime_test_events_id_seq', 1, false);


--
-- Name: memory_distill_events_id_seq; Type: SEQUENCE SET; Schema: agent_workflow; Owner: -
--

SELECT pg_catalog.setval('agent_workflow.memory_distill_events_id_seq', 1, false);


--
-- Name: node_run_events_id_seq; Type: SEQUENCE SET; Schema: agent_workflow; Owner: -
--

SELECT pg_catalog.setval('agent_workflow.node_run_events_id_seq', 1, false);


--
-- Name: action_template_revisions action_template_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.action_template_revisions
    ADD CONSTRAINT action_template_revisions_pkey PRIMARY KEY (template_id, revision);


--
-- Name: action_templates action_templates_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.action_templates
    ADD CONSTRAINT action_templates_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: auth_login_policy auth_login_policy_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.auth_login_policy
    ADD CONSTRAINT auth_login_policy_pkey PRIMARY KEY (id);


--
-- Name: automation_policies automation_policies_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.automation_policies
    ADD CONSTRAINT automation_policies_pkey PRIMARY KEY (id);


--
-- Name: automation_policy_revisions automation_policy_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.automation_policy_revisions
    ADD CONSTRAINT automation_policy_revisions_pkey PRIMARY KEY (policy_id, revision);


--
-- Name: cached_repos cached_repos_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.cached_repos
    ADD CONSTRAINT cached_repos_pkey PRIMARY KEY (id);


--
-- Name: cached_repos cached_repos_url_hash_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.cached_repos
    ADD CONSTRAINT cached_repos_url_hash_unique UNIQUE (url_hash);


--
-- Name: capability_templates capability_templates_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.capability_templates
    ADD CONSTRAINT capability_templates_pkey PRIMARY KEY (id);


--
-- Name: clarify_rounds clarify_rounds_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.clarify_rounds
    ADD CONSTRAINT clarify_rounds_pkey PRIMARY KEY (id);


--
-- Name: code_ai_attempts code_ai_attempts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_ai_attempts
    ADD CONSTRAINT code_ai_attempts_pkey PRIMARY KEY (id);


--
-- Name: code_findings code_findings_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_findings
    ADD CONSTRAINT code_findings_pkey PRIMARY KEY (id);


--
-- Name: code_host_connections code_host_connections_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_host_connections
    ADD CONSTRAINT code_host_connections_pkey PRIMARY KEY (provider);


--
-- Name: code_round_stages code_round_stages_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_round_stages
    ADD CONSTRAINT code_round_stages_pkey PRIMARY KEY (id);


--
-- Name: code_trigger_deliveries code_trigger_deliveries_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_trigger_deliveries
    ADD CONSTRAINT code_trigger_deliveries_pkey PRIMARY KEY (id);


--
-- Name: code_work_items code_work_items_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_work_items
    ADD CONSTRAINT code_work_items_pkey PRIMARY KEY (id);


--
-- Name: code_work_rounds code_work_rounds_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.code_work_rounds
    ADD CONSTRAINT code_work_rounds_pkey PRIMARY KEY (id);


--
-- Name: collaboration_gate_artifacts collaboration_gate_artifacts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.collaboration_gate_artifacts
    ADD CONSTRAINT collaboration_gate_artifacts_pkey PRIMARY KEY (operation_id, artifact_key);


--
-- Name: collaboration_gate_operations collaboration_gate_operations_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.collaboration_gate_operations
    ADD CONSTRAINT collaboration_gate_operations_pkey PRIMARY KEY (id);


--
-- Name: committed_event_aggregate_heads committed_event_aggregate_heads_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.committed_event_aggregate_heads
    ADD CONSTRAINT committed_event_aggregate_heads_pkey PRIMARY KEY (producer, family, aggregate_kind, aggregate_id);


--
-- Name: committed_event_deliveries committed_event_deliveries_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.committed_event_deliveries
    ADD CONSTRAINT committed_event_deliveries_pkey PRIMARY KEY (event_id, consumer_id);


--
-- Name: committed_event_family_cutovers committed_event_family_cutovers_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.committed_event_family_cutovers
    ADD CONSTRAINT committed_event_family_cutovers_pkey PRIMARY KEY (producer, family);


--
-- Name: committed_events committed_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.committed_events
    ADD CONSTRAINT committed_events_pkey PRIMARY KEY (id);


--
-- Name: custom_event_source_definitions custom_event_source_definitions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.custom_event_source_definitions
    ADD CONSTRAINT custom_event_source_definitions_pkey PRIMARY KEY (id);


--
-- Name: custom_event_source_revisions custom_event_source_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.custom_event_source_revisions
    ADD CONSTRAINT custom_event_source_revisions_pkey PRIMARY KEY (source_id, revision);


--
-- Name: development_action_runs development_action_runs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_action_runs
    ADD CONSTRAINT development_action_runs_pkey PRIMARY KEY (id);


--
-- Name: development_adapter_definition_revisions development_adapter_definition_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_adapter_definition_revisions
    ADD CONSTRAINT development_adapter_definition_revisions_pkey PRIMARY KEY (adapter_id, revision);


--
-- Name: development_adapter_definitions development_adapter_definitions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_adapter_definitions
    ADD CONSTRAINT development_adapter_definitions_pkey PRIMARY KEY (id);


--
-- Name: development_agent_attempts development_agent_attempts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_agent_attempts
    ADD CONSTRAINT development_agent_attempts_pkey PRIMARY KEY (id);


--
-- Name: development_approval_sagas development_approval_sagas_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_approval_sagas
    ADD CONSTRAINT development_approval_sagas_pkey PRIMARY KEY (id);


--
-- Name: development_bundle_refs development_bundle_refs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_bundle_refs
    ADD CONSTRAINT development_bundle_refs_pkey PRIMARY KEY (id);


--
-- Name: development_decisions development_decisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_decisions
    ADD CONSTRAINT development_decisions_pkey PRIMARY KEY (id);


--
-- Name: development_deferred_wakes development_deferred_wakes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_deferred_wakes
    ADD CONSTRAINT development_deferred_wakes_pkey PRIMARY KEY (id);


--
-- Name: development_effects development_effects_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_effects
    ADD CONSTRAINT development_effects_pkey PRIMARY KEY (id);


--
-- Name: development_fact_snapshots development_fact_snapshots_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_fact_snapshots
    ADD CONSTRAINT development_fact_snapshots_pkey PRIMARY KEY (id);


--
-- Name: development_feedback_ledger development_feedback_ledger_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_feedback_ledger
    ADD CONSTRAINT development_feedback_ledger_pkey PRIMARY KEY (id);


--
-- Name: development_mission_links development_mission_links_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_links
    ADD CONSTRAINT development_mission_links_pkey PRIMARY KEY (id);


--
-- Name: development_mission_sources development_mission_sources_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_sources
    ADD CONSTRAINT development_mission_sources_pkey PRIMARY KEY (id);


--
-- Name: development_missions development_missions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_missions
    ADD CONSTRAINT development_missions_pkey PRIMARY KEY (id);


--
-- Name: development_mr_claims development_mr_claims_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mr_claims
    ADD CONSTRAINT development_mr_claims_pkey PRIMARY KEY (id);


--
-- Name: development_repository_upload_plan_entries development_repository_upload_plan_entries_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_plan_entries
    ADD CONSTRAINT development_repository_upload_plan_entries_pkey PRIMARY KEY (plan_id, ordinal);


--
-- Name: development_repository_upload_plans development_repository_upload_plans_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_plans
    ADD CONSTRAINT development_repository_upload_plans_pkey PRIMARY KEY (id);


--
-- Name: development_repository_upload_receipts development_repository_upload_receipts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_receipts
    ADD CONSTRAINT development_repository_upload_receipts_pkey PRIMARY KEY (id);


--
-- Name: development_step_joins development_step_joins_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_step_joins
    ADD CONSTRAINT development_step_joins_pkey PRIMARY KEY (mission_id, group_id, member_step_id);


--
-- Name: development_step_runs development_step_runs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_step_runs
    ADD CONSTRAINT development_step_runs_pkey PRIMARY KEY (id);


--
-- Name: development_wake_hints development_wake_hints_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_wake_hints
    ADD CONSTRAINT development_wake_hints_pkey PRIMARY KEY (id);


--
-- Name: digital_employee_revisions digital_employee_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.digital_employee_revisions
    ADD CONSTRAINT digital_employee_revisions_pkey PRIMARY KEY (employee_id, revision);


--
-- Name: digital_employees digital_employees_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.digital_employees
    ADD CONSTRAINT digital_employees_pkey PRIMARY KEY (id);


--
-- Name: doc_versions doc_versions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.doc_versions
    ADD CONSTRAINT doc_versions_pkey PRIMARY KEY (id);


--
-- Name: employee_approval_sagas employee_approval_sagas_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_approval_sagas
    ADD CONSTRAINT employee_approval_sagas_pkey PRIMARY KEY (id);


--
-- Name: employee_attention_bindings employee_attention_bindings_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_attention_bindings
    ADD CONSTRAINT employee_attention_bindings_pkey PRIMARY KEY (id);


--
-- Name: employee_case_event_origins employee_case_event_origins_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_event_origins
    ADD CONSTRAINT employee_case_event_origins_pkey PRIMARY KEY (case_id);


--
-- Name: employee_case_inbox employee_case_inbox_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_inbox
    ADD CONSTRAINT employee_case_inbox_pkey PRIMARY KEY (id);


--
-- Name: employee_case_members employee_case_members_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_members
    ADD CONSTRAINT employee_case_members_pkey PRIMARY KEY (case_id, user_id);


--
-- Name: employee_case_metering_receipts employee_case_metering_receipts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_metering_receipts
    ADD CONSTRAINT employee_case_metering_receipts_pkey PRIMARY KEY (source_ref);


--
-- Name: employee_case_workspaces employee_case_workspaces_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_workspaces
    ADD CONSTRAINT employee_case_workspaces_pkey PRIMARY KEY (case_id);


--
-- Name: employee_cases employee_cases_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_cases
    ADD CONSTRAINT employee_cases_pkey PRIMARY KEY (id);


--
-- Name: employee_change_candidates employee_change_candidates_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_change_candidates
    ADD CONSTRAINT employee_change_candidates_pkey PRIMARY KEY (candidate_ref);


--
-- Name: employee_channel_results employee_channel_results_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channel_results
    ADD CONSTRAINT employee_channel_results_pkey PRIMARY KEY (id);


--
-- Name: employee_channels employee_channels_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channels
    ADD CONSTRAINT employee_channels_pkey PRIMARY KEY (id);


--
-- Name: employee_context_links employee_context_links_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_links
    ADD CONSTRAINT employee_context_links_pkey PRIMARY KEY (id);


--
-- Name: employee_context_records employee_context_records_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_records
    ADD CONSTRAINT employee_context_records_pkey PRIMARY KEY (id);


--
-- Name: employee_context_revisions employee_context_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_revisions
    ADD CONSTRAINT employee_context_revisions_pkey PRIMARY KEY (context_id, revision);


--
-- Name: employee_definition_revisions employee_definition_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_definition_revisions
    ADD CONSTRAINT employee_definition_revisions_pkey PRIMARY KEY (employee_id, revision);


--
-- Name: employee_definitions employee_definitions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_definitions
    ADD CONSTRAINT employee_definitions_pkey PRIMARY KEY (id);


--
-- Name: employee_execution_policy_revisions employee_execution_policy_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_execution_policy_revisions
    ADD CONSTRAINT employee_execution_policy_revisions_pkey PRIMARY KEY (revision);


--
-- Name: employee_external_context_bindings employee_external_context_bindings_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_external_context_bindings
    ADD CONSTRAINT employee_external_context_bindings_pkey PRIMARY KEY (subject_type, subject_ref);


--
-- Name: employee_input_uploads employee_input_uploads_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_input_uploads
    ADD CONSTRAINT employee_input_uploads_pkey PRIMARY KEY (id);


--
-- Name: employee_invocations employee_invocations_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_invocations
    ADD CONSTRAINT employee_invocations_pkey PRIMARY KEY (id);


--
-- Name: employee_job_template_revisions employee_job_template_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_job_template_revisions
    ADD CONSTRAINT employee_job_template_revisions_pkey PRIMARY KEY (template_id, revision);


--
-- Name: employee_job_templates employee_job_templates_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_job_templates
    ADD CONSTRAINT employee_job_templates_pkey PRIMARY KEY (id);


--
-- Name: employee_os_outbox employee_os_outbox_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_os_outbox
    ADD CONSTRAINT employee_os_outbox_pkey PRIMARY KEY (id);


--
-- Name: employee_os_settings employee_os_settings_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_os_settings
    ADD CONSTRAINT employee_os_settings_pkey PRIMARY KEY (singleton_key);


--
-- Name: employee_os_writer_state employee_os_writer_state_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_os_writer_state
    ADD CONSTRAINT employee_os_writer_state_pkey PRIMARY KEY (id);


--
-- Name: employee_reaction_rounds employee_reaction_rounds_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_reaction_rounds
    ADD CONSTRAINT employee_reaction_rounds_pkey PRIMARY KEY (id);


--
-- Name: employee_round_workspace_states employee_round_workspace_states_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_round_workspace_states
    ADD CONSTRAINT employee_round_workspace_states_pkey PRIMARY KEY (round_id, attempt_ordinal);


--
-- Name: employee_tool_registration_revisions employee_tool_registration_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_tool_registration_revisions
    ADD CONSTRAINT employee_tool_registration_revisions_pkey PRIMARY KEY (tool_id, revision);


--
-- Name: employee_tool_registrations employee_tool_registrations_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_tool_registrations
    ADD CONSTRAINT employee_tool_registrations_pkey PRIMARY KEY (id);


--
-- Name: employee_type_packages employee_type_packages_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_type_packages
    ADD CONSTRAINT employee_type_packages_pkey PRIMARY KEY (type_id, revision);


--
-- Name: employee_work_scope_revisions employee_work_scope_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_work_scope_revisions
    ADD CONSTRAINT employee_work_scope_revisions_pkey PRIMARY KEY (scope_id, revision);


--
-- Name: event_deliveries event_deliveries_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_deliveries
    ADD CONSTRAINT event_deliveries_pkey PRIMARY KEY (id);


--
-- Name: event_observer_runs event_observer_runs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_observer_runs
    ADD CONSTRAINT event_observer_runs_pkey PRIMARY KEY (id);


--
-- Name: event_records event_records_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_records
    ADD CONSTRAINT event_records_pkey PRIMARY KEY (id);


--
-- Name: event_response_rules event_response_rules_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_response_rules
    ADD CONSTRAINT event_response_rules_pkey PRIMARY KEY (id);


--
-- Name: event_sources event_sources_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_sources
    ADD CONSTRAINT event_sources_pkey PRIMARY KEY (source_id, revision);


--
-- Name: event_subscriptions event_subscriptions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_subscriptions
    ADD CONSTRAINT event_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: event_type_catalog event_type_catalog_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_type_catalog
    ADD CONSTRAINT event_type_catalog_pkey PRIMARY KEY (event_type_id, revision);


--
-- Name: fusions fusions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.fusions
    ADD CONSTRAINT fusions_pkey PRIMARY KEY (id);


--
-- Name: intent_apply_journal intent_apply_journal_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_apply_journal
    ADD CONSTRAINT intent_apply_journal_pkey PRIMARY KEY (id);


--
-- Name: intent_draft_resolutions intent_draft_resolutions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_draft_resolutions
    ADD CONSTRAINT intent_draft_resolutions_pkey PRIMARY KEY (draft_id);


--
-- Name: intent_drafts intent_drafts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_drafts
    ADD CONSTRAINT intent_drafts_pkey PRIMARY KEY (id);


--
-- Name: intent_provenance intent_provenance_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_provenance
    ADD CONSTRAINT intent_provenance_pkey PRIMARY KEY (resource_type, resource_id, commit_id);


--
-- Name: intent_sessions intent_sessions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_sessions
    ADD CONSTRAINT intent_sessions_pkey PRIMARY KEY (id);


--
-- Name: intent_turn_events intent_turn_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_turn_events
    ADD CONSTRAINT intent_turn_events_pkey PRIMARY KEY (id);


--
-- Name: intent_turns intent_turns_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_turns
    ADD CONSTRAINT intent_turns_pkey PRIMARY KEY (id);


--
-- Name: intent_working_set_changes intent_working_set_changes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_working_set_changes
    ADD CONSTRAINT intent_working_set_changes_pkey PRIMARY KEY (id);


--
-- Name: legacy_code_work_item_links legacy_code_work_item_links_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.legacy_code_work_item_links
    ADD CONSTRAINT legacy_code_work_item_links_pkey PRIMARY KEY (id);


--
-- Name: lifecycle_alerts lifecycle_alerts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.lifecycle_alerts
    ADD CONSTRAINT lifecycle_alerts_pkey PRIMARY KEY (id);


--
-- Name: lifecycle_repair_audit lifecycle_repair_audit_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.lifecycle_repair_audit
    ADD CONSTRAINT lifecycle_repair_audit_pkey PRIMARY KEY (id);


--
-- Name: maintenance_runs maintenance_runs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.maintenance_runs
    ADD CONSTRAINT maintenance_runs_pkey PRIMARY KEY (id);


--
-- Name: maintenance_state maintenance_state_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.maintenance_state
    ADD CONSTRAINT maintenance_state_pkey PRIMARY KEY (key);


--
-- Name: mcp_probes mcp_probes_mcp_id_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_probes
    ADD CONSTRAINT mcp_probes_mcp_id_unique UNIQUE (mcp_id);


--
-- Name: mcp_probes mcp_probes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_probes
    ADD CONSTRAINT mcp_probes_pkey PRIMARY KEY (id);


--
-- Name: mcp_runtime_test_create_receipts mcp_runtime_test_create_receipts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_create_receipts
    ADD CONSTRAINT mcp_runtime_test_create_receipts_pkey PRIMARY KEY (mcp_id, owner_user_id, client_create_id);


--
-- Name: mcp_runtime_test_events mcp_runtime_test_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_events
    ADD CONSTRAINT mcp_runtime_test_events_pkey PRIMARY KEY (id);


--
-- Name: mcp_runtime_test_session_leases mcp_runtime_test_session_leases_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_session_leases
    ADD CONSTRAINT mcp_runtime_test_session_leases_pkey PRIMARY KEY (protocol, runtime_session_id);


--
-- Name: mcp_runtime_test_sessions mcp_runtime_test_sessions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_sessions
    ADD CONSTRAINT mcp_runtime_test_sessions_pkey PRIMARY KEY (id);


--
-- Name: mcp_runtime_test_turns mcp_runtime_test_turns_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_turns
    ADD CONSTRAINT mcp_runtime_test_turns_pkey PRIMARY KEY (id);


--
-- Name: mcps mcps_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcps
    ADD CONSTRAINT mcps_pkey PRIMARY KEY (id);


--
-- Name: memories memories_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.memories
    ADD CONSTRAINT memories_pkey PRIMARY KEY (id);


--
-- Name: memory_distill_events memory_distill_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.memory_distill_events
    ADD CONSTRAINT memory_distill_events_pkey PRIMARY KEY (id);


--
-- Name: memory_distill_jobs memory_distill_jobs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.memory_distill_jobs
    ADD CONSTRAINT memory_distill_jobs_pkey PRIMARY KEY (id);


--
-- Name: memory_scope_move_events memory_scope_move_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.memory_scope_move_events
    ADD CONSTRAINT memory_scope_move_events_pkey PRIMARY KEY (id);


--
-- Name: mission_input_uploads mission_input_uploads_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mission_input_uploads
    ADD CONSTRAINT mission_input_uploads_pkey PRIMARY KEY (id);


--
-- Name: node_run_events node_run_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_run_events
    ADD CONSTRAINT node_run_events_pkey PRIMARY KEY (id);


--
-- Name: node_run_outputs node_run_outputs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_run_outputs
    ADD CONSTRAINT node_run_outputs_pkey PRIMARY KEY (node_run_id, port_name);


--
-- Name: node_runs node_runs_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_runs
    ADD CONSTRAINT node_runs_pkey PRIMARY KEY (id);


--
-- Name: observer_activations observer_activations_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.observer_activations
    ADD CONSTRAINT observer_activations_pkey PRIMARY KEY (source_id, source_revision);


--
-- Name: oidc_providers oidc_providers_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.oidc_providers
    ADD CONSTRAINT oidc_providers_pkey PRIMARY KEY (id);


--
-- Name: oidc_providers oidc_providers_slug_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.oidc_providers
    ADD CONSTRAINT oidc_providers_slug_unique UNIQUE (slug);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: recovery_events recovery_events_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.recovery_events
    ADD CONSTRAINT recovery_events_pkey PRIMARY KEY (id);


--
-- Name: repo_capability_config repo_capability_config_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repo_capability_config
    ADD CONSTRAINT repo_capability_config_pkey PRIMARY KEY (id);


--
-- Name: repo_group_nodes repo_group_nodes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repo_group_nodes
    ADD CONSTRAINT repo_group_nodes_pkey PRIMARY KEY (group_id, path);


--
-- Name: repo_groups repo_groups_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repo_groups
    ADD CONSTRAINT repo_groups_pkey PRIMARY KEY (id);


--
-- Name: repository_employee_assignments repository_employee_assignments_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repository_employee_assignments
    ADD CONSTRAINT repository_employee_assignments_pkey PRIMARY KEY (id);


--
-- Name: repository_transport_connections repository_transport_connections_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repository_transport_connections
    ADD CONSTRAINT repository_transport_connections_pkey PRIMARY KEY (provider);


--
-- Name: resource_bundle_applies resource_bundle_applies_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.resource_bundle_applies
    ADD CONSTRAINT resource_bundle_applies_pkey PRIMARY KEY (id);


--
-- Name: resource_grants resource_grants_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.resource_grants
    ADD CONSTRAINT resource_grants_pkey PRIMARY KEY (resource_type, resource_id, user_id);


--
-- Name: review_comments review_comments_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_comments
    ADD CONSTRAINT review_comments_pkey PRIMARY KEY (id);


--
-- Name: review_node_reviewers review_node_reviewers_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_node_reviewers
    ADD CONSTRAINT review_node_reviewers_pkey PRIMARY KEY (task_id, review_node_id, reviewer_user_id);


--
-- Name: runtime_session_leases runtime_session_leases_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.runtime_session_leases
    ADD CONSTRAINT runtime_session_leases_pkey PRIMARY KEY (protocol, session_id);


--
-- Name: runtimes runtimes_name_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.runtimes
    ADD CONSTRAINT runtimes_name_unique UNIQUE (name);


--
-- Name: runtimes runtimes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.runtimes
    ADD CONSTRAINT runtimes_pkey PRIMARY KEY (id);


--
-- Name: scheduled_tasks scheduled_tasks_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.scheduled_tasks
    ADD CONSTRAINT scheduled_tasks_pkey PRIMARY KEY (id);


--
-- Name: skill_operation_locks skill_operation_locks_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.skill_operation_locks
    ADD CONSTRAINT skill_operation_locks_pkey PRIMARY KEY (locked_skill_id);


--
-- Name: skill_operations skill_operations_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.skill_operations
    ADD CONSTRAINT skill_operations_pkey PRIMARY KEY (op_id);


--
-- Name: skill_versions skill_versions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.skill_versions
    ADD CONSTRAINT skill_versions_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: task_archive_audit task_archive_audit_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_archive_audit
    ADD CONSTRAINT task_archive_audit_pkey PRIMARY KEY (id);


--
-- Name: task_collaborators task_collaborators_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_collaborators
    ADD CONSTRAINT task_collaborators_pkey PRIMARY KEY (task_id, user_id, role);


--
-- Name: task_execution_effect_attempts task_execution_effect_attempts_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effect_attempts
    ADD CONSTRAINT task_execution_effect_attempts_pkey PRIMARY KEY (id);


--
-- Name: task_execution_effect_fences task_execution_effect_fences_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effect_fences
    ADD CONSTRAINT task_execution_effect_fences_pkey PRIMARY KEY (effect_attempt_id, fence_key);


--
-- Name: task_execution_effects task_execution_effects_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effects
    ADD CONSTRAINT task_execution_effects_pkey PRIMARY KEY (id);


--
-- Name: task_execution_intents task_execution_intents_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_intents
    ADD CONSTRAINT task_execution_intents_pkey PRIMARY KEY (id);


--
-- Name: task_execution_lineage_operation_records task_execution_lineage_operation_records_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_lineage_operation_records
    ADD CONSTRAINT task_execution_lineage_operation_records_pkey PRIMARY KEY (id);


--
-- Name: task_execution_maintenance_claims task_execution_maintenance_claims_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_maintenance_claims
    ADD CONSTRAINT task_execution_maintenance_claims_pkey PRIMARY KEY (id);


--
-- Name: task_execution_maintenance_members task_execution_maintenance_members_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_maintenance_members
    ADD CONSTRAINT task_execution_maintenance_members_pkey PRIMARY KEY (claim_id, task_id);


--
-- Name: task_execution_owners task_execution_owners_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_owners
    ADD CONSTRAINT task_execution_owners_pkey PRIMARY KEY (task_id);


--
-- Name: task_feedback task_feedback_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_feedback
    ADD CONSTRAINT task_feedback_pkey PRIMARY KEY (id);


--
-- Name: task_node_clarify_directives task_node_clarify_directives_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_node_clarify_directives
    ADD CONSTRAINT task_node_clarify_directives_pkey PRIMARY KEY (task_id, node_id, shard_key);


--
-- Name: task_questions task_questions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_questions
    ADD CONSTRAINT task_questions_pkey PRIMARY KEY (id);


--
-- Name: task_repos task_repos_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_repos
    ADD CONSTRAINT task_repos_pkey PRIMARY KEY (task_id, repo_index);


--
-- Name: task_space_nodes task_space_nodes_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_space_nodes
    ADD CONSTRAINT task_space_nodes_pkey PRIMARY KEY (task_id, node_path);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: token_audit token_audit_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.token_audit
    ADD CONSTRAINT token_audit_pkey PRIMARY KEY (id);


--
-- Name: token_delete_snapshot token_delete_snapshot_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.token_delete_snapshot
    ADD CONSTRAINT token_delete_snapshot_pkey PRIMARY KEY (id);


--
-- Name: user_access_audit user_access_audit_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_access_audit
    ADD CONSTRAINT user_access_audit_pkey PRIMARY KEY (id);


--
-- Name: user_identities user_identities_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_identities
    ADD CONSTRAINT user_identities_pkey PRIMARY KEY (id);


--
-- Name: user_pats user_pats_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_pats
    ADD CONSTRAINT user_pats_pkey PRIMARY KEY (id);


--
-- Name: user_pats user_pats_token_hash_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_pats
    ADD CONSTRAINT user_pats_token_hash_unique UNIQUE (token_hash);


--
-- Name: user_permission_grants user_permission_grants_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_permission_grants
    ADD CONSTRAINT user_permission_grants_pkey PRIMARY KEY (user_id, permission);


--
-- Name: user_repository_transport_credentials user_repository_transport_credentials_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_repository_transport_credentials
    ADD CONSTRAINT user_repository_transport_credentials_pkey PRIMARY KEY (user_id, provider);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_token_hash_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_sessions
    ADD CONSTRAINT user_sessions_token_hash_unique UNIQUE (token_hash);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: verification_profile_revisions verification_profile_revisions_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.verification_profile_revisions
    ADD CONSTRAINT verification_profile_revisions_pkey PRIMARY KEY (profile_id, revision);


--
-- Name: verification_profiles verification_profiles_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.verification_profiles
    ADD CONSTRAINT verification_profiles_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: webhook_mr_control_effects webhook_mr_control_effects_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_mr_control_effects
    ADD CONSTRAINT webhook_mr_control_effects_pkey PRIMARY KEY (id);


--
-- Name: webhook_mr_control_targets webhook_mr_control_targets_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_mr_control_targets
    ADD CONSTRAINT webhook_mr_control_targets_pkey PRIMARY KEY (effect_id, task_id);


--
-- Name: webhook_mr_launch_guards webhook_mr_launch_guards_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_mr_launch_guards
    ADD CONSTRAINT webhook_mr_launch_guards_pkey PRIMARY KEY (id);


--
-- Name: webhook_mr_stream_states webhook_mr_stream_states_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_mr_stream_states
    ADD CONSTRAINT webhook_mr_stream_states_pkey PRIMARY KEY (endpoint_id, stream_key);


--
-- Name: webhook_trigger_fires webhook_trigger_fires_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_trigger_fires
    ADD CONSTRAINT webhook_trigger_fires_pkey PRIMARY KEY (id);


--
-- Name: webhook_trigger_streams webhook_trigger_streams_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_trigger_streams
    ADD CONSTRAINT webhook_trigger_streams_pkey PRIMARY KEY (trigger_id, stream_key);


--
-- Name: webhook_triggers webhook_triggers_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_triggers
    ADD CONSTRAINT webhook_triggers_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: workgroup_assignments workgroup_assignments_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_assignments
    ADD CONSTRAINT workgroup_assignments_pkey PRIMARY KEY (id);


--
-- Name: workgroup_member_cursors workgroup_member_cursors_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_member_cursors
    ADD CONSTRAINT workgroup_member_cursors_pkey PRIMARY KEY (task_id, member_id);


--
-- Name: workgroup_members workgroup_members_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_members
    ADD CONSTRAINT workgroup_members_pkey PRIMARY KEY (id);


--
-- Name: workgroup_messages workgroup_messages_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_messages
    ADD CONSTRAINT workgroup_messages_pkey PRIMARY KEY (id);


--
-- Name: workgroup_task_state workgroup_task_state_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_task_state
    ADD CONSTRAINT workgroup_task_state_pkey PRIMARY KEY (task_id);


--
-- Name: workgroups workgroups_pkey; Type: CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroups
    ADD CONSTRAINT workgroups_pkey PRIMARY KEY (id);


--
-- Name: database_generations database_generations_pkey; Type: CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.database_generations
    ADD CONSTRAINT database_generations_pkey PRIMARY KEY (generation_id);


--
-- Name: logical_copy_chunks logical_copy_chunks_pkey; Type: CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.logical_copy_chunks
    ADD CONSTRAINT logical_copy_chunks_pkey PRIMARY KEY (operation_id, table_id, chunk_index);


--
-- Name: logical_copy_operations logical_copy_operations_pkey; Type: CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.logical_copy_operations
    ADD CONSTRAINT logical_copy_operations_pkey PRIMARY KEY (operation_id);


--
-- Name: schema_contract schema_contract_pkey; Type: CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.schema_contract
    ADD CONSTRAINT schema_contract_pkey PRIMARY KEY (singleton);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (baseline_id);


--
-- Name: action_templates_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX action_templates_owner_name_unique ON agent_workflow.action_templates USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: agents_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX agents_owner_name_unique ON agent_workflow.agents USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: automation_policies_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX automation_policies_owner_name_unique ON agent_workflow.automation_policies USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: capability_templates_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX capability_templates_owner_name_unique ON agent_workflow.capability_templates USING btree (owner_user_id, name);


--
-- Name: committed_events_aggregate_seq_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX committed_events_aggregate_seq_unique ON agent_workflow.committed_events USING btree (producer, family, aggregate_kind, aggregate_id, aggregate_seq);


--
-- Name: committed_events_group_ordinal_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX committed_events_group_ordinal_unique ON agent_workflow.committed_events USING btree (event_group_id, event_group_ordinal);


--
-- Name: dev_action_runs_decision_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_action_runs_decision_unique ON agent_workflow.development_action_runs USING btree (decision_id);


--
-- Name: dev_action_runs_single_writable; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_action_runs_single_writable ON agent_workflow.development_action_runs USING btree (mission_id) WHERE ((writable = 1) AND (status = ANY (ARRAY['claimed'::text, 'materializing'::text, 'running'::text, 'validating'::text, 'awaiting-effect'::text])));


--
-- Name: dev_agent_attempts_ordinal_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_agent_attempts_ordinal_unique ON agent_workflow.development_agent_attempts USING btree (action_run_id, rerun_seq, attempt_seq);


--
-- Name: dev_approval_sagas_idem_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_approval_sagas_idem_unique ON agent_workflow.development_approval_sagas USING btree (idempotency_key);


--
-- Name: dev_decisions_input_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_decisions_input_unique ON agent_workflow.development_decisions USING btree (mission_id, decision_input_digest);


--
-- Name: dev_deferred_wakes_decision_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_deferred_wakes_decision_unique ON agent_workflow.development_deferred_wakes USING btree (mission_id, decision_id);


--
-- Name: dev_effects_idempotency_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_effects_idempotency_unique ON agent_workflow.development_effects USING btree (idempotency_key);


--
-- Name: dev_feedback_ledger_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_feedback_ledger_unique ON agent_workflow.development_feedback_ledger USING btree (mission_id, thread_ref, revision, head_sha);


--
-- Name: dev_mission_links_child_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_mission_links_child_unique ON agent_workflow.development_mission_links USING btree (child_mission_id);


--
-- Name: dev_mission_links_idem_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_mission_links_idem_unique ON agent_workflow.development_mission_links USING btree (idempotency_key);


--
-- Name: dev_mr_claims_active_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_mr_claims_active_unique ON agent_workflow.development_mr_claims USING btree (code_host_endpoint_ref, stable_project_ref, mr_iid) WHERE (state = 'active'::text);


--
-- Name: dev_step_runs_replay_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_step_runs_replay_unique ON agent_workflow.development_step_runs USING btree (mission_id, employee_id, employee_revision, step_id, attempt, input_digest);


--
-- Name: dev_upload_plan_target_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_upload_plan_target_unique ON agent_workflow.development_repository_upload_plan_entries USING btree (plan_id, repository_target_path);


--
-- Name: dev_upload_receipts_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_upload_receipts_unique ON agent_workflow.development_repository_upload_receipts USING btree (plan_id, baseline_snapshot_ref, receipt_kind);


--
-- Name: dev_wake_hints_delivery_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX dev_wake_hints_delivery_unique ON agent_workflow.development_wake_hints USING btree (mission_id, delivery_key);


--
-- Name: development_adapter_definitions_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX development_adapter_definitions_owner_name_unique ON agent_workflow.development_adapter_definitions USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: development_missions_launch_idem_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX development_missions_launch_idem_unique ON agent_workflow.development_missions USING btree (launch_idempotency_key) WHERE (launch_idempotency_key IS NOT NULL);


--
-- Name: digital_employees_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX digital_employees_owner_name_unique ON agent_workflow.digital_employees USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: employee_approval_sagas_correlation_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_approval_sagas_correlation_unique ON agent_workflow.employee_approval_sagas USING btree (adapter_id, adapter_revision, correlation_ref) WHERE (correlation_ref IS NOT NULL);


--
-- Name: employee_approval_sagas_idempotency_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_approval_sagas_idempotency_unique ON agent_workflow.employee_approval_sagas USING btree (idempotency_key);


--
-- Name: employee_attention_desired_identity_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_attention_desired_identity_unique ON agent_workflow.employee_attention_bindings USING btree (desired_identity_key);


--
-- Name: employee_case_event_origins_delivery_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_case_event_origins_delivery_unique ON agent_workflow.employee_case_event_origins USING btree (event_delivery_id);


--
-- Name: employee_case_inbox_delivery_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_case_inbox_delivery_unique ON agent_workflow.employee_case_inbox USING btree (delivery_id);


--
-- Name: employee_change_candidates_round_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_change_candidates_round_unique ON agent_workflow.employee_change_candidates USING btree (round_id);


--
-- Name: employee_channel_results_identity_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_channel_results_identity_unique ON agent_workflow.employee_channel_results USING btree (channel_id, milestone_type, envelope_digest);


--
-- Name: employee_channels_invocation_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_channels_invocation_unique ON agent_workflow.employee_channels USING btree (invocation_id);


--
-- Name: employee_context_links_identity_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_context_links_identity_unique ON agent_workflow.employee_context_links USING btree (case_id, from_context_id, relation, to_context_id);


--
-- Name: employee_definitions_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_definitions_owner_name_unique ON agent_workflow.employee_definitions USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: employee_input_uploads_actor_idempotency_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_input_uploads_actor_idempotency_unique ON agent_workflow.employee_input_uploads USING btree (COALESCE(actor_user_id, ''::text), upload_idempotency_key) WHERE (upload_idempotency_key IS NOT NULL);


--
-- Name: employee_invocations_idempotency_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_invocations_idempotency_unique ON agent_workflow.employee_invocations USING btree (idempotency_key);


--
-- Name: employee_job_templates_owner_type_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_job_templates_owner_type_name_unique ON agent_workflow.employee_job_templates USING btree (COALESCE(owner_user_id, ''::text), type_id, type_revision, name);


--
-- Name: employee_os_outbox_dedupe_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_os_outbox_dedupe_unique ON agent_workflow.employee_os_outbox USING btree (dedupe_key);


--
-- Name: employee_reaction_rounds_inbox_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_reaction_rounds_inbox_unique ON agent_workflow.employee_reaction_rounds USING btree (inbox_id);


--
-- Name: employee_reaction_rounds_one_active; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX employee_reaction_rounds_one_active ON agent_workflow.employee_reaction_rounds USING btree (case_id) WHERE (state = ANY (ARRAY['planned'::text, 'running'::text, 'settling'::text]));


--
-- Name: event_deliveries_event_subscription_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX event_deliveries_event_subscription_unique ON agent_workflow.event_deliveries USING btree (event_id, subscription_id);


--
-- Name: event_records_source_dedupe_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX event_records_source_dedupe_unique ON agent_workflow.event_records USING btree (source_id, source_revision, dedupe_key);


--
-- Name: event_subscriptions_active_identity_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX event_subscriptions_active_identity_unique ON agent_workflow.event_subscriptions USING btree (active_identity_key) WHERE (active_identity_key IS NOT NULL);


--
-- Name: idx_cached_repos_fetched_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_cached_repos_fetched_id ON agent_workflow.cached_repos USING btree (last_fetched_at, id);


--
-- Name: idx_cached_repos_submodule_health; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_cached_repos_submodule_health ON agent_workflow.cached_repos USING btree (has_submodules, last_submodule_sync_ok);


--
-- Name: idx_capability_templates_capability; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_capability_templates_capability ON agent_workflow.capability_templates USING btree (capability);


--
-- Name: idx_capability_templates_upstream; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_capability_templates_upstream ON agent_workflow.capability_templates USING btree (upstream_id);


--
-- Name: idx_clarify_rounds_asking; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_clarify_rounds_asking ON agent_workflow.clarify_rounds USING btree (asking_node_id, container_run_id, loop_iter, iteration);


--
-- Name: idx_clarify_rounds_intermediary; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_clarify_rounds_intermediary ON agent_workflow.clarify_rounds USING btree (intermediary_node_id, loop_iter, iteration);


--
-- Name: idx_clarify_rounds_kind_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_clarify_rounds_kind_status ON agent_workflow.clarify_rounds USING btree (kind, status);


--
-- Name: idx_clarify_rounds_target_consumer; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_clarify_rounds_target_consumer ON agent_workflow.clarify_rounds USING btree (target_consumer_node_id, status);


--
-- Name: idx_clarify_rounds_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_clarify_rounds_task ON agent_workflow.clarify_rounds USING btree (task_id);


--
-- Name: idx_code_ai_attempts_round; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_ai_attempts_round ON agent_workflow.code_ai_attempts USING btree (round_id);


--
-- Name: idx_code_ai_attempts_started; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_ai_attempts_started ON agent_workflow.code_ai_attempts USING btree (started_at);


--
-- Name: idx_code_ai_attempts_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_ai_attempts_status ON agent_workflow.code_ai_attempts USING btree (status);


--
-- Name: idx_code_findings_anchor; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_findings_anchor ON agent_workflow.code_findings USING btree (code_host_endpoint_id, stable_project_id, anchor_kind, anchor_id, lifecycle);


--
-- Name: idx_code_findings_external_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_findings_external_created ON agent_workflow.code_findings USING btree (created_at) WHERE (external_id IS NOT NULL);


--
-- Name: idx_code_findings_seen; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_findings_seen ON agent_workflow.code_findings USING btree (stable_project_id, last_seen_at);


--
-- Name: idx_code_round_stages_round; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_round_stages_round ON agent_workflow.code_round_stages USING btree (round_id);


--
-- Name: idx_code_trigger_deliveries_correlation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_trigger_deliveries_correlation ON agent_workflow.code_trigger_deliveries USING btree (correlation_id);


--
-- Name: idx_code_trigger_deliveries_outcome; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_trigger_deliveries_outcome ON agent_workflow.code_trigger_deliveries USING btree (outcome, created_at);


--
-- Name: idx_code_trigger_deliveries_project; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_trigger_deliveries_project ON agent_workflow.code_trigger_deliveries USING btree (stable_project_id, created_at);


--
-- Name: idx_code_work_items_anchor; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_items_anchor ON agent_workflow.code_work_items USING btree (code_host_endpoint_id, stable_project_id, anchor_kind, anchor_id);


--
-- Name: idx_code_work_items_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_items_created ON agent_workflow.code_work_items USING btree (created_at);


--
-- Name: idx_code_work_items_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_items_status ON agent_workflow.code_work_items USING btree (status);


--
-- Name: idx_code_work_rounds_item; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_rounds_item ON agent_workflow.code_work_rounds USING btree (work_item_id);


--
-- Name: idx_code_work_rounds_started; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_rounds_started ON agent_workflow.code_work_rounds USING btree (started_at);


--
-- Name: idx_code_work_rounds_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_code_work_rounds_task ON agent_workflow.code_work_rounds USING btree (task_id);


--
-- Name: idx_collaboration_gate_artifacts_final_path; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_collaboration_gate_artifacts_final_path ON agent_workflow.collaboration_gate_artifacts USING btree (final_path);


--
-- Name: idx_collaboration_gate_artifacts_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_collaboration_gate_artifacts_state ON agent_workflow.collaboration_gate_artifacts USING btree (state, updated_at);


--
-- Name: idx_collaboration_gate_operations_idempotency; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_collaboration_gate_operations_idempotency ON agent_workflow.collaboration_gate_operations USING btree (task_id, gate_kind, operation_kind, idempotency_key);


--
-- Name: idx_collaboration_gate_operations_one_active; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_collaboration_gate_operations_one_active ON agent_workflow.collaboration_gate_operations USING btree (task_id, gate_kind, gate_ref, operation_kind) WHERE (state = ANY (ARRAY['preparing'::text, 'prepared'::text, 'committed'::text, 'cleanup_pending'::text]));


--
-- Name: idx_collaboration_gate_operations_recovery; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_collaboration_gate_operations_recovery ON agent_workflow.collaboration_gate_operations USING btree (state, claim_expires_at, updated_at);


--
-- Name: idx_collaboration_gate_operations_revision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_collaboration_gate_operations_revision ON agent_workflow.collaboration_gate_operations USING btree (gate_kind, gate_ref, result_gate_revision) WHERE (result_gate_revision IS NOT NULL);


--
-- Name: idx_collaboration_gate_operations_task_gate; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_collaboration_gate_operations_task_gate ON agent_workflow.collaboration_gate_operations USING btree (task_id, gate_kind, gate_ref, created_at);


--
-- Name: idx_committed_event_deliveries_consumer_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_committed_event_deliveries_consumer_state ON agent_workflow.committed_event_deliveries USING btree (consumer_id, state, updated_at);


--
-- Name: idx_committed_event_deliveries_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_committed_event_deliveries_due ON agent_workflow.committed_event_deliveries USING btree (state, next_attempt_at, claim_expires_at, created_at);


--
-- Name: idx_committed_events_aggregate; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_committed_events_aggregate ON agent_workflow.committed_events USING btree (producer, family, aggregate_kind, aggregate_id, aggregate_seq);


--
-- Name: idx_committed_events_operation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_committed_events_operation ON agent_workflow.committed_events USING btree (producer, family, operation_ref);


--
-- Name: idx_custom_event_source_revisions; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_custom_event_source_revisions ON agent_workflow.custom_event_source_revisions USING btree (source_id, revision);


--
-- Name: idx_custom_event_sources_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_custom_event_sources_state ON agent_workflow.custom_event_source_definitions USING btree (retired_at, updated_at);


--
-- Name: idx_dev_agent_attempts_execution_ref; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_agent_attempts_execution_ref ON agent_workflow.development_agent_attempts USING btree (execution_ref);


--
-- Name: idx_dev_approval_sagas_correlation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_approval_sagas_correlation ON agent_workflow.development_approval_sagas USING btree (correlation_ref);


--
-- Name: idx_dev_approval_sagas_mission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_approval_sagas_mission ON agent_workflow.development_approval_sagas USING btree (mission_id);


--
-- Name: idx_dev_bundle_refs_mission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_bundle_refs_mission ON agent_workflow.development_bundle_refs USING btree (mission_id);


--
-- Name: idx_dev_deferred_wakes_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_deferred_wakes_due ON agent_workflow.development_deferred_wakes USING btree (resume_at) WHERE (state = 'armed'::text);


--
-- Name: idx_dev_effects_mission_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_effects_mission_state ON agent_workflow.development_effects USING btree (mission_id, state);


--
-- Name: idx_dev_effects_prepared; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_effects_prepared ON agent_workflow.development_effects USING btree (created_at) WHERE (state = 'prepared'::text);


--
-- Name: idx_dev_fact_snapshots_mission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_fact_snapshots_mission ON agent_workflow.development_fact_snapshots USING btree (mission_id);


--
-- Name: idx_dev_mission_links_parent; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_mission_links_parent ON agent_workflow.development_mission_links USING btree (parent_mission_id);


--
-- Name: idx_dev_mission_sources_mission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_mission_sources_mission ON agent_workflow.development_mission_sources USING btree (mission_id);


--
-- Name: idx_dev_mr_claims_lookup; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_mr_claims_lookup ON agent_workflow.development_mr_claims USING btree (code_host_endpoint_ref, stable_project_ref, mr_iid);


--
-- Name: idx_dev_step_joins_pending; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_step_joins_pending ON agent_workflow.development_step_joins USING btree (mission_id, settled_result);


--
-- Name: idx_dev_step_runs_action; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_step_runs_action ON agent_workflow.development_step_runs USING btree (action_run_id);


--
-- Name: idx_dev_step_runs_mission_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_step_runs_mission_state ON agent_workflow.development_step_runs USING btree (mission_id, state);


--
-- Name: idx_dev_wake_hints_unconsumed; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_dev_wake_hints_unconsumed ON agent_workflow.development_wake_hints USING btree (mission_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_development_missions_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_created ON agent_workflow.development_missions USING btree (created_at);


--
-- Name: idx_development_missions_created_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_created_id ON agent_workflow.development_missions USING btree (created_at, id);


--
-- Name: idx_development_missions_fenced; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_fenced ON agent_workflow.development_missions USING btree (id) WHERE (transition_fence <> 'none'::text);


--
-- Name: idx_development_missions_open; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_open ON agent_workflow.development_missions USING btree (created_at, id) WHERE (terminal_at IS NULL);


--
-- Name: idx_development_missions_repo; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_repo ON agent_workflow.development_missions USING btree (repository_id);


--
-- Name: idx_development_missions_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_status ON agent_workflow.development_missions USING btree (status);


--
-- Name: idx_development_missions_status_employee; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_development_missions_status_employee ON agent_workflow.development_missions USING btree (status, employee_id);


--
-- Name: idx_distill_events_job_attempt; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_distill_events_job_attempt ON agent_workflow.memory_distill_events USING btree (distill_job_id, attempt_index, ts);


--
-- Name: idx_distill_events_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_distill_events_session ON agent_workflow.memory_distill_events USING btree (distill_job_id, session_id, ts);


--
-- Name: idx_distill_jobs_debounce; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_distill_jobs_debounce ON agent_workflow.memory_distill_jobs USING btree (debounce_key, status);


--
-- Name: idx_distill_jobs_status_next; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_distill_jobs_status_next ON agent_workflow.memory_distill_jobs USING btree (status, next_run_at);


--
-- Name: idx_distill_jobs_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_distill_jobs_task ON agent_workflow.memory_distill_jobs USING btree (task_id, source_kind);


--
-- Name: idx_doc_versions_pending_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_doc_versions_pending_created ON agent_workflow.doc_versions USING btree (created_at) WHERE (decision = 'pending'::text);


--
-- Name: idx_doc_versions_review_item; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_doc_versions_review_item ON agent_workflow.doc_versions USING btree (review_node_run_id, item_index);


--
-- Name: idx_doc_versions_review_run; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_doc_versions_review_run ON agent_workflow.doc_versions USING btree (review_node_run_id, version_index);


--
-- Name: idx_doc_versions_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_doc_versions_task ON agent_workflow.doc_versions USING btree (task_id);


--
-- Name: idx_employee_approval_sagas_case_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_approval_sagas_case_state ON agent_workflow.employee_approval_sagas USING btree (case_id, latest_status, updated_at);


--
-- Name: idx_employee_attention_case_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_attention_case_state ON agent_workflow.employee_attention_bindings USING btree (case_id, state, updated_at);


--
-- Name: idx_employee_case_event_origins_subscription; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_case_event_origins_subscription ON agent_workflow.employee_case_event_origins USING btree (event_subscription_id, created_at);


--
-- Name: idx_employee_case_inbox_queue; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_case_inbox_queue ON agent_workflow.employee_case_inbox USING btree (case_id, state, priority, occurred_at, event_id);


--
-- Name: idx_employee_case_members_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_case_members_user ON agent_workflow.employee_case_members USING btree (user_id, case_id);


--
-- Name: idx_employee_case_metering_case; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_case_metering_case ON agent_workflow.employee_case_metering_receipts USING btree (case_id, created_at);


--
-- Name: idx_employee_case_workspaces_repo_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_case_workspaces_repo_state ON agent_workflow.employee_case_workspaces USING btree (repository_id, state, updated_at);


--
-- Name: idx_employee_cases_employee_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_cases_employee_state ON agent_workflow.employee_cases USING btree (employee_id, employee_revision, state, updated_at);


--
-- Name: idx_employee_cases_owner_origin_updated; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_cases_owner_origin_updated ON agent_workflow.employee_cases USING btree (owner_user_id, launch_origin, updated_at, id);


--
-- Name: idx_employee_cases_state_employee_terminal; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_cases_state_employee_terminal ON agent_workflow.employee_cases USING btree (state, employee_id, terminal_kind);


--
-- Name: idx_employee_change_candidates_case_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_change_candidates_case_state ON agent_workflow.employee_change_candidates USING btree (case_id, state, updated_at);


--
-- Name: idx_employee_context_case_type; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_context_case_type ON agent_workflow.employee_context_records USING btree (case_id, type_id, lifecycle_state);


--
-- Name: idx_employee_definitions_type; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_definitions_type ON agent_workflow.employee_definitions USING btree (type_id, type_revision, archived_at);


--
-- Name: idx_employee_input_uploads_expiry; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_input_uploads_expiry ON agent_workflow.employee_input_uploads USING btree (state, expires_at);


--
-- Name: idx_employee_invocations_parent_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_invocations_parent_state ON agent_workflow.employee_invocations USING btree (parent_case_id, state, deadline_at);


--
-- Name: idx_employee_os_outbox_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_os_outbox_due ON agent_workflow.employee_os_outbox USING btree (state, next_attempt_at, claim_expires_at);


--
-- Name: idx_employee_reaction_rounds_execution; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_reaction_rounds_execution ON agent_workflow.employee_reaction_rounds USING btree (execution_ref, state);


--
-- Name: idx_employee_round_workspace_case; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_round_workspace_case ON agent_workflow.employee_round_workspace_states USING btree (case_id, created_at);


--
-- Name: idx_employee_tool_revisions_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_tool_revisions_state ON agent_workflow.employee_tool_registration_revisions USING btree (state, tool_id, revision);


--
-- Name: idx_employee_tools_node; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_tools_node ON agent_workflow.employee_tool_registrations USING btree (type_id, type_revision, work_item_ref, retired_at);


--
-- Name: idx_employee_type_packages_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_employee_type_packages_state ON agent_workflow.employee_type_packages USING btree (state, type_id, revision);


--
-- Name: idx_event_deliveries_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_deliveries_due ON agent_workflow.event_deliveries USING btree (subscriber_kind, state, next_attempt_at, claim_expires_at);


--
-- Name: idx_event_deliveries_pending; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_deliveries_pending ON agent_workflow.event_deliveries USING btree (subscriber_kind, subscriber_ref, state, next_attempt_at, created_at);


--
-- Name: idx_event_observer_runs_source; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_observer_runs_source ON agent_workflow.event_observer_runs USING btree (source_id, source_revision, started_at);


--
-- Name: idx_event_records_audit; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_records_audit ON agent_workflow.event_records USING btree (observed_at, id);


--
-- Name: idx_event_records_source_audit; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_records_source_audit ON agent_workflow.event_records USING btree (source_id, observed_at, id);


--
-- Name: idx_event_records_subject; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_records_subject ON agent_workflow.event_records USING btree (subject_type, subject_ref, occurred_at);


--
-- Name: idx_event_response_rules_event; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_response_rules_event ON agent_workflow.event_response_rules USING btree (enabled, source_id, source_revision, event_type_id, event_type_revision);


--
-- Name: idx_event_response_rules_owner; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_response_rules_owner ON agent_workflow.event_response_rules USING btree (owner_user_id, updated_at);


--
-- Name: idx_event_subscriptions_audit; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_subscriptions_audit ON agent_workflow.event_subscriptions USING btree (mode, updated_at, id);


--
-- Name: idx_event_subscriptions_fanout; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_subscriptions_fanout ON agent_workflow.event_subscriptions USING btree (event_type_id, event_type_revision, subject_type, subject_ref, state);


--
-- Name: idx_event_subscriptions_mode; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_subscriptions_mode ON agent_workflow.event_subscriptions USING btree (mode, state, updated_at);


--
-- Name: idx_event_subscriptions_subscriber; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_subscriptions_subscriber ON agent_workflow.event_subscriptions USING btree (subscriber_kind, subscriber_ref, state);


--
-- Name: idx_event_type_source; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_event_type_source ON agent_workflow.event_type_catalog USING btree (source_id, source_revision, state);


--
-- Name: idx_events_node; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_events_node ON agent_workflow.node_run_events USING btree (node_run_id, id);


--
-- Name: idx_events_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_events_session ON agent_workflow.node_run_events USING btree (node_run_id, session_id, id);


--
-- Name: idx_fusions_skill; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_fusions_skill ON agent_workflow.fusions USING btree (skill_id);


--
-- Name: idx_fusions_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_fusions_status ON agent_workflow.fusions USING btree (status);


--
-- Name: idx_intent_apply_journal_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_apply_journal_session ON agent_workflow.intent_apply_journal USING btree (session_id);


--
-- Name: idx_intent_apply_journal_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_apply_journal_state ON agent_workflow.intent_apply_journal USING btree (state);


--
-- Name: idx_intent_draft_resolutions_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_draft_resolutions_session ON agent_workflow.intent_draft_resolutions USING btree (session_id, created_at);


--
-- Name: idx_intent_drafts_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_drafts_session ON agent_workflow.intent_drafts USING btree (session_id);


--
-- Name: idx_intent_provenance_resource; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_provenance_resource ON agent_workflow.intent_provenance USING btree (resource_type, resource_id);


--
-- Name: idx_intent_provenance_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_provenance_session ON agent_workflow.intent_provenance USING btree (session_id);


--
-- Name: idx_intent_sessions_owner; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_sessions_owner ON agent_workflow.intent_sessions USING btree (owner_user_id);


--
-- Name: idx_intent_sessions_owner_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_sessions_owner_status ON agent_workflow.intent_sessions USING btree (owner_user_id, status);


--
-- Name: idx_intent_turn_events_turn; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_turn_events_turn ON agent_workflow.intent_turn_events USING btree (turn_id, event_seq);


--
-- Name: idx_intent_turns_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_turns_session ON agent_workflow.intent_turns USING btree (session_id);


--
-- Name: idx_intent_working_set_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_working_set_session ON agent_workflow.intent_working_set_changes USING btree (session_id, created_at);


--
-- Name: idx_intent_working_set_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_intent_working_set_state ON agent_workflow.intent_working_set_changes USING btree (state, updated_at);


--
-- Name: idx_lifecycle_alerts_open; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_lifecycle_alerts_open ON agent_workflow.lifecycle_alerts USING btree (resolved_at, severity);


--
-- Name: idx_lifecycle_alerts_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_lifecycle_alerts_task ON agent_workflow.lifecycle_alerts USING btree (task_id, detected_at);


--
-- Name: idx_lifecycle_repair_audit_rule; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_lifecycle_repair_audit_rule ON agent_workflow.lifecycle_repair_audit USING btree (alert_rule, applied_at);


--
-- Name: idx_lifecycle_repair_audit_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_lifecycle_repair_audit_task ON agent_workflow.lifecycle_repair_audit USING btree (task_id, applied_at);


--
-- Name: idx_maintenance_runs_admission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_maintenance_runs_admission ON agent_workflow.maintenance_runs USING btree (state, job_class, scheduled_at);


--
-- Name: idx_maintenance_runs_job_slot; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_maintenance_runs_job_slot ON agent_workflow.maintenance_runs USING btree (job_key, slot_key);


--
-- Name: idx_maintenance_runs_last; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_maintenance_runs_last ON agent_workflow.maintenance_runs USING btree (finished_at, job_key);


--
-- Name: idx_maintenance_runs_lease; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_maintenance_runs_lease ON agent_workflow.maintenance_runs USING btree (state, lease_expires_at);


--
-- Name: idx_maintenance_runs_one_queued; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_maintenance_runs_one_queued ON agent_workflow.maintenance_runs USING btree (job_key) WHERE (state = ANY (ARRAY['pending'::text, 'deferred'::text]));


--
-- Name: idx_maintenance_runs_one_running; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_maintenance_runs_one_running ON agent_workflow.maintenance_runs USING btree (job_key) WHERE (state = 'running'::text);


--
-- Name: idx_mcp_runtime_test_create_receipts_expiry; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_create_receipts_expiry ON agent_workflow.mcp_runtime_test_create_receipts USING btree (expires_at);


--
-- Name: idx_mcp_runtime_test_events_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_events_session ON agent_workflow.mcp_runtime_test_events USING btree (test_session_id, event_seq);


--
-- Name: idx_mcp_runtime_test_sessions_idle; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_sessions_idle ON agent_workflow.mcp_runtime_test_sessions USING btree (status, idle_deadline_at);


--
-- Name: idx_mcp_runtime_test_sessions_owner_mcp_updated; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_sessions_owner_mcp_updated ON agent_workflow.mcp_runtime_test_sessions USING btree (owner_user_id, mcp_id, updated_at);


--
-- Name: idx_mcp_runtime_test_turns_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_turns_session ON agent_workflow.mcp_runtime_test_turns USING btree (session_id, seq);


--
-- Name: idx_mcp_runtime_test_turns_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mcp_runtime_test_turns_status ON agent_workflow.mcp_runtime_test_turns USING btree (status, hard_deadline_at);


--
-- Name: idx_memories_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_created ON agent_workflow.memories USING btree (created_at);


--
-- Name: idx_memories_fused_skill_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_fused_skill_id ON agent_workflow.memories USING btree (fused_into_skill_id, fused_into_skill_version);


--
-- Name: idx_memories_scope_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_scope_status ON agent_workflow.memories USING btree (scope_type, scope_id, status);


--
-- Name: idx_memories_source; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_source ON agent_workflow.memories USING btree (source_kind, source_event_id);


--
-- Name: idx_memories_status_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_status_created ON agent_workflow.memories USING btree (status, created_at);


--
-- Name: idx_memories_supersedes; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memories_supersedes ON agent_workflow.memories USING btree (supersedes_id);


--
-- Name: idx_memory_scope_move_events_memory_version; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_memory_scope_move_events_memory_version ON agent_workflow.memory_scope_move_events USING btree (memory_id, resulting_version);


--
-- Name: idx_memory_scope_move_events_occurred; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_memory_scope_move_events_occurred ON agent_workflow.memory_scope_move_events USING btree (occurred_at, memory_id);


--
-- Name: idx_mission_input_uploads_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_mission_input_uploads_state ON agent_workflow.mission_input_uploads USING btree (state, expires_at);


--
-- Name: idx_node_runs_child_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_node_runs_child_task ON agent_workflow.node_runs USING btree (child_task_id);


--
-- Name: idx_node_runs_container; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_node_runs_container ON agent_workflow.node_runs USING btree (task_id, container_run_id, node_id, iteration);


--
-- Name: idx_node_runs_parent; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_node_runs_parent ON agent_workflow.node_runs USING btree (parent_node_run_id);


--
-- Name: idx_node_runs_status_active; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_node_runs_status_active ON agent_workflow.node_runs USING btree (status, started_at);


--
-- Name: idx_node_runs_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_node_runs_task ON agent_workflow.node_runs USING btree (task_id, node_id, iteration, retry_index);


--
-- Name: idx_observer_activations_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_observer_activations_due ON agent_workflow.observer_activations USING btree (state, next_scan_at, lease_expires_at);


--
-- Name: idx_oidc_providers_enabled; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_oidc_providers_enabled ON agent_workflow.oidc_providers USING btree (enabled);


--
-- Name: idx_recovery_events_kind; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_recovery_events_kind ON agent_workflow.recovery_events USING btree (kind, created_at);


--
-- Name: idx_recovery_events_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_recovery_events_task ON agent_workflow.recovery_events USING btree (task_id, created_at);


--
-- Name: idx_repo_capability_readiness; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_repo_capability_readiness ON agent_workflow.repo_capability_config USING btree (readiness);


--
-- Name: idx_repo_capability_template; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_repo_capability_template ON agent_workflow.repo_capability_config USING btree (template_id);


--
-- Name: idx_resource_bundle_applies_actor; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_resource_bundle_applies_actor ON agent_workflow.resource_bundle_applies USING btree (actor_user_id);


--
-- Name: idx_resource_bundle_applies_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_resource_bundle_applies_state ON agent_workflow.resource_bundle_applies USING btree (state);


--
-- Name: idx_resource_grants_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_resource_grants_user ON agent_workflow.resource_grants USING btree (user_id);


--
-- Name: idx_review_comments_version; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_review_comments_version ON agent_workflow.review_comments USING btree (doc_version_id, anchor_section_path);


--
-- Name: idx_review_node_reviewers_actor; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_review_node_reviewers_actor ON agent_workflow.review_node_reviewers USING btree (reviewer_user_id, task_id, review_node_id);


--
-- Name: idx_review_node_reviewers_node; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_review_node_reviewers_node ON agent_workflow.review_node_reviewers USING btree (task_id, review_node_id);


--
-- Name: idx_rgn_cached_repo; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_rgn_cached_repo ON agent_workflow.repo_group_nodes USING btree (cached_repo_id);


--
-- Name: idx_rgn_child_group; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_rgn_child_group ON agent_workflow.repo_group_nodes USING btree (child_group_id);


--
-- Name: idx_runtime_session_leases_created_run; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_runtime_session_leases_created_run ON agent_workflow.runtime_session_leases USING btree (created_node_run_id);


--
-- Name: idx_runtime_session_leases_lease_run; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_runtime_session_leases_lease_run ON agent_workflow.runtime_session_leases USING btree (lease_node_run_id);


--
-- Name: idx_runtime_session_leases_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_runtime_session_leases_task ON agent_workflow.runtime_session_leases USING btree (task_id);


--
-- Name: idx_scheduled_tasks_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_scheduled_tasks_due ON agent_workflow.scheduled_tasks USING btree (enabled, next_run_at);


--
-- Name: idx_scheduled_tasks_owner; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_scheduled_tasks_owner ON agent_workflow.scheduled_tasks USING btree (owner_user_id);


--
-- Name: idx_skill_versions_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_skill_versions_created ON agent_workflow.skill_versions USING btree (created_at);


--
-- Name: idx_skill_versions_fusion; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_skill_versions_fusion ON agent_workflow.skill_versions USING btree (fusion_id);


--
-- Name: idx_task_archive_audit_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_archive_audit_created ON agent_workflow.task_archive_audit USING btree (created_at);


--
-- Name: idx_task_collab_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_collab_task ON agent_workflow.task_collaborators USING btree (task_id);


--
-- Name: idx_task_collab_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_collab_user ON agent_workflow.task_collaborators USING btree (user_id);


--
-- Name: idx_task_execution_attempts_effect_no; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_attempts_effect_no ON agent_workflow.task_execution_effect_attempts USING btree (effect_id, attempt_no);


--
-- Name: idx_task_execution_attempts_one_active; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_attempts_one_active ON agent_workflow.task_execution_effect_attempts USING btree (effect_id) WHERE (state = ANY (ARRAY['prepared'::text, 'acting'::text, 'recovery-required'::text]));


--
-- Name: idx_task_execution_effect_fences_active_key; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_effect_fences_active_key ON agent_workflow.task_execution_effect_fences USING btree (fence_key) WHERE (released_at IS NULL);


--
-- Name: idx_task_execution_effects_lineage_family_generation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_effects_lineage_family_generation ON agent_workflow.task_execution_effects USING btree (execution_lineage_id, operation_family_key, operation_generation);


--
-- Name: idx_task_execution_effects_task_operation_generation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_effects_task_operation_generation ON agent_workflow.task_execution_effects USING btree (task_id, operation_key, operation_generation);


--
-- Name: idx_task_execution_effects_task_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_execution_effects_task_state ON agent_workflow.task_execution_effects USING btree (task_id, state);


--
-- Name: idx_task_execution_intents_claimed_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_intents_claimed_task ON agent_workflow.task_execution_intents USING btree (task_id) WHERE (state = 'claimed'::text);


--
-- Name: idx_task_execution_intents_pending_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_intents_pending_task ON agent_workflow.task_execution_intents USING btree (task_id) WHERE (state = 'pending'::text);


--
-- Name: idx_task_execution_intents_task_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_execution_intents_task_state ON agent_workflow.task_execution_intents USING btree (task_id, state);


--
-- Name: idx_task_execution_lineage_decision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_lineage_decision ON agent_workflow.task_execution_lineage_operation_records USING btree (execution_lineage_id, operation_family_key, operation_generation) WHERE (record_kind = 'replay-decision'::text);


--
-- Name: idx_task_execution_lineage_decision_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_execution_lineage_decision_state ON agent_workflow.task_execution_lineage_operation_records USING btree (record_kind, decision_state, updated_at);


--
-- Name: idx_task_execution_lineage_watermark; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_lineage_watermark ON agent_workflow.task_execution_lineage_operation_records USING btree (execution_lineage_id, operation_family_key) WHERE (record_kind = 'generation-watermark'::text);


--
-- Name: idx_task_execution_maintenance_members_active_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_task_execution_maintenance_members_active_task ON agent_workflow.task_execution_maintenance_members USING btree (task_id) WHERE (released_at IS NULL);


--
-- Name: idx_task_execution_maintenance_state_updated; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_execution_maintenance_state_updated ON agent_workflow.task_execution_maintenance_claims USING btree (state, updated_at);


--
-- Name: idx_task_execution_owners_state_lease; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_execution_owners_state_lease ON agent_workflow.task_execution_owners USING btree (state, lease_until);


--
-- Name: idx_task_feedback_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_feedback_task ON agent_workflow.task_feedback USING btree (task_id, created_at);


--
-- Name: idx_task_node_clarify_directives_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_node_clarify_directives_task ON agent_workflow.task_node_clarify_directives USING btree (task_id);


--
-- Name: idx_task_questions_origin; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_questions_origin ON agent_workflow.task_questions USING btree (origin_node_run_id);


--
-- Name: idx_task_questions_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_questions_task ON agent_workflow.task_questions USING btree (task_id);


--
-- Name: idx_task_repos_cached_repo_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_repos_cached_repo_id ON agent_workflow.task_repos USING btree (cached_repo_id);


--
-- Name: idx_task_repos_cached_repo_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_repos_cached_repo_task ON agent_workflow.task_repos USING btree (cached_repo_id, task_id);


--
-- Name: idx_task_repos_repo_path; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_repos_repo_path ON agent_workflow.task_repos USING btree (repo_path);


--
-- Name: idx_task_repos_repo_url; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_task_repos_repo_url ON agent_workflow.task_repos USING btree (repo_url);


--
-- Name: idx_tasks_branch_started_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_branch_started_id ON agent_workflow.tasks USING btree (branch_started_at, id);


--
-- Name: idx_tasks_cached_repo; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_cached_repo ON agent_workflow.tasks USING btree (cached_repo_id);


--
-- Name: idx_tasks_code_round; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_code_round ON agent_workflow.tasks USING btree (code_round_id);


--
-- Name: idx_tasks_digital_employee_round; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_digital_employee_round ON agent_workflow.tasks USING btree (digital_employee_round_id);


--
-- Name: idx_tasks_event_delivery_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_tasks_event_delivery_unique ON agent_workflow.tasks USING btree (event_delivery_id) WHERE (event_delivery_id IS NOT NULL);


--
-- Name: idx_tasks_event_subscription; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_event_subscription ON agent_workflow.tasks USING btree (event_subscription_id);


--
-- Name: idx_tasks_list_owner_started_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_list_owner_started_id ON agent_workflow.tasks USING btree (owner_user_id, started_at, id);


--
-- Name: idx_tasks_list_parent_started_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_list_parent_started_id ON agent_workflow.tasks USING btree (parent_task_id, started_at, id);


--
-- Name: idx_tasks_list_started_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_list_started_id ON agent_workflow.tasks USING btree (started_at, id);


--
-- Name: idx_tasks_list_status_started_id; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_list_status_started_id ON agent_workflow.tasks USING btree (status, started_at, id);


--
-- Name: idx_tasks_live; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_live ON agent_workflow.tasks USING btree (id) WHERE (deleted_at IS NULL);


--
-- Name: idx_tasks_scheduled_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_scheduled_task ON agent_workflow.tasks USING btree (scheduled_task_id);


--
-- Name: idx_tasks_source_agent; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_source_agent ON agent_workflow.tasks USING btree (source_agent_id);


--
-- Name: idx_tasks_source_termination; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_source_termination ON agent_workflow.tasks USING btree (source_termination_binding, source_termination_launch_rev);


--
-- Name: idx_tasks_status_finished; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_status_finished ON agent_workflow.tasks USING btree (status, finished_at);


--
-- Name: idx_tasks_webhook_trigger; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_webhook_trigger ON agent_workflow.tasks USING btree (webhook_trigger_id);


--
-- Name: idx_tasks_workflow; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_tasks_workflow ON agent_workflow.tasks USING btree (workflow_id, started_at);


--
-- Name: idx_token_audit_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_token_audit_created ON agent_workflow.token_audit USING btree (created_at);


--
-- Name: idx_token_audit_pat_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_token_audit_pat_created ON agent_workflow.token_audit USING btree (pat_id, created_at);


--
-- Name: idx_token_audit_user_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_token_audit_user_created ON agent_workflow.token_audit USING btree (user_id, created_at);


--
-- Name: idx_token_delete_snapshot_audit; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_token_delete_snapshot_audit ON agent_workflow.token_delete_snapshot USING btree (audit_id);


--
-- Name: idx_token_delete_snapshot_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_token_delete_snapshot_created ON agent_workflow.token_delete_snapshot USING btree (created_at);


--
-- Name: idx_user_access_audit_created; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_access_audit_created ON agent_workflow.user_access_audit USING btree (created_at);


--
-- Name: idx_user_access_audit_operation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_access_audit_operation ON agent_workflow.user_access_audit USING btree (operation_id);


--
-- Name: idx_user_access_audit_target_revision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_access_audit_target_revision ON agent_workflow.user_access_audit USING btree (target_user_id, access_revision);


--
-- Name: idx_user_identities_provider; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_identities_provider ON agent_workflow.user_identities USING btree (provider_id);


--
-- Name: idx_user_identities_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_identities_user ON agent_workflow.user_identities USING btree (user_id);


--
-- Name: idx_user_pats_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_pats_user ON agent_workflow.user_pats USING btree (user_id);


--
-- Name: idx_user_permission_grants_permission; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_permission_grants_permission ON agent_workflow.user_permission_grants USING btree (permission);


--
-- Name: idx_user_repository_transport_credentials_provider_generation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_repository_transport_credentials_provider_generation ON agent_workflow.user_repository_transport_credentials USING btree (provider, connection_generation);


--
-- Name: idx_user_sessions_user; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_user_sessions_user ON agent_workflow.user_sessions USING btree (user_id, expires_at);


--
-- Name: idx_users_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_users_status ON agent_workflow.users USING btree (status);


--
-- Name: idx_webhook_deliveries_dedupe; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_webhook_deliveries_dedupe ON agent_workflow.webhook_deliveries USING btree (endpoint_id, event_uuid) WHERE ((event_uuid IS NOT NULL) AND (status <> ALL (ARRAY['rejected'::text, 'failed'::text])));


--
-- Name: idx_webhook_deliveries_endpoint_time; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_deliveries_endpoint_time ON agent_workflow.webhook_deliveries USING btree (endpoint_id, received_at);


--
-- Name: idx_webhook_deliveries_event_time; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_deliveries_event_time ON agent_workflow.webhook_deliveries USING btree (event_type, received_at);


--
-- Name: idx_webhook_deliveries_mr_fact; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_webhook_deliveries_mr_fact ON agent_workflow.webhook_deliveries USING btree (endpoint_id, mr_fact_key) WHERE ((mr_fact_key IS NOT NULL) AND (replayed_from_delivery_id IS NULL) AND (status <> ALL (ARRAY['rejected'::text, 'failed'::text])));


--
-- Name: idx_webhook_deliveries_received_at; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_deliveries_received_at ON agent_workflow.webhook_deliveries USING btree (received_at);


--
-- Name: idx_webhook_deliveries_repo_time; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_deliveries_repo_time ON agent_workflow.webhook_deliveries USING btree (repo_path, received_at);


--
-- Name: idx_webhook_deliveries_status_time; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_deliveries_status_time ON agent_workflow.webhook_deliveries USING btree (status, received_at);


--
-- Name: idx_webhook_endpoints_url_token; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_webhook_endpoints_url_token ON agent_workflow.webhook_endpoints USING btree (url_token);


--
-- Name: idx_webhook_fires_delivery; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_fires_delivery ON agent_workflow.webhook_trigger_fires USING btree (delivery_id);


--
-- Name: idx_webhook_fires_stream; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_fires_stream ON agent_workflow.webhook_trigger_fires USING btree (trigger_id, stream_key, fired_at);


--
-- Name: idx_webhook_fires_trigger_time; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_fires_trigger_time ON agent_workflow.webhook_trigger_fires USING btree (trigger_id, fired_at);


--
-- Name: idx_webhook_mr_effect_delivery; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_webhook_mr_effect_delivery ON agent_workflow.webhook_mr_control_effects USING btree (delivery_id);


--
-- Name: idx_webhook_mr_effect_due; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_effect_due ON agent_workflow.webhook_mr_control_effects USING btree (status, next_attempt_at);


--
-- Name: idx_webhook_mr_effect_stream_revision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX idx_webhook_mr_effect_stream_revision ON agent_workflow.webhook_mr_control_effects USING btree (endpoint_id, stream_key, revision);


--
-- Name: idx_webhook_mr_guard_status; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_guard_status ON agent_workflow.webhook_mr_launch_guards USING btree (status, updated_at);


--
-- Name: idx_webhook_mr_guard_stream_revision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_guard_stream_revision ON agent_workflow.webhook_mr_launch_guards USING btree (endpoint_id, stream_key, launch_revision);


--
-- Name: idx_webhook_mr_guard_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_guard_task ON agent_workflow.webhook_mr_launch_guards USING btree (task_id);


--
-- Name: idx_webhook_mr_stream_endpoint_state; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_stream_endpoint_state ON agent_workflow.webhook_mr_stream_states USING btree (endpoint_id, state);


--
-- Name: idx_webhook_mr_target_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_mr_target_task ON agent_workflow.webhook_mr_control_targets USING btree (task_id);


--
-- Name: idx_webhook_triggers_endpoint_enabled; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_triggers_endpoint_enabled ON agent_workflow.webhook_triggers USING btree (endpoint_id, enabled);


--
-- Name: idx_webhook_triggers_owner; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_webhook_triggers_owner ON agent_workflow.webhook_triggers USING btree (owner_user_id);


--
-- Name: idx_wg_assign_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_wg_assign_task ON agent_workflow.workgroup_assignments USING btree (task_id, status);


--
-- Name: idx_wg_msg_task; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_wg_msg_task ON agent_workflow.workgroup_messages USING btree (task_id, id);


--
-- Name: idx_workgroup_members_group; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE INDEX idx_workgroup_members_group ON agent_workflow.workgroup_members USING btree (workgroup_id);


--
-- Name: mcps_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX mcps_owner_name_unique ON agent_workflow.mcps USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: mission_input_uploads_idem_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX mission_input_uploads_idem_unique ON agent_workflow.mission_input_uploads USING btree (actor_user_id, upload_idempotency_key) WHERE (upload_idempotency_key IS NOT NULL);


--
-- Name: plugins_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX plugins_owner_name_unique ON agent_workflow.plugins USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: repository_employee_assignments_scope_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX repository_employee_assignments_scope_unique ON agent_workflow.repository_employee_assignments USING btree (scope_kind, COALESCE(scope_ref, ''::text));


--
-- Name: repository_transport_connections_provider_generation_uq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX repository_transport_connections_provider_generation_uq ON agent_workflow.repository_transport_connections USING btree (provider, connection_generation);


--
-- Name: skills_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX skills_owner_name_unique ON agent_workflow.skills USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: uniq_code_ai_attempts_identity; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_code_ai_attempts_identity ON agent_workflow.code_ai_attempts USING btree (round_id, stage_name, shard_key, rerun_seq, attempt_seq);


--
-- Name: uniq_code_finding_identity; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_code_finding_identity ON agent_workflow.code_findings USING btree (code_host_endpoint_id, stable_project_id, anchor_kind, anchor_id, fingerprint, generation);


--
-- Name: uniq_code_round_stages_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_code_round_stages_seq ON agent_workflow.code_round_stages USING btree (round_id, stage_seq);


--
-- Name: uniq_code_work_items_identity; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_code_work_items_identity ON agent_workflow.code_work_items USING btree (code_host_endpoint_id, stable_project_id, capability, anchor_kind, anchor_id);


--
-- Name: uniq_code_work_rounds_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_code_work_rounds_seq ON agent_workflow.code_work_rounds USING btree (work_item_id, round_seq);


--
-- Name: uniq_intent_apply_journal_mutation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_apply_journal_mutation ON agent_workflow.intent_apply_journal USING btree (session_id, client_mutation_id);


--
-- Name: uniq_intent_drafts_session_revision; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_drafts_session_revision ON agent_workflow.intent_drafts USING btree (session_id, revision);


--
-- Name: uniq_intent_turn_events_external; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_turn_events_external ON agent_workflow.intent_turn_events USING btree (turn_id, source, external_event_id);


--
-- Name: uniq_intent_turn_events_turn_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_turn_events_turn_seq ON agent_workflow.intent_turn_events USING btree (turn_id, event_seq);


--
-- Name: uniq_intent_turns_session_mutation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_turns_session_mutation ON agent_workflow.intent_turns USING btree (session_id, client_mutation_id) WHERE (client_mutation_id IS NOT NULL);


--
-- Name: uniq_intent_turns_session_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_turns_session_seq ON agent_workflow.intent_turns USING btree (session_id, seq);


--
-- Name: uniq_intent_working_set_mutation; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_working_set_mutation ON agent_workflow.intent_working_set_changes USING btree (session_id, client_mutation_id);


--
-- Name: uniq_intent_working_set_unresolved; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_intent_working_set_unresolved ON agent_workflow.intent_working_set_changes USING btree (session_id) WHERE (state = ANY (ARRAY['queued'::text, 'applying'::text, 'failed'::text]));


--
-- Name: uniq_mcp_runtime_test_events_external; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_events_external ON agent_workflow.mcp_runtime_test_events USING btree (test_session_id, external_event_key) WHERE (external_event_key IS NOT NULL);


--
-- Name: uniq_mcp_runtime_test_events_session_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_events_session_seq ON agent_workflow.mcp_runtime_test_events USING btree (test_session_id, event_seq);


--
-- Name: uniq_mcp_runtime_test_session_leases_test_session; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_session_leases_test_session ON agent_workflow.mcp_runtime_test_session_leases USING btree (test_session_id);


--
-- Name: uniq_mcp_runtime_test_sessions_create; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_sessions_create ON agent_workflow.mcp_runtime_test_sessions USING btree (mcp_id, owner_user_id, client_create_id);


--
-- Name: uniq_mcp_runtime_test_sessions_owner_mcp_live; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_sessions_owner_mcp_live ON agent_workflow.mcp_runtime_test_sessions USING btree (mcp_id, owner_user_id) WHERE (status = ANY (ARRAY['active'::text, 'ending'::text]));


--
-- Name: uniq_mcp_runtime_test_turns_message; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_turns_message ON agent_workflow.mcp_runtime_test_turns USING btree (session_id, client_message_id);


--
-- Name: uniq_mcp_runtime_test_turns_session_seq; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_mcp_runtime_test_turns_session_seq ON agent_workflow.mcp_runtime_test_turns USING btree (session_id, seq);


--
-- Name: uniq_repo_capability_cell; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_repo_capability_cell ON agent_workflow.repo_capability_config USING btree (repo_id, capability);


--
-- Name: uniq_resource_bundle_applies_key; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_resource_bundle_applies_key ON agent_workflow.resource_bundle_applies USING btree (scope, key);


--
-- Name: uniq_task_questions_identity; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uniq_task_questions_identity ON agent_workflow.task_questions USING btree (origin_node_run_id, question_id, role_kind);


--
-- Name: uq_skill_operations_active; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uq_skill_operations_active ON agent_workflow.skill_operations USING btree (skill_id) WHERE (active = 1);


--
-- Name: uq_skill_versions_skill_v; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uq_skill_versions_skill_v ON agent_workflow.skill_versions USING btree (skill_id, version_index);


--
-- Name: uq_workgroup_members_display; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX uq_workgroup_members_display ON agent_workflow.workgroup_members USING btree (workgroup_id, display_name);


--
-- Name: user_identities_provider_subject_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX user_identities_provider_subject_unique ON agent_workflow.user_identities USING btree (provider_id, subject);


--
-- Name: verification_profiles_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX verification_profiles_owner_name_unique ON agent_workflow.verification_profiles USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: workgroups_owner_name_unique; Type: INDEX; Schema: agent_workflow; Owner: -
--

CREATE UNIQUE INDEX workgroups_owner_name_unique ON agent_workflow.workgroups USING btree (COALESCE(owner_user_id, ''::text), name);


--
-- Name: action_template_revisions action_template_revisions_template_id_action_templates_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.action_template_revisions
    ADD CONSTRAINT action_template_revisions_template_id_action_templates_id_fk FOREIGN KEY (template_id) REFERENCES agent_workflow.action_templates(id);


--
-- Name: automation_policy_revisions automation_policy_revisions_policy_id_automation_policies_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.automation_policy_revisions
    ADD CONSTRAINT automation_policy_revisions_policy_id_automation_policies_id_fk FOREIGN KEY (policy_id) REFERENCES agent_workflow.automation_policies(id);


--
-- Name: clarify_rounds clarify_rounds_asking_node_run_id_node_runs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.clarify_rounds
    ADD CONSTRAINT clarify_rounds_asking_node_run_id_node_runs_id_fk FOREIGN KEY (asking_node_run_id) REFERENCES agent_workflow.node_runs(id) ON DELETE CASCADE;


--
-- Name: clarify_rounds clarify_rounds_intermediary_node_run_id_node_runs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.clarify_rounds
    ADD CONSTRAINT clarify_rounds_intermediary_node_run_id_node_runs_id_fk FOREIGN KEY (intermediary_node_run_id) REFERENCES agent_workflow.node_runs(id) ON DELETE CASCADE;


--
-- Name: clarify_rounds clarify_rounds_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.clarify_rounds
    ADD CONSTRAINT clarify_rounds_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: collaboration_gate_artifacts collaboration_gate_artifacts_operation_id_collabor_4d082f595e5b; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.collaboration_gate_artifacts
    ADD CONSTRAINT collaboration_gate_artifacts_operation_id_collabor_4d082f595e5b FOREIGN KEY (operation_id) REFERENCES agent_workflow.collaboration_gate_operations(id) ON DELETE CASCADE;


--
-- Name: collaboration_gate_operations collaboration_gate_operations_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.collaboration_gate_operations
    ADD CONSTRAINT collaboration_gate_operations_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: committed_event_deliveries committed_event_deliveries_event_id_committed_events_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.committed_event_deliveries
    ADD CONSTRAINT committed_event_deliveries_event_id_committed_events_id_fk FOREIGN KEY (event_id) REFERENCES agent_workflow.committed_events(id) ON DELETE CASCADE;


--
-- Name: custom_event_source_revisions custom_event_source_revisions_source_id_custom_eve_0ff963268a83; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.custom_event_source_revisions
    ADD CONSTRAINT custom_event_source_revisions_source_id_custom_eve_0ff963268a83 FOREIGN KEY (source_id) REFERENCES agent_workflow.custom_event_source_definitions(id);


--
-- Name: development_action_runs development_action_runs_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_action_runs
    ADD CONSTRAINT development_action_runs_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_adapter_definition_revisions development_adapter_definition_revisions_adapter_i_147cf7c4a221; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_adapter_definition_revisions
    ADD CONSTRAINT development_adapter_definition_revisions_adapter_i_147cf7c4a221 FOREIGN KEY (adapter_id) REFERENCES agent_workflow.development_adapter_definitions(id);


--
-- Name: development_agent_attempts development_agent_attempts_action_run_id_developme_3d3b074560bb; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_agent_attempts
    ADD CONSTRAINT development_agent_attempts_action_run_id_developme_3d3b074560bb FOREIGN KEY (action_run_id) REFERENCES agent_workflow.development_action_runs(id);


--
-- Name: development_approval_sagas development_approval_sagas_mission_id_development__5886264c140b; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_approval_sagas
    ADD CONSTRAINT development_approval_sagas_mission_id_development__5886264c140b FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_approval_sagas development_approval_sagas_step_run_id_development_ba15044b16d7; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_approval_sagas
    ADD CONSTRAINT development_approval_sagas_step_run_id_development_ba15044b16d7 FOREIGN KEY (step_run_id) REFERENCES agent_workflow.development_step_runs(id);


--
-- Name: development_bundle_refs development_bundle_refs_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_bundle_refs
    ADD CONSTRAINT development_bundle_refs_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_decisions development_decisions_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_decisions
    ADD CONSTRAINT development_decisions_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_deferred_wakes development_deferred_wakes_mission_id_development__44b54f5464c1; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_deferred_wakes
    ADD CONSTRAINT development_deferred_wakes_mission_id_development__44b54f5464c1 FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_effects development_effects_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_effects
    ADD CONSTRAINT development_effects_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_fact_snapshots development_fact_snapshots_mission_id_development__f23708033cce; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_fact_snapshots
    ADD CONSTRAINT development_fact_snapshots_mission_id_development__f23708033cce FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_feedback_ledger development_feedback_ledger_mission_id_development_67f5b2123306; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_feedback_ledger
    ADD CONSTRAINT development_feedback_ledger_mission_id_development_67f5b2123306 FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_mission_links development_mission_links_child_mission_id_develop_c5db09d1d172; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_links
    ADD CONSTRAINT development_mission_links_child_mission_id_develop_c5db09d1d172 FOREIGN KEY (child_mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_mission_links development_mission_links_parent_mission_id_develo_f327baef86f4; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_links
    ADD CONSTRAINT development_mission_links_parent_mission_id_develo_f327baef86f4 FOREIGN KEY (parent_mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_mission_links development_mission_links_parent_step_run_id_devel_5ae3a3eabfa7; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_links
    ADD CONSTRAINT development_mission_links_parent_step_run_id_devel_5ae3a3eabfa7 FOREIGN KEY (parent_step_run_id) REFERENCES agent_workflow.development_step_runs(id);


--
-- Name: development_mission_sources development_mission_sources_mission_id_development_18b469725042; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mission_sources
    ADD CONSTRAINT development_mission_sources_mission_id_development_18b469725042 FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_mr_claims development_mr_claims_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_mr_claims
    ADD CONSTRAINT development_mr_claims_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_repository_upload_plan_entries development_repository_upload_plan_entries_plan_id_c49b09384582; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_plan_entries
    ADD CONSTRAINT development_repository_upload_plan_entries_plan_id_c49b09384582 FOREIGN KEY (plan_id) REFERENCES agent_workflow.development_repository_upload_plans(id);


--
-- Name: development_repository_upload_plans development_repository_upload_plans_mission_id_dev_346f2394746d; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_plans
    ADD CONSTRAINT development_repository_upload_plans_mission_id_dev_346f2394746d FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_repository_upload_receipts development_repository_upload_receipts_plan_id_dev_2c3bab9954c9; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_repository_upload_receipts
    ADD CONSTRAINT development_repository_upload_receipts_plan_id_dev_2c3bab9954c9 FOREIGN KEY (plan_id) REFERENCES agent_workflow.development_repository_upload_plans(id);


--
-- Name: development_step_joins development_step_joins_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_step_joins
    ADD CONSTRAINT development_step_joins_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_step_runs development_step_runs_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_step_runs
    ADD CONSTRAINT development_step_runs_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: development_wake_hints development_wake_hints_mission_id_development_missions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.development_wake_hints
    ADD CONSTRAINT development_wake_hints_mission_id_development_missions_id_fk FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: digital_employee_revisions digital_employee_revisions_employee_id_digital_employees_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.digital_employee_revisions
    ADD CONSTRAINT digital_employee_revisions_employee_id_digital_employees_id_fk FOREIGN KEY (employee_id) REFERENCES agent_workflow.digital_employees(id);


--
-- Name: doc_versions doc_versions_review_node_run_id_node_runs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.doc_versions
    ADD CONSTRAINT doc_versions_review_node_run_id_node_runs_id_fk FOREIGN KEY (review_node_run_id) REFERENCES agent_workflow.node_runs(id) ON DELETE CASCADE;


--
-- Name: doc_versions doc_versions_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.doc_versions
    ADD CONSTRAINT doc_versions_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: employee_approval_sagas employee_approval_sagas_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_approval_sagas
    ADD CONSTRAINT employee_approval_sagas_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_approval_sagas employee_approval_sagas_submit_round_id_employee_r_191362b9c92f; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_approval_sagas
    ADD CONSTRAINT employee_approval_sagas_submit_round_id_employee_r_191362b9c92f FOREIGN KEY (submit_round_id) REFERENCES agent_workflow.employee_reaction_rounds(id);


--
-- Name: employee_attention_bindings employee_attention_bindings_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_attention_bindings
    ADD CONSTRAINT employee_attention_bindings_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_attention_bindings employee_attention_bindings_context_id_employee_co_fe5b453e173a; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_attention_bindings
    ADD CONSTRAINT employee_attention_bindings_context_id_employee_co_fe5b453e173a FOREIGN KEY (context_id) REFERENCES agent_workflow.employee_context_records(id);


--
-- Name: employee_case_event_origins employee_case_event_origins_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_event_origins
    ADD CONSTRAINT employee_case_event_origins_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_case_inbox employee_case_inbox_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_inbox
    ADD CONSTRAINT employee_case_inbox_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_case_members employee_case_members_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_members
    ADD CONSTRAINT employee_case_members_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id) ON DELETE CASCADE;


--
-- Name: employee_case_members employee_case_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_members
    ADD CONSTRAINT employee_case_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: employee_case_metering_receipts employee_case_metering_receipts_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_metering_receipts
    ADD CONSTRAINT employee_case_metering_receipts_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id) ON DELETE CASCADE;


--
-- Name: employee_case_workspaces employee_case_workspaces_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_case_workspaces
    ADD CONSTRAINT employee_case_workspaces_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_change_candidates employee_change_candidates_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_change_candidates
    ADD CONSTRAINT employee_change_candidates_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_change_candidates employee_change_candidates_round_id_employee_react_a8d55d68619e; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_change_candidates
    ADD CONSTRAINT employee_change_candidates_round_id_employee_react_a8d55d68619e FOREIGN KEY (round_id) REFERENCES agent_workflow.employee_reaction_rounds(id);


--
-- Name: employee_channel_results employee_channel_results_channel_id_employee_channels_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channel_results
    ADD CONSTRAINT employee_channel_results_channel_id_employee_channels_id_fk FOREIGN KEY (channel_id) REFERENCES agent_workflow.employee_channels(id);


--
-- Name: employee_channels employee_channels_child_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channels
    ADD CONSTRAINT employee_channels_child_case_id_employee_cases_id_fk FOREIGN KEY (child_case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_channels employee_channels_invocation_id_employee_invocations_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channels
    ADD CONSTRAINT employee_channels_invocation_id_employee_invocations_id_fk FOREIGN KEY (invocation_id) REFERENCES agent_workflow.employee_invocations(id);


--
-- Name: employee_channels employee_channels_parent_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_channels
    ADD CONSTRAINT employee_channels_parent_case_id_employee_cases_id_fk FOREIGN KEY (parent_case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_context_links employee_context_links_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_links
    ADD CONSTRAINT employee_context_links_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_context_records employee_context_records_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_records
    ADD CONSTRAINT employee_context_records_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_context_revisions employee_context_revisions_context_id_employee_con_e9ee9b9a1144; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_context_revisions
    ADD CONSTRAINT employee_context_revisions_context_id_employee_con_e9ee9b9a1144 FOREIGN KEY (context_id) REFERENCES agent_workflow.employee_context_records(id);


--
-- Name: employee_definition_revisions employee_definition_revisions_employee_id_employee_8e76e11ba591; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_definition_revisions
    ADD CONSTRAINT employee_definition_revisions_employee_id_employee_8e76e11ba591 FOREIGN KEY (employee_id) REFERENCES agent_workflow.employee_definitions(id);


--
-- Name: employee_external_context_bindings employee_external_context_bindings_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_external_context_bindings
    ADD CONSTRAINT employee_external_context_bindings_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_external_context_bindings employee_external_context_bindings_context_id_empl_e9977b5da35f; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_external_context_bindings
    ADD CONSTRAINT employee_external_context_bindings_context_id_empl_e9977b5da35f FOREIGN KEY (context_id) REFERENCES agent_workflow.employee_context_records(id);


--
-- Name: employee_invocations employee_invocations_parent_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_invocations
    ADD CONSTRAINT employee_invocations_parent_case_id_employee_cases_id_fk FOREIGN KEY (parent_case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_invocations employee_invocations_parent_round_id_employee_reac_8b1facd8653a; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_invocations
    ADD CONSTRAINT employee_invocations_parent_round_id_employee_reac_8b1facd8653a FOREIGN KEY (parent_round_id) REFERENCES agent_workflow.employee_reaction_rounds(id);


--
-- Name: employee_job_template_revisions employee_job_template_revisions_template_id_employ_8afd92d090c2; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_job_template_revisions
    ADD CONSTRAINT employee_job_template_revisions_template_id_employ_8afd92d090c2 FOREIGN KEY (template_id) REFERENCES agent_workflow.employee_job_templates(id);


--
-- Name: employee_os_outbox employee_os_outbox_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_os_outbox
    ADD CONSTRAINT employee_os_outbox_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_os_settings employee_os_settings_execution_policy_revision_emp_9984f9183d04; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_os_settings
    ADD CONSTRAINT employee_os_settings_execution_policy_revision_emp_9984f9183d04 FOREIGN KEY (execution_policy_revision) REFERENCES agent_workflow.employee_execution_policy_revisions(revision);


--
-- Name: employee_reaction_rounds employee_reaction_rounds_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_reaction_rounds
    ADD CONSTRAINT employee_reaction_rounds_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_reaction_rounds employee_reaction_rounds_inbox_id_employee_case_inbox_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_reaction_rounds
    ADD CONSTRAINT employee_reaction_rounds_inbox_id_employee_case_inbox_id_fk FOREIGN KEY (inbox_id) REFERENCES agent_workflow.employee_case_inbox(id);


--
-- Name: employee_round_workspace_states employee_round_workspace_states_case_id_employee_cases_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_round_workspace_states
    ADD CONSTRAINT employee_round_workspace_states_case_id_employee_cases_id_fk FOREIGN KEY (case_id) REFERENCES agent_workflow.employee_cases(id);


--
-- Name: employee_round_workspace_states employee_round_workspace_states_round_id_employee__b93987d3d270; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_round_workspace_states
    ADD CONSTRAINT employee_round_workspace_states_round_id_employee__b93987d3d270 FOREIGN KEY (round_id) REFERENCES agent_workflow.employee_reaction_rounds(id);


--
-- Name: employee_tool_registration_revisions employee_tool_registration_revisions_tool_id_emplo_636fb0d8fb9f; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.employee_tool_registration_revisions
    ADD CONSTRAINT employee_tool_registration_revisions_tool_id_emplo_636fb0d8fb9f FOREIGN KEY (tool_id) REFERENCES agent_workflow.employee_tool_registrations(id);


--
-- Name: event_deliveries event_deliveries_event_id_event_records_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_deliveries
    ADD CONSTRAINT event_deliveries_event_id_event_records_id_fk FOREIGN KEY (event_id) REFERENCES agent_workflow.event_records(id);


--
-- Name: event_deliveries event_deliveries_subscription_id_event_subscriptions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.event_deliveries
    ADD CONSTRAINT event_deliveries_subscription_id_event_subscriptions_id_fk FOREIGN KEY (subscription_id) REFERENCES agent_workflow.event_subscriptions(id);


--
-- Name: intent_apply_journal intent_apply_journal_session_id_intent_sessions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_apply_journal
    ADD CONSTRAINT intent_apply_journal_session_id_intent_sessions_id_fk FOREIGN KEY (session_id) REFERENCES agent_workflow.intent_sessions(id) ON DELETE CASCADE;


--
-- Name: intent_draft_resolutions intent_draft_resolutions_draft_id_intent_drafts_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_draft_resolutions
    ADD CONSTRAINT intent_draft_resolutions_draft_id_intent_drafts_id_fk FOREIGN KEY (draft_id) REFERENCES agent_workflow.intent_drafts(id) ON DELETE CASCADE;


--
-- Name: intent_draft_resolutions intent_draft_resolutions_session_id_intent_sessions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_draft_resolutions
    ADD CONSTRAINT intent_draft_resolutions_session_id_intent_sessions_id_fk FOREIGN KEY (session_id) REFERENCES agent_workflow.intent_sessions(id) ON DELETE CASCADE;


--
-- Name: intent_drafts intent_drafts_session_id_intent_sessions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_drafts
    ADD CONSTRAINT intent_drafts_session_id_intent_sessions_id_fk FOREIGN KEY (session_id) REFERENCES agent_workflow.intent_sessions(id) ON DELETE CASCADE;


--
-- Name: intent_turn_events intent_turn_events_turn_id_intent_turns_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_turn_events
    ADD CONSTRAINT intent_turn_events_turn_id_intent_turns_id_fk FOREIGN KEY (turn_id) REFERENCES agent_workflow.intent_turns(id) ON DELETE CASCADE;


--
-- Name: intent_turns intent_turns_session_id_intent_sessions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_turns
    ADD CONSTRAINT intent_turns_session_id_intent_sessions_id_fk FOREIGN KEY (session_id) REFERENCES agent_workflow.intent_sessions(id) ON DELETE CASCADE;


--
-- Name: intent_working_set_changes intent_working_set_changes_session_id_intent_sessions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.intent_working_set_changes
    ADD CONSTRAINT intent_working_set_changes_session_id_intent_sessions_id_fk FOREIGN KEY (session_id) REFERENCES agent_workflow.intent_sessions(id) ON DELETE CASCADE;


--
-- Name: legacy_code_work_item_links legacy_code_work_item_links_mission_id_development_d4b1915e353c; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.legacy_code_work_item_links
    ADD CONSTRAINT legacy_code_work_item_links_mission_id_development_d4b1915e353c FOREIGN KEY (mission_id) REFERENCES agent_workflow.development_missions(id);


--
-- Name: lifecycle_alerts lifecycle_alerts_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.lifecycle_alerts
    ADD CONSTRAINT lifecycle_alerts_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: mcp_probes mcp_probes_mcp_id_mcps_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_probes
    ADD CONSTRAINT mcp_probes_mcp_id_mcps_id_fk FOREIGN KEY (mcp_id) REFERENCES agent_workflow.mcps(id) ON DELETE CASCADE;


--
-- Name: mcp_runtime_test_create_receipts mcp_runtime_test_create_receipts_mcp_id_mcps_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_create_receipts
    ADD CONSTRAINT mcp_runtime_test_create_receipts_mcp_id_mcps_id_fk FOREIGN KEY (mcp_id) REFERENCES agent_workflow.mcps(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_create_receipts mcp_runtime_test_create_receipts_owner_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_create_receipts
    ADD CONSTRAINT mcp_runtime_test_create_receipts_owner_user_id_users_id_fk FOREIGN KEY (owner_user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_events mcp_runtime_test_events_test_session_id_mcp_runtim_47e8aec33a5f; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_events
    ADD CONSTRAINT mcp_runtime_test_events_test_session_id_mcp_runtim_47e8aec33a5f FOREIGN KEY (test_session_id) REFERENCES agent_workflow.mcp_runtime_test_sessions(id) ON DELETE CASCADE;


--
-- Name: mcp_runtime_test_session_leases mcp_runtime_test_session_leases_created_turn_id_mc_733839fa8fd3; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_session_leases
    ADD CONSTRAINT mcp_runtime_test_session_leases_created_turn_id_mc_733839fa8fd3 FOREIGN KEY (created_turn_id) REFERENCES agent_workflow.mcp_runtime_test_turns(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_session_leases mcp_runtime_test_session_leases_current_turn_id_mc_f098fab5ac06; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_session_leases
    ADD CONSTRAINT mcp_runtime_test_session_leases_current_turn_id_mc_f098fab5ac06 FOREIGN KEY (current_turn_id) REFERENCES agent_workflow.mcp_runtime_test_turns(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_session_leases mcp_runtime_test_session_leases_lease_turn_id_mcp__6fa69ac53f6f; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_session_leases
    ADD CONSTRAINT mcp_runtime_test_session_leases_lease_turn_id_mcp__6fa69ac53f6f FOREIGN KEY (lease_turn_id) REFERENCES agent_workflow.mcp_runtime_test_turns(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_session_leases mcp_runtime_test_session_leases_test_session_id_mc_2a89b094c931; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_session_leases
    ADD CONSTRAINT mcp_runtime_test_session_leases_test_session_id_mc_2a89b094c931 FOREIGN KEY (test_session_id) REFERENCES agent_workflow.mcp_runtime_test_sessions(id) ON DELETE CASCADE;


--
-- Name: mcp_runtime_test_sessions mcp_runtime_test_sessions_mcp_id_mcps_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_sessions
    ADD CONSTRAINT mcp_runtime_test_sessions_mcp_id_mcps_id_fk FOREIGN KEY (mcp_id) REFERENCES agent_workflow.mcps(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_sessions mcp_runtime_test_sessions_owner_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_sessions
    ADD CONSTRAINT mcp_runtime_test_sessions_owner_user_id_users_id_fk FOREIGN KEY (owner_user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: mcp_runtime_test_turns mcp_runtime_test_turns_session_id_mcp_runtime_test_f98966f21820; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.mcp_runtime_test_turns
    ADD CONSTRAINT mcp_runtime_test_turns_session_id_mcp_runtime_test_f98966f21820 FOREIGN KEY (session_id) REFERENCES agent_workflow.mcp_runtime_test_sessions(id) ON DELETE CASCADE;


--
-- Name: memory_distill_events memory_distill_events_distill_job_id_memory_distill_jobs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.memory_distill_events
    ADD CONSTRAINT memory_distill_events_distill_job_id_memory_distill_jobs_id_fk FOREIGN KEY (distill_job_id) REFERENCES agent_workflow.memory_distill_jobs(id) ON DELETE CASCADE;


--
-- Name: node_run_events node_run_events_node_run_id_node_runs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_run_events
    ADD CONSTRAINT node_run_events_node_run_id_node_runs_id_fk FOREIGN KEY (node_run_id) REFERENCES agent_workflow.node_runs(id) ON DELETE CASCADE;


--
-- Name: node_run_outputs node_run_outputs_node_run_id_node_runs_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_run_outputs
    ADD CONSTRAINT node_run_outputs_node_run_id_node_runs_id_fk FOREIGN KEY (node_run_id) REFERENCES agent_workflow.node_runs(id) ON DELETE CASCADE;


--
-- Name: node_runs node_runs_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.node_runs
    ADD CONSTRAINT node_runs_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: repo_group_nodes repo_group_nodes_cached_repo_id_cached_repos_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repo_group_nodes
    ADD CONSTRAINT repo_group_nodes_cached_repo_id_cached_repos_id_fk FOREIGN KEY (cached_repo_id) REFERENCES agent_workflow.cached_repos(id);


--
-- Name: repo_group_nodes repo_group_nodes_group_id_repo_groups_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.repo_group_nodes
    ADD CONSTRAINT repo_group_nodes_group_id_repo_groups_id_fk FOREIGN KEY (group_id) REFERENCES agent_workflow.repo_groups(id) ON DELETE CASCADE;


--
-- Name: resource_grants resource_grants_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.resource_grants
    ADD CONSTRAINT resource_grants_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: review_comments review_comments_doc_version_id_doc_versions_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_comments
    ADD CONSTRAINT review_comments_doc_version_id_doc_versions_id_fk FOREIGN KEY (doc_version_id) REFERENCES agent_workflow.doc_versions(id) ON DELETE CASCADE;


--
-- Name: review_node_reviewers review_node_reviewers_assigned_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_node_reviewers
    ADD CONSTRAINT review_node_reviewers_assigned_by_user_id_users_id_fk FOREIGN KEY (assigned_by_user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: review_node_reviewers review_node_reviewers_reviewer_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_node_reviewers
    ADD CONSTRAINT review_node_reviewers_reviewer_user_id_users_id_fk FOREIGN KEY (reviewer_user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: review_node_reviewers review_node_reviewers_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.review_node_reviewers
    ADD CONSTRAINT review_node_reviewers_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: runtime_session_leases runtime_session_leases_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.runtime_session_leases
    ADD CONSTRAINT runtime_session_leases_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: skill_versions skill_versions_skill_id_skills_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.skill_versions
    ADD CONSTRAINT skill_versions_skill_id_skills_id_fk FOREIGN KEY (skill_id) REFERENCES agent_workflow.skills(id) ON DELETE CASCADE;


--
-- Name: task_collaborators task_collaborators_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_collaborators
    ADD CONSTRAINT task_collaborators_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_collaborators task_collaborators_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_collaborators
    ADD CONSTRAINT task_collaborators_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE RESTRICT;


--
-- Name: task_execution_effect_attempts task_execution_effect_attempts_effect_id_task_exec_dd101cf90ddf; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effect_attempts
    ADD CONSTRAINT task_execution_effect_attempts_effect_id_task_exec_dd101cf90ddf FOREIGN KEY (effect_id) REFERENCES agent_workflow.task_execution_effects(id) ON DELETE CASCADE;


--
-- Name: task_execution_effect_attempts task_execution_effect_attempts_intent_id_task_exec_6d21cf2aca30; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effect_attempts
    ADD CONSTRAINT task_execution_effect_attempts_intent_id_task_exec_6d21cf2aca30 FOREIGN KEY (intent_id) REFERENCES agent_workflow.task_execution_intents(id) ON DELETE CASCADE;


--
-- Name: task_execution_effect_fences task_execution_effect_fences_effect_attempt_id_tas_e1b169c32dd1; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effect_fences
    ADD CONSTRAINT task_execution_effect_fences_effect_attempt_id_tas_e1b169c32dd1 FOREIGN KEY (effect_attempt_id) REFERENCES agent_workflow.task_execution_effect_attempts(id) ON DELETE CASCADE;


--
-- Name: task_execution_effects task_execution_effects_current_intent_id_task_exec_671350815f49; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effects
    ADD CONSTRAINT task_execution_effects_current_intent_id_task_exec_671350815f49 FOREIGN KEY (current_intent_id) REFERENCES agent_workflow.task_execution_intents(id) ON DELETE CASCADE;


--
-- Name: task_execution_effects task_execution_effects_origin_intent_id_task_execu_7e144c8d36fe; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effects
    ADD CONSTRAINT task_execution_effects_origin_intent_id_task_execu_7e144c8d36fe FOREIGN KEY (origin_intent_id) REFERENCES agent_workflow.task_execution_intents(id) ON DELETE CASCADE;


--
-- Name: task_execution_effects task_execution_effects_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_effects
    ADD CONSTRAINT task_execution_effects_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_execution_intents task_execution_intents_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_intents
    ADD CONSTRAINT task_execution_intents_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_execution_maintenance_members task_execution_maintenance_members_claim_id_task_e_f62fa5a702b6; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_maintenance_members
    ADD CONSTRAINT task_execution_maintenance_members_claim_id_task_e_f62fa5a702b6 FOREIGN KEY (claim_id) REFERENCES agent_workflow.task_execution_maintenance_claims(id) ON DELETE CASCADE;


--
-- Name: task_execution_owners task_execution_owners_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_execution_owners
    ADD CONSTRAINT task_execution_owners_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_node_clarify_directives task_node_clarify_directives_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_node_clarify_directives
    ADD CONSTRAINT task_node_clarify_directives_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_questions task_questions_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_questions
    ADD CONSTRAINT task_questions_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_repos task_repos_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_repos
    ADD CONSTRAINT task_repos_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: task_space_nodes task_space_nodes_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.task_space_nodes
    ADD CONSTRAINT task_space_nodes_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_parent_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.tasks
    ADD CONSTRAINT tasks_parent_task_id_tasks_id_fk FOREIGN KEY (parent_task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: user_identities user_identities_provider_id_oidc_providers_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_identities
    ADD CONSTRAINT user_identities_provider_id_oidc_providers_id_fk FOREIGN KEY (provider_id) REFERENCES agent_workflow.oidc_providers(id) ON DELETE RESTRICT;


--
-- Name: user_identities user_identities_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_identities
    ADD CONSTRAINT user_identities_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: user_pats user_pats_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_pats
    ADD CONSTRAINT user_pats_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: user_permission_grants user_permission_grants_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_permission_grants
    ADD CONSTRAINT user_permission_grants_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: user_repository_transport_credentials user_repository_transport_credentials_connection_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_repository_transport_credentials
    ADD CONSTRAINT user_repository_transport_credentials_connection_fk FOREIGN KEY (provider, connection_generation) REFERENCES agent_workflow.repository_transport_connections(provider, connection_generation) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_repository_transport_credentials user_repository_transport_credentials_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_repository_transport_credentials
    ADD CONSTRAINT user_repository_transport_credentials_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.user_sessions
    ADD CONSTRAINT user_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES agent_workflow.users(id) ON DELETE CASCADE;


--
-- Name: verification_profile_revisions verification_profile_revisions_profile_id_verifica_e654c156f61c; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.verification_profile_revisions
    ADD CONSTRAINT verification_profile_revisions_profile_id_verifica_e654c156f61c FOREIGN KEY (profile_id) REFERENCES agent_workflow.verification_profiles(id);


--
-- Name: webhook_trigger_fires webhook_trigger_fires_trigger_id_webhook_triggers_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_trigger_fires
    ADD CONSTRAINT webhook_trigger_fires_trigger_id_webhook_triggers_id_fk FOREIGN KEY (trigger_id) REFERENCES agent_workflow.webhook_triggers(id) ON DELETE CASCADE;


--
-- Name: webhook_trigger_streams webhook_trigger_streams_trigger_id_webhook_triggers_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_trigger_streams
    ADD CONSTRAINT webhook_trigger_streams_trigger_id_webhook_triggers_id_fk FOREIGN KEY (trigger_id) REFERENCES agent_workflow.webhook_triggers(id) ON DELETE CASCADE;


--
-- Name: webhook_triggers webhook_triggers_endpoint_id_webhook_endpoints_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.webhook_triggers
    ADD CONSTRAINT webhook_triggers_endpoint_id_webhook_endpoints_id_fk FOREIGN KEY (endpoint_id) REFERENCES agent_workflow.webhook_endpoints(id);


--
-- Name: workgroup_assignments workgroup_assignments_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_assignments
    ADD CONSTRAINT workgroup_assignments_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: workgroup_member_cursors workgroup_member_cursors_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_member_cursors
    ADD CONSTRAINT workgroup_member_cursors_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: workgroup_members workgroup_members_workgroup_id_workgroups_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_members
    ADD CONSTRAINT workgroup_members_workgroup_id_workgroups_id_fk FOREIGN KEY (workgroup_id) REFERENCES agent_workflow.workgroups(id) ON DELETE CASCADE;


--
-- Name: workgroup_messages workgroup_messages_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_messages
    ADD CONSTRAINT workgroup_messages_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: workgroup_messages workgroup_messages_trigger_message_id_workgroup_messages_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_messages
    ADD CONSTRAINT workgroup_messages_trigger_message_id_workgroup_messages_id_fk FOREIGN KEY (trigger_message_id) REFERENCES agent_workflow.workgroup_messages(id) ON DELETE SET NULL;


--
-- Name: workgroup_task_state workgroup_task_state_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: agent_workflow; Owner: -
--

ALTER TABLE ONLY agent_workflow.workgroup_task_state
    ADD CONSTRAINT workgroup_task_state_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES agent_workflow.tasks(id) ON DELETE CASCADE;


--
-- Name: database_generations database_generations_operation_id_fkey; Type: FK CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.database_generations
    ADD CONSTRAINT database_generations_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES agent_workflow_meta.logical_copy_operations(operation_id) ON DELETE RESTRICT;


--
-- Name: logical_copy_chunks logical_copy_chunks_operation_id_fkey; Type: FK CONSTRAINT; Schema: agent_workflow_meta; Owner: -
--

ALTER TABLE ONLY agent_workflow_meta.logical_copy_chunks
    ADD CONSTRAINT logical_copy_chunks_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES agent_workflow_meta.logical_copy_operations(operation_id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict Q802Qe3I5i6fCXkRhgnt1T151kOEpA9VOJ2g9lfUr8zcn8Is8aECyN5rcJiVO7Z

